# Method note - frame extension over the occupied ground floor

## 1. Which document governs where the issued set disagrees with itself

`rules/TWP-09_temporary_works_procedure.md` **revision C is the document in force** and governs this
package. Revision B is marked SUPERSEDED in its own file name and by clause 1 of revision C; it is not
applied anywhere here. The revision B values that changed at C were not used: completion day 250
(revision B said 310), yard stock 3,600 sf of soffit and 120 ft of scaffold face (revision B said
4,500 and 160), 8 gangs (revision B said 10), 10 crane hours in a shift (revision B said 12),
reshoring at 8 ft centres (revision B said 10) and a full-strength age of 28 days (revision B said
21). Revision B also allowed an early strike without reshoring; revision C does not, so every slab
in this package is reshored. Every TWP-09 clause number cited in the constraint register is a
revision C clause; the register also cites the five adopted CFR documents, the catalogues and the
model schedules, which have their own clause, row or field references.

`programme/activity_list.csv` governs the programme. `programme/SUPERSEDED_baseline_programme_revA.csv`
is revision A of the baseline and is not in force: it programmes every SHOR activity at four days
against the issued two and omits the level-to-level scaffold dependencies that the issued list
carries. All 294 durations, crane hours and dependencies in `construction_sequence.csv` are the
issued ones; those superseded durations and that superseded logic are not used.

The design is taken from the model schedules (`storey_schedule.csv`, `slab_schedule.csv`,
`column_schedule.csv`, `zone_schedule.csv`, `grid_schedule.csv`), which are the takeoff. The
architect's IFC exports are partial and were not used as a quantity source. `L1_HW_IFC.ifc` contains
31 `IFCCOLUMN` entities (plus 29 `IFCCOLUMNTYPE` definitions) and `L3_HW_IFC.ifc` contains 24
`IFCCOLUMN` entities (plus 24 `IFCCOLUMNTYPE` definitions), 55 `IFCCOLUMN` entities in total;
`column_schedule.csv` has 78 schedule rows for 26 distinct `source_ifc_entity` values. The two IFC
exports therefore do not carry every column of this package, and neither says anything about how the
frame is built. Their storey spacings (16.667 ft between levels) agree with the storey
schedule to 0.007 ft, a difference with no effect on any height, extension or volume here; where
they differ at all the schedule governs as the takeoff. `site/existing_occupation.csv` governs which
zone-lifts carry a protective deck. `method_statements/MS-14_facade_replacement_OTHER_SCOPE.md` is a
different package and is not used. Where TWP-09 restates a clause of 29 CFR 1926.451, 1926.703,
1926.250, 1926.34 or 1926.1408, the CFR text was opened and the stricter of the two readings applied.

## 2. Sequence

The package carries all 42 zone-lifts of `zone_work_schedule.csv` and all 294 issued activities under
their issued ids, with the issued durations and crane hours. TWP-09 clause 7.2 (one zone-lift at a
time in a zone) is applied as an added dependency on top of the issued logic: the L3 zone-lift of a
zone starts only when the L2 zone-lift has finished (SCST complete), and L4 only when L3 has.
Within a lift COL and SCAF start together, SHOR follows both, then RBAR, POUR, the early-strike
wait, STRK and SCST. The three stair-core zones (Z-A-N, Z-B-S, Z-E-S) are separated so that no more
than one of them is shored on any day (clause 7.3). The programme finishes on day 211 against the
250-day contract date; the sum of the zone-lift finish days, which is the programme term in the
price, is 4,126.

## 3. Striking and reshoring method adopted

Both mixes are struck at their early-strike age - 7 days for M40-PUMP and 4 days for M50-HE
(`catalogue/concrete_mix_schedule.csv`) - and every slab is reshored as the original shores are
removed, which is the only condition under which clause 6.3 permits an early strike (29 CFR
1926.703(b)(10) and (e)(1)(i)). Reshoring is RS-16 at 8 ft centres in both directions: the posts are
set out on a perimeter grid of (ceil(Lx/8)+1) by (ceil(Ly/8)+1), giving 24 to 35 posts per zone-lift
and 1,170 in total, so the in-line spacing is at most 8 ft in
both directions. `install_day` is the start of STRK, the day the first original shores come out, not
the end of the strike; the occupancy report's shored period closes at the finish of STRK. Reshoring
is removed 28 days after the pour finishes, the full-strength age (clause 6.4, 29 CFR
1926.703(e)(2)). The yard model is the conservative one: the full soffit stands from SHOR to the
finish of STRK and the 25 per cent reshore stock stands from the start of STRK to removal, so the two
overlap during the strike. The programme is levelled against that overlap, and its worst day is
3,594 sf of the 3,600 sf the yard holds. The alternative - no reshoring, forms left in place to
28 days - was priced and rejected: it would hold the whole soffit area for about 32 days instead of
about 11 days at full area plus about 22 days at 25 per cent, and the 3,600 sf yard would not then carry 42
zone-lifts to the 250-day completion date.

## 4. The constraint that governs each zone

* **L2 Z-A-N to Z-C-S (six zone-lifts):** the space below is in continued occupation, so the shoring
  carries a protective deck and the design load includes its 15 psf (q = 387.6 psf);
  the scaffold is medium duty (1,000 lb per bay) and the shore grid is 3.5 ft. The deck is 3/4 in
  plywood on 4 x 4 headers carried by the shore heads, with 12 in edge kerbs, installed with SHOR and
  removed with STRK; it is kept clear of the occupied ceiling and nothing is fixed to the floor below.
* **L2 Z-D-N/Z-D-S and all L3/L4 zone-lifts of bands A-D (18):** placed by pump, q = 372.6 psf,
  light duty SF-3 scaffold, 3.5 ft shore grid.
* **Bands E-G, all three levels (18):** placed by crane and bucket, q = 397.6 psf, heavy
  duty SF-5 scaffold (five planks per bay give 7,500 lb against 4 x 1,750 lb), 3.5 ft shore grid.
* **L3 and L4 (28 zone-lifts):** the scaffolds are 35.42 ft and 52.08 ft above grade. Both exceed 35 ft,
  so each carries a rest platform at 32.5 ft in addition to the working platform; `platform_levels` is
  2 for these 28 lifts, with the planks, guardrails and capacity of both levels counted. Ties are at
  horizontal members at intervals not exceeding 20 ft for the 3 ft SF-3 and 26 ft for the 5 ft SF-5,
  with the top tie within the 4:1 height of the top and ties at both ends; the SF-5 L4 lifts carry an
  intermediate tie at 32.5 ft so the interval there is 13 ft, not 26 ft.
* **B zones (six zone-lifts):** the 30 ft face needs five 7 ft bays, a 35 ft scaffold. Three tie
  columns are used, so the horizontal interval is 17.5 ft, inside the 30 ft limit; two columns would
  have left 35 ft. The 35 ft erected length is counted in the erected-face check; the yard peak on that basis is 98.0 ft.
* **Stair-core zones Z-A-N, Z-B-S, Z-E-S:** clause 7.3 - one shored at a time; this sets the offset
  between those three zones in the programme.
* **Z-D-N/Z-D-S:** the heaviest pick (13,674 lb at L3) governs the crane. CP-C serves D-N at
  78.55 ft, where the chart rates 16,116 lb, and D-S at the 40 ft chart radius, where it
  rates 38,000 lb; both are served with margin.
* **Every zone-lift:** the yard in clause 8.3 governs the programme. Shoring for 3,600 sf of soffit
  and 120 ft of face is the binding shared resource. The declared programme peaks at 3,594 sf on
  the overlap model and 84 ft of zone face; the actual erected scaffold face (bays x bay
  length) peaks at 98.0 ft. All are inside the 3,600 sf and 120 ft limits.

## 5. Margins applied

* **Shore posts:** worst utilisation 0.812 (4,870.6 lb against the
  SP-16 6,000 lb rating, on the 3.5 ft grid). Every zone uses the 3.5 ft grid; the post count is a
  perimeter grid at that spacing (4,134 posts in total), so the actual
  tributary spacing is at most 3.5 ft. The 4.0 ft grid would have been cheaper by about 1,495 units
  but would sit at 5,961.6/6,000 = 0.994 of the rating; the 3.5 ft grid is adopted for a visible
  reserve. The 4.5 ft and 5.0 ft grids exceed the rating at q = 372.6 psf (7,545 and 9,315 lb) and
  are not available. SP-13 and SP-09 are ruled out by the 13.83 ft required extension.
* **Platform capacity:** SF-3 light 4,500 lb against 4 x 750 = 3,000 lb; SF-3 medium 4,500 against
  4 x 1,000 = 4,000; SF-5 heavy 7,500 against 4 x 1,750 = 7,000. No platform is set at the exact 4x
  limit.
* **Platform width and gaps:** platform width 28.5 in on the 3 ft SF-3 and 47.5 in on the 5 ft SF-5.
  The frame is set out with a 6.5 in front edge gap (SF-3) or 11.5 in (SF-5), so the back edge is
  1.0 in from the uprights; both front gaps are inside the 14 in limit (clause 4.3, 29 CFR
  1926.451(b)(3)) and the 1 in platform-to-upright limit (29 CFR 1926.451(b)(1)(i)) is met without a
  filler. The back gap is 1.00 in in every case (variation 0.00 in).
* **Planking:** PL-95 planks are 10 ft long on 7 ft bays, so each plank overlaps its neighbour by
  3 ft over the bearer, well over the 12 in minimum of 29 CFR 1926.451(b)(7). At the ends of each run
  the plank is restrained from movement at the end bearer, the condition on which 29 CFR
  1926.451(b)(5)(i) permits an end overhang greater than 12 in, and each end extends at least 6 in
  over the centreline of its support, 29 CFR 1926.451(b)(4).
* **Guardrail:** 42 in toprail (38 to 45 permitted), on all open sides and ends of every platform
  level, including the rest platforms.
* **Bearing:** each frame leg bears on a 12 in x 24 in mudsill (2 sf); the worst pressure is
  1,828 psf against the 2,000 psf limit.
* **Crane:** one fixed standing position, CP-C. The worst radius is 105.14 ft (Z-A-N) and the worst
  rated-capacity utilisation is 0.931 (8,752 lb pick against
  9,403 lb at 105.14 ft). The demarcated radius is 140 ft, inside the
  145 ft the 155 ft distance to the 34.5 kV line allows after the 10 ft Table A approach. There is no
  crane relocation in the programme.
* **Programme:** last activity finishes on day 211 against 250 (utilisation 0.84); peak crane
  9.49 of 10 h per shift; peak 6 of 8 gangs; 16 of 16 laydown units; one stair core
  shored at a time; yard 3,594 of 3,600 sf on the overlap model (3,584 on the non-overlap model).
* **Stability:** the greatest demand is 9,512 lb (L2-Z-B-N, against 12,000 lb of XB-1 bracing); the
  worst utilisation is 0.854 (6,830 lb against 8,000 lb at L4-Z-F-N); every check passes.

## 6. Options priced and not adopted

* **4.0 ft shore grid:** cheaper by about 1,495 units over the 18 zone-lifts that could use it, but
  99.4 per cent of the SP-16 rating. The 3.5 ft grid is adopted to hold a visible reserve; the price
  of that reserve is stated in section 7.
* **SP-13 and SP-09 posts:** maximum extensions 13 ft and 9 ft are shorter than the 13.83 ft required
  extension, so they cannot be used even though they are cheaper per post.
* **Adjacent slab diaphragm (clause 6.2):** it would remove the XB-1 bracing cost (288 units in total)
  where an adjacent zone at the same level has reached early-strike age before the zone's shoring goes
  up. It is not adopted for every lift: the adjacent slab is not at early-strike age at the SHOR date
  for all 42 lifts, and the bracing is the lateral system that is independent of the state of the
  neighbouring pour. XB-1 bracing is retained, 2 or 3 bays per lift (8,000 or 12,000 lb).
* **Two planks per bay for light duty:** 2 x 1,500 = 3,000 lb is exactly 4 x 750 lb, with no reserve,
  and still requires the 1 in back gap. Three planks (4,500 lb) are retained; the extra plank costs
  about 62 units over the light-duty lifts.
* **SF-7 for the 30 ft B zones:** a 3 x 10 ft scaffold would match the face, but the frame cost is
  9 units against 4 for SF-3 and the total is higher at every level; SF-3 with five 7 ft bays and
  three tie columns is retained.
* **No-reshore, 28-day strike:** as section 3, it does not fit the 3,600 sf yard.
* **CP-W and CP-E:** smaller radii for some zones, but a second standing position would require a
  crane relocation and a second demarcation; one fixed CP-C position serves all 42 lifts within
  105.14 ft at 0.931 of the chart, so it is retained.

## 7. Price

The temporary-works price (clauses 10.1 and 10.2) is 31,426 cost units: 20,670 for the
shoring posts, 4,680 for the reshoring, 5,788 for the scaffolds (frames, planks,
guardrails and ties) and 288 for the frame bracing. The programme term is 4 units for each
of the 4,126 zone-lift-days to completion, or 16,504 units. The total is 47,930 units.
The 3.5 ft grid costs about 1,495 units more than the 4.0 ft grid and buys the shoring reserve; the
rest platforms and the third tie column on the B scaffolds cost 520 and 24 units respectively
and are required by clauses 4.6 and 4.4.

## 8. Conditions that must be met before and during the work

The package is issued with these actions recorded as conditions of the sequence, not as open items:
the temporary-works drawings (TWD-2024-014 Rev C) are on site before the first SCAF (clause 6.5, 29
CFR 1926.703(a)(2)); the utility confirms the 34.5 kV line voltage within two working days of the
request (29 CFR 1926.1408(c)); before lifting starts there is a planning meeting with the operator
and the crews in the area, an elevated warning line or line of signs at the Table A distance of 10 ft,
a proximity alarm or dedicated spotter, and the work zone demarcated at the 140 ft radius (29 CFR
1926.1408(b)(1), (b)(3), (b)(4), Option (3)); all power lines are treated as energized and uninsulated
until the utility confirms otherwise (29 CFR 1926.1408(e), (g)); the crane operator and crew are
trained on electrical-contact procedures (29 CFR 1926.1408(g)); shoring is inspected before erection
and again immediately before, during and after each pour (29 CFR 1926.703(b)(1), (b)(3)); scaffolds
are erected, moved, dismantled and altered only under the supervision of a competent person
qualified in scaffold erection, and are inspected by a competent person before each shift (29 CFR
1926.451(f)(7), (f)(3)); the stairtower access has stairrails, 18 in x 18 in landings, 18 in clear
width, a 40 to 60 degree slope and guardrails at every landing (29 CFR 1926.451(e)(4)); the reshore
is left in place until the slab is 28 days old and no load in excess of the slab's capacity is placed
on it before then; the protective deck over the six occupied L2 lifts is installed with the shoring
and removed with the strike; and two means of egress stay open on every level with no more than one
stair-core zone shored at a time (clause 7.3). No condition blocks the sequence: every zone-lift has
a date, the last finishes on day 211 inside the 250-day contract date, and the binding constraint on
the package is the yard in clause 8.3, which peaks at 3,594 of the 3,600 sf it may hold.

## 9. Attribution and CC BY 4.0

The building geometry in this corpus - its storey elevations, column grid and sections, slab
thickness and stair cores - is derived from the LivingBIM Dataset: *As-designed and As-built Dataset
for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images*, DOI
10.5281/zenodo.17934615, licensed under Creative Commons Attribution 4.0 International (CC BY 4.0),
https://creativecommons.org/licenses/by/4.0/legalcode.

Attribution: "Building geometry, storey elevations, column grid and sections, slab thickness and
stair cores are reproduced from the LivingBIM Dataset (DOI 10.5281/zenodo.17934615), CC BY 4.0."
Changes: the model schedules in this package are extracts and reformatting of the LivingBIM data;
the zone breakdown, temporary works, programme, quantities and prices are the contractor's work and
are not part of the original dataset. The attribution and the CC BY 4.0 conditions - attribution,
a link to the licence, an indication of changes, and no additional restrictions - are carried with
every design quantity reproduced from the model schedules in this package. The attribution does not
imply that the LivingBIM authors endorse this package.
