# Foundation-Type Feasibility and Optimisation Matrix

Cattail Run Data Campus, Phase 1 - AV-CR-2604. One section per pad, one row per foundation. All costs are pad-level construction costs at the project budget unit prices (bid schedule Rev. 1 and Kettleridge proposal KGS-26-0917), including the per-pad production modulus test where the pad is improved but excluding the campus rig mobilisation, which is shown once in the campus summary. The angular distortion (AD) is dimensionless, computed as the difference in settlement between adjacent units divided by the distance between them with both terms in inches, and compared with the criteria limit 1/500 = 0.002.

**Campus summary.** Pads improved: CR-P1, CR-P2, CR-P4, CR-P6. Rigs mobilised: 2 (each serves two pads). Mobilisation: $80,000. Campus total: **$460,100**. Maximum total settlement 0.880 in (CR-P2 F3) against 1.0 in; maximum angular distortion 0.001417 (CR-P6 F5-W1) against 1/500 = 0.002, utilisation 0.71.

| Pad | Decision | Bearing depth (in) | Bearing stratum | FS | Max settlement (in) | Max angular distortion | Max q_net/q_allow | Pad cost |
|---|---|---:|---|---:|---:|---:|---:|---:|
| CR-P1 | IMPROVED_SPREAD | 45 | I | 3.5 | 0.738 | 0.001083 | 0.957 | $88,034 |
| CR-P2 | IMPROVED_SPREAD | 48 | I | 3.5 | 0.880 | 0.001350 | 0.947 | $94,441 |
| CR-P3 | SPREAD | 45 | I | 3.5 | 0.879 | 0.000917 | 0.933 | $36,333 |
| CR-P4 | IMPROVED_SPREAD | 42 | I | 3.0 | 0.660 | 0.000767 | 0.957 | $47,790 |
| CR-P5 | SPREAD | 42 | I | 3.0 | 0.646 | 0.000833 | 0.937 | $22,509 |
| CR-P6 | IMPROVED_SPREAD | 48 | I | 3.5 | 0.832 | 0.001417 | 0.952 | $90,992 |

## CR-P1 - Data Hall 1

**Occupancy:** Light Industrial, Public (FS = 3.5). **Bearing elevation:** 45 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 45 in = 3.75 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 8.0 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.14 % -> S1; **exposure classes:** F1, W1, C1, S1; **concrete:** f'c = 4000 psi, w/cm <= 0.50.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.957 (limit 1.00), the maximum total settlement is 0.738 in (limit 1.00 in) and the maximum angular distortion is 0.001083 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 610.0 | 838.0 | IMPROVED_SPREAD | 135 x 135 x 30 | 4.820 | 5.2 | 0.927 | 0.605 | — | 9 x 8 | 0.3491 | 12,543 | #6 @ 8 in / 0.00185 | BEARING | $6,670 |
| F2 | 1180.0 | 1622.0 | IMPROVED_SPREAD | 183 x 183 x 42 | 5.074 | 5.3 | 0.957 | 0.721 | 0.000403 | 16 x 8 | 0.3377 | 13,861 | #8 @ 10 in / 0.00293 | BEARING | $14,958 |
| F3 | 1420.0 | 1953.0 | IMPROVED_SPREAD | 201 x 201 x 45 | 5.061 | 5.4 | 0.937 | 0.738 | 0.000260 | 20 x 8 | 0.3499 | 13,554 | #6 @ 5 in / 0.00300 | BEARING | $18,894 |
| F4 | 980.0 | 1348.0 | IMPROVED_SPREAD | 168 x 168 x 36 | 5.000 | 5.3 | 0.943 | 0.688 | 0.000410 | 14 x 8 | 0.3506 | 13,115 | #8 @ 11 in / 0.00209 | BEARING | $11,152 |
| F5 | 520.0 | 715.0 | IMPROVED_SPREAD | 126 x 126 x 27 | 4.717 | 5.2 | 0.907 | 0.629 | 0.001083 | 8 x 8 | 0.3562 | 12,018 | #6 @ 9 in / 0.00195 | BEARING | $5,696 |
| W1 | 1650.0 | 2244.0 | IMPROVED_SPREAD | 177 x 288 x 33 | 4.661 | 4.9 | 0.951 | 0.694 | 0.001083 | 25 x 9 | 0.3467 | 12,315 | #9 @ 6 in / 0.00316 | BEARING | $21,164 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 29.5 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 5.67 ksf against the one-third-increased allowable of 6.53 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: IMPROVED_SPREAD.** Spread-only cost **$532,227** (a deep-founding all-spread scheme bearing below the compressible Stratum I; no compliant shallow spread-only scheme exists at acceptable width); improved cost **$88,034**. Ground improvement is decisively cheaper than deep founding, and the rig is required for the pad's settlement control.

**Pad cost:** sum of foundation costs $78,534 + per-pad production test $9,500 = **$88,034**. Piers on this pad: 761 LF; deepest treatment 9 ft. Maximum settlement 0.738 in; maximum AD 0.001083.

## CR-P2 - Data Hall 2

**Occupancy:** Light Industrial, Public (FS = 3.5). **Bearing elevation:** 48 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 48 in = 4.00 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 9.0 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.23 % -> S2; **exposure classes:** F1, W1, C1, S2; **concrete:** f'c = 4500 psi, w/cm <= 0.45.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.947 (limit 1.00), the maximum total settlement is 0.880 in (limit 1.00 in) and the maximum angular distortion is 0.001350 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 646.6 | 888.3 | IMPROVED_SPREAD | 135 x 135 x 27 | 5.109 | 5.4 | 0.946 | 0.848 | — | 9 x 9 | 0.3491 | 13,151 | #5 @ 5 in / 0.00239 | BEARING | $7,174 |
| F2 | 1250.8 | 1719.3 | IMPROVED_SPREAD | 186 x 186 x 42 | 5.206 | 5.5 | 0.947 | 0.848 | 0.000133 | 17 x 8 | 0.3473 | 13,891 | #9 @ 12 in / 0.00308 | BEARING | $16,426 |
| F3 | 1505.2 | 2070.2 | IMPROVED_SPREAD | 204 x 204 x 45 | 5.208 | 5.6 | 0.930 | 0.880 | 0.000344 | 20 x 8 | 0.3397 | 14,224 | #8 @ 8 in / 0.00336 | BEARING | $20,740 |
| F4 | 1038.8 | 1428.9 | IMPROVED_SPREAD | 171 x 171 x 36 | 5.116 | 5.5 | 0.930 | 0.814 | 0.000736 | 14 x 8 | 0.3384 | 13,757 | #8 @ 10 in / 0.00231 | BEARING | $12,157 |
| F5 | 551.2 | 757.9 | IMPROVED_SPREAD | 126 x 126 x 27 | 5.000 | 5.3 | 0.943 | 0.708 | 0.001350 | 8 x 8 | 0.3562 | 12,691 | #6 @ 8 in / 0.00207 | BEARING | $5,996 |
| W1 | 1749.0 | 2378.6 | IMPROVED_SPREAD | 180 x 288 x 33 | 4.858 | 5.2 | 0.934 | 0.789 | 0.001350 | 27 x 8 | 0.3682 | 12,220 | #11 @ 9 in / 0.00345 | BEARING | $22,447 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 30.0 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 5.89 ksf against the one-third-increased allowable of 6.93 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: IMPROVED_SPREAD.** Spread-only cost **$410,781** (a deep-founding all-spread scheme bearing below the compressible Stratum I; no compliant shallow spread-only scheme exists at acceptable width); improved cost **$94,441**. Ground improvement is decisively cheaper than deep founding, and the rig is required for the pad's settlement control.

**Pad cost:** sum of foundation costs $84,941 + per-pad production test $9,500 = **$94,441**. Piers on this pad: 769 LF; deepest treatment 9 ft. Maximum settlement 0.880 in; maximum AD 0.001350.

## CR-P3 - Electrical Yard Building

**Occupancy:** Light Industrial, Public (FS = 3.5). **Bearing elevation:** 45 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 45 in = 3.75 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 19.0 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.07 % -> S0; **exposure classes:** F1, W1, C1, S0; **concrete:** f'c = 4000 psi, w/cm <= 0.50.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.933 (limit 1.00), the maximum total settlement is 0.879 in (limit 1.00 in) and the maximum angular distortion is 0.000917 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 439.2 | 603.4 | SPREAD | 111 x 111 x 24 | 5.133 | 5.5 | 0.933 | 0.623 | — | — | — | — | #6 @ 10 in / 0.00199 | BEARING | $2,901 |
| F2 | 849.6 | 1167.8 | SPREAD | 153 x 153 x 33 | 5.226 | 5.7 | 0.917 | 0.824 | 0.000698 | — | — | — | #7 @ 9 in / 0.00214 | BEARING | $6,353 |
| F3 | 1022.4 | 1406.2 | SPREAD | 177 x 177 x 36 | 4.699 | 5.8 | 0.810 | 0.874 | 0.000208 | — | — | — | #5 @ 4 in / 0.00219 | SETTLEMENT | $8,888 |
| F4 | 705.6 | 970.6 | SPREAD | 144 x 144 x 30 | 4.900 | 5.6 | 0.875 | 0.879 | 0.000500 | — | — | — | #5 @ 5 in / 0.00209 | SETTLEMENT | $5,334 |
| F5 | 374.4 | 514.8 | SPREAD | 105 x 105 x 21 | 4.890 | 5.4 | 0.906 | 0.807 | 0.000917 | — | — | — | #6 @ 10 in / 0.00220 | BEARING | $2,503 |
| W1 | 1188.0 | 1615.7 | SPREAD | 144 x 288 x 27 | 4.125 | 5.2 | 0.793 | 0.862 | 0.000917 | — | — | — | #6 @ 3 in / 0.00278 | SETTLEMENT | $10,354 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 24.0 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 5.22 ksf against the one-third-increased allowable of 6.93 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: SPREAD (shallow spread in Stratum I at the 45-in bearing elevation).** Spread-only cost **$36,333**; improved (all six foundations on rammed aggregate piers) cost **$57,345**. The least-cost hybrid with piers only under W1 is about $50,100 including its production test, still more than the all-spread scheme. Stratum I is only 5.5-7.0 ft thick, so shallow spread is the least-cost compliant scheme.

**Pad cost:** sum of foundation costs $36,333 + per-pad production test $0 = **$36,333**. Piers on this pad: 0 LF; deepest treatment 0 ft. Maximum settlement 0.879 in; maximum AD 0.000917.

## CR-P4 - Administration and Operations Building

**Occupancy:** Apartments, Office (FS = 3.0). **Bearing elevation:** 42 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 42 in = 3.50 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 8.0 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.11 % -> S1; **exposure classes:** F1, W1, C1, S1; **concrete:** f'c = 4000 psi, w/cm <= 0.50.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.957 (limit 1.00), the maximum total settlement is 0.660 in (limit 1.00 in) and the maximum angular distortion is 0.000767 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 384.3 | 527.9 | IMPROVED_SPREAD | 102 x 102 x 21 | 5.319 | 5.8 | 0.917 | 0.554 | — | 5 x 8 | 0.3397 | 13,757 | #5 @ 7 in / 0.00218 | BEARING | $3,426 |
| F2 | 743.4 | 1021.9 | IMPROVED_SPREAD | 138 x 138 x 30 | 5.621 | 6.0 | 0.937 | 0.601 | 0.000246 | 10 x 8 | 0.3712 | 13,815 | #6 @ 7 in / 0.00213 | BEARING | $7,077 |
| F3 | 894.6 | 1230.4 | IMPROVED_SPREAD | 150 x 150 x 33 | 5.725 | 6.0 | 0.954 | 0.660 | 0.000302 | 11 x 8 | 0.3456 | 14,934 | #8 @ 11 in / 0.00224 | BEARING | $8,522 |
| F4 | 617.4 | 849.2 | IMPROVED_SPREAD | 126 x 126 x 27 | 5.600 | 5.9 | 0.949 | 0.602 | 0.000701 | 8 x 8 | 0.3562 | 14,118 | #7 @ 11 in / 0.00212 | BEARING | $5,633 |
| F5 | 327.6 | 450.4 | IMPROVED_SPREAD | 93 x 93 x 21 | 5.454 | 5.7 | 0.957 | 0.501 | 0.000767 | 5 x 8 | 0.4086 | 12,222 | #6 @ 12 in / 0.00181 | BEARING | $3,020 |
| W1 | 1039.5 | 1413.7 | IMPROVED_SPREAD | 111 x 288 x 21 | 4.682 | 5.2 | 0.900 | 0.547 | 0.000767 | 16 x 8 | 0.3538 | 11,819 | #8 @ 5 in / 0.00301 | BEARING | $10,614 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 18.5 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 6.30 ksf against the one-third-increased allowable of 6.93 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: IMPROVED_SPREAD.** Spread-only cost **$69,170** (shallow spread at a 48-in bearing elevation; at the adopted 42-in elevation the spread-only scheme cannot meet the settlement limit within a practical width); improved cost **$47,790**. Ground improvement is cheaper and fits the second rig with no additional mobilisation.

**Pad cost:** sum of foundation costs $38,290 + per-pad production test $9,500 = **$47,790**. Piers on this pad: 440 LF; deepest treatment 8 ft. Maximum settlement 0.660 in; maximum AD 0.000767.

## CR-P5 - Logistics and Spares Warehouse

**Occupancy:** Warehouse (FS = 3.0). **Bearing elevation:** 42 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 42 in = 3.50 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 21.0 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.05 % -> S0; **exposure classes:** F3, W1, C1, S0; **concrete:** f'c = 5000 psi, w/cm <= 0.40.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.937 (limit 1.00), the maximum total settlement is 0.646 in (limit 1.00 in) and the maximum angular distortion is 0.000833 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 335.5 | 460.9 | SPREAD | 93 x 93 x 18 | 5.586 | 6.0 | 0.931 | 0.427 | — | — | — | — | #5 @ 7 in / 0.00260 | BEARING | $1,968 |
| F2 | 649.0 | 892.1 | SPREAD | 126 x 126 x 27 | 5.887 | 6.3 | 0.934 | 0.569 | 0.000493 | — | — | — | #7 @ 10 in / 0.00230 | BEARING | $4,167 |
| F3 | 781.0 | 1074.2 | SPREAD | 138 x 138 x 30 | 5.905 | 6.3 | 0.937 | 0.646 | 0.000321 | — | — | — | #8 @ 12 in / 0.00229 | BEARING | $5,267 |
| F4 | 539.0 | 741.4 | SPREAD | 117 x 117 x 24 | 5.670 | 6.2 | 0.915 | 0.618 | 0.000403 | — | — | — | #6 @ 8 in / 0.00236 | BEARING | $3,409 |
| F5 | 286.0 | 393.3 | SPREAD | 87 x 87 x 18 | 5.441 | 5.9 | 0.922 | 0.560 | 0.000833 | — | — | — | #5 @ 8 in / 0.00218 | BEARING | $1,702 |
| W1 | 907.5 | 1234.2 | SPREAD | 96 x 288 x 18 | 4.727 | 5.3 | 0.892 | 0.610 | 0.000833 | — | — | — | #8 @ 5 in / 0.00305 | BEARING | $5,995 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 16.0 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 6.62 ksf against the one-third-increased allowable of 7.07 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: SPREAD (shallow spread in Stratum I at the 42-in frost minimum).** Spread-only cost **$22,509**; improved (all six foundations on rammed aggregate piers) cost **$42,925**. The least-cost hybrid with piers only under W1 is about $35,300 including its production test, still more than the all-spread scheme. Stratum I is only 4.5-5.5 ft thick, so shallow spread is the least-cost compliant scheme.

**Pad cost:** sum of foundation costs $22,509 + per-pad production test $0 = **$22,509**. Piers on this pad: 0 LF; deepest treatment 0 ft. Maximum settlement 0.646 in; maximum AD 0.000833.

## CR-P6 - Data Hall 3

**Occupancy:** Light Industrial, Public (FS = 3.5). **Bearing elevation:** 48 in below finished grade for all six foundations. **Bearing stratum:** I (all foundations; the deepest bearing surface is 48 in = 4.00 ft, above the shallowest interpolated Stratum I base of 4.5 ft at CR-P5 F1). **Groundwater:** 8.5 ft below finished grade; all bearing surfaces are above groundwater, so dewatering days = 0. **Sulfate:** 0.26 % -> S2; **exposure classes:** F1, W1, C1, S2; **concrete:** f'c = 4500 psi, w/cm <= 0.45.

**Pad-level governing constraint: BEARING.** The maximum reported bearing utilisation is 0.952 (limit 1.00), the maximum total settlement is 0.832 in (limit 1.00 in) and the maximum angular distortion is 0.001417 (limit 0.002). The bearing utilisation is at or above 0.80 at the critical foundation, so BEARING selects the pad design. The per-foundation constraint in the table is the largest of the bearing, settlement and angular-distortion utilisations for that foundation.

| Tag | Service P (k) | Strength Pu (k) | Type | B x L x t (in) | q_net (ksf) | q_allow (ksf) | q_net/q_allow | Settlement (in) | AD to previous | Piers (no. x ft) | Ra | qg (psf) | Bar / ratio | Governing constraint | Cost |
|---|---:|---:|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---:|---:|
| F1 | 622.2 | 854.8 | IMPROVED_SPREAD | 135 x 135 x 27 | 4.916 | 5.3 | 0.928 | 0.832 | — | 9 x 9 | 0.3491 | 12,686 | #7 @ 10 in / 0.00231 | BEARING | $7,142 |
| F2 | 1203.6 | 1654.4 | IMPROVED_SPREAD | 183 x 183 x 39 | 5.175 | 5.5 | 0.941 | 0.788 | 0.000153 | 16 x 8 | 0.3377 | 14,020 | #9 @ 12 in / 0.00337 | BEARING | $15,513 |
| F3 | 1448.4 | 1992.1 | IMPROVED_SPREAD | 201 x 201 x 45 | 5.162 | 5.6 | 0.922 | 0.786 | 0.000328 | 20 x 8 | 0.3499 | 13,798 | #9 @ 11 in / 0.00316 | BEARING | $19,986 |
| F4 | 999.6 | 1375.0 | IMPROVED_SPREAD | 168 x 168 x 36 | 5.100 | 5.5 | 0.927 | 0.723 | 0.000674 | 14 x 8 | 0.3506 | 13,356 | #7 @ 8 in / 0.00219 | BEARING | $11,759 |
| F5 | 530.4 | 729.3 | IMPROVED_SPREAD | 123 x 123 x 27 | 5.048 | 5.3 | 0.952 | 0.626 | 0.001417 | 8 x 8 | 0.3738 | 12,342 | #5 @ 6 in / 0.00197 | BEARING | $5,780 |
| W1 | 1683.0 | 2288.9 | IMPROVED_SPREAD | 174 x 288 x 33 | 4.836 | 5.1 | 0.948 | 0.711 | 0.001417 | 26 x 8 | 0.3667 | 12,205 | #9 @ 6 in / 0.00316 | BEARING | $21,312 |

**W1 shear-wall footing stability.** Sliding (0.6D + W): FS = 0.312 P/H = **2.30** (no passive credit; Stratum I phi' = 26 deg used at every pad) against the UFC 3-220-01 2-4.6.3 minimum 2.0. Overturning (D + L + W): e = M/P = **6.4 in**; B/6 = 29.0 in and L/6 = 48 in, so the resultant is within the middle third in both directions. Uplift (0.6D + W): FS = 0.6 x dead load / net uplift = **2.72**, ignoring footing and soil credit; exceeds 1.5. The D + L + W toe pressure is 5.90 ksf against the one-third-increased allowable of 6.80 ksf (IBC 1605.3.1), so the wind combination also satisfies bearing. All three stability checks pass; none governs the pad.

**Decision: IMPROVED_SPREAD.** Spread-only cost **$194,054** (an all-spread scheme with very large footings; at the adopted 48-in elevation the spread-only scheme requires footings far larger than the improved scheme); improved cost **$90,992**. Ground improvement is decisively cheaper, and the rig is required for the pad's settlement control.

**Pad cost:** sum of foundation costs $81,492 + per-pad production test $9,500 = **$90,992**. Piers on this pad: 753 LF; deepest treatment 9 ft. Maximum settlement 0.832 in; maximum AD 0.001417.

## Campus programme and rig assignment

| Pad | Decision | Pad cost | Rig |
|---|---|---:|---|
| CR-P1 | IMPROVED_SPREAD | $88,034 | RIG-1 |
| CR-P2 | IMPROVED_SPREAD | $94,441 | RIG-1 |
| CR-P3 | SPREAD | $36,333 | — |
| CR-P4 | IMPROVED_SPREAD | $47,790 | RIG-2 |
| CR-P5 | SPREAD | $22,509 | — |
| CR-P6 | IMPROVED_SPREAD | $90,992 | RIG-2 |
| **Rig mobilisation** | 2 rigs x $40,000 | $80,000 | |
| **Campus total** | | **$460,100** | |

Why two rigs: four pads are improved (CR-P1, CR-P2, CR-P4, CR-P6) and Kettleridge 4 permits at most two pads per rig, so ceil(4/2) = 2 rigs are required. P3 and P5 are not improved because their all-spread schemes ($36,318 and $22,509) are cheaper than their all-improved alternatives ($57,345 and $42,925), and adding either to the improved set would require a third rig (+$40,000). P4 is improved because its improved cost ($47,790) is below its spread-only alternative ($69,170) and it fits on the second rig with no additional mobilisation. The programme was selected by comparing all subsets of the six pads at their least-cost spread and improved schemes and adding ceil(k/2) rigs for k improved pads.

