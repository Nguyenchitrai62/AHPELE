```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 532227.0,
      "improved_cost_usd": 88034.48
    },
    "CR-P2": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 410781.0,
      "improved_cost_usd": 94440.8
    },
    "CR-P3": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 36332.73,
      "improved_cost_usd": 57345.0
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 69170.0,
      "improved_cost_usd": 47790.4
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 22509.15,
      "improved_cost_usd": 42925.0
    },
    "CR-P6": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 194054.0,
      "improved_cost_usd": 90992.37
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 460099.94,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-01N (2005) Foundation Design - cancelled predecessor volume; set aside, UFC 3-220-01 (2012, Change 3) governs.",
    "UFC 3-220-10N (2005) Soil Mechanics - cancelled predecessor volume; set aside, UFC 3-220-20 (2025) governs.",
    "Geotechnical Addendum 1 - superseded and withdrawn; its 4,000 psf presumptive value is not used.",
    "Basis of Design Rev. 1 - superseded in its entirety by Rev. 3; its all-Warehouse classification, F0 concrete, 1-in grid and 20-ft depth limit are not used.",
    "NOAA NCEI AFI 1951-1980 return periods - superseded edition; its 416 F-days is not used.",
    "Broadview Commons adjacent-parcel report (2023) - different property, information only; its 5,500 psf value is not used.",
    "3,000 psf presumptive bearing value - preliminary only; prohibited by AHJ Amendment 4 and RFI-009.",
    "4,000 psf and 5,500 psf presumptive values - from superseded or non-project documents; not used.",
    "Deep foundations (drilled piers, driven piles) - owner will not accept in Phase 1 per RFI-015.",
    "FHWA GEC 6 bridge movement criteria (1/300 and 0.004-0.005, differential about half total) - different class of structure; UFC 1/500 governs.",
    "EM 1110-2-2104 Table 3-1 hydraulic-structure load factors - expressly not applicable per the load combination memorandum.",
    "Subgrade-reaction settlement estimator - rejected by RFI-019 in favour of layered elastic compression.",
    "Proprietary vendor aggregate-pier stress ratios - rejected by RFI-011; FHWA GEC 13 n_s = 10 used."
  ]
}
```

# Design Basis - Cattail Run Data Campus, Phase 1 Foundation Strategy

**Project:** AV-CR-2604, Ardent Vale Infrastructure LLC, Loudoun County, Virginia
**Prepared by:** Structural Engineer of Record, Phase 1 foundation package
**Date:** 2026-08-14 (data-room issue date)
**Deliverables:** `foundation_geometry.json`, `ground_improvement_plan.json`, `foundation_schedule.xlsx`, `foundation_feasibility_matrix.md`, `constraint_register.xlsx`, this design basis.

## 1. Decision in brief

The Phase 1 package contains 36 foundations on six pads. The adopted programme is:

* **CR-P1, CR-P2, CR-P4 and CR-P6 - improved spread footings.** All six foundations on each of these pads are carried on 30-in rammed aggregate piers. The pads are improved because a shallow spread-only scheme cannot control total settlement on the soft Stratum I residual clay at these locations within a practical footing width; the least-cost all-spread alternatives are deep-founding schemes and are far more expensive.
* **CR-P3 and CR-P5 - shallow spread footings in Stratum I.** CR-P3 is founded at 45 in and CR-P5 at the 42-in frost minimum. At these pads Stratum I is thin (5.5-7.0 ft at P3; 4.5-5.5 ft at P5), and the all-spread scheme is cheaper than the all-improved alternative ($36,333 vs $57,345 at P3; $22,509 vs $42,925 at P5). Both pads are governed by **BEARING**, with maximum reported bearing utilisations of 0.933 and 0.937 respectively.
* **Two rigs are mobilised** for the four improved pads, each rig serving two pads, for a mobilisation cost of **$80,000**. The repriced campus total is **$460,100** at the project budget unit prices.

The maximum predicted total settlement is **0.880 in** (CR-P2, F3) against the 1.0 in limit. The maximum angular distortion is **0.001417** (CR-P6, between F5 and W1) against the 1/500 = 0.002 limit, a utilisation of **0.71**. The angular distortion is computed in consistent units: the difference in settlement in inches divided by the distance in inches, i.e. delta_s/(12 L_ft). Reporting delta_s in inches divided by L in feet would overstate the distortion by a factor of 12 and is not used. Every foundation satisfies its bearing factor of safety. The pad-level governing constraint is **BEARING** at all six pads: the reported bearing utilisation is at least 0.80 at the critical foundation on every pad (0.933-0.957), so bearing selects each pad's design under the task's acceptance test.

## 2. Governing criteria and documents reviewed and set aside

### 2.1 Documents that govern

| Document | Revision / date | Role in this design |
|---|---|---|
| UFC 3-220-01, *Geotechnical Engineering* | 1 Nov 2012, Change 3, 1 Jul 2025 | Governing geotechnical criteria: presumptive-value prohibition, minimum factors of safety (Table 2-3), design for capacity and settlement, minimum widths and depths, frost protection, reinforcement of thick footings. |
| UFC 3-220-20, *Foundations and Earth Structures* (DM 7.2) | 16 Jan 2025 | Governing foundations manual: general bearing-capacity equation (Eq. 5-15), bearing-capacity factors (Table 5-2), shape/depth factors, groundwater correction. |
| UFC 3-301-01, *Structural Engineering* | 11 Apr 2023, Change 4, 3 Jun 2025 | Concrete design to ACI CODE-318-19. |
| EM 1110-1-1905, *Bearing Capacity of Soils* | 30 Oct 1992 | Bearing-capacity equation and groundwater correction (Eq. 1-6). |
| EM 1110-2-2000, *Concrete for Civil Works Structures* | 1 Feb 1994 | Sulfate exposure-condition guide (Table 2-2). |
| EM 1110-2-2104, *Strength Design for Reinforced Concrete* | 30 Nov 2016 | Strength design and shear per ACI 318; hydraulic-structure load factors expressly not applicable. |
| EM 1110-2-2502, *Retaining and Flood Walls* | 29 Sep 1989 | Limit-equilibrium sliding procedure invoked by the load-combination memorandum. |
| FHWA GEC 13, *Ground Modification Methods*, Vol. 1 | FHWA-NHI-16-027 | Rammed aggregate pier design: stress concentration ratio, replacement ratio, two-layer settlement (Eqs. 5-11 to 5-14). |
| UFGS 03 30 00, *Cast-in-Place Concrete* | current data-room issue | Concrete exposure classes and durability limits (F, W, C, S tables). |
| AV-CR-2604 Geotechnical Data Report | Rev. 2, issued 2026-08-14 | Site stratigraphy, strength and stiffness parameters, interpolation rule, sulfate testing reference, presumptive-value warning. |
| AV-CR-2604 laboratory test summary | 2026-08-14 | Water-soluble sulfate results by pad and the rule that the more severe of the two Stratum I results governs. |
| AV-CR-2604 grading and groundwater record | 2026-08-14 | Finished grade, stabilised groundwater depths, dewatering allowance and open-cut side slopes. |
| AV-CR-2604 load combination memo | 2026-08-14 | Governing load combinations, sliding resistance, middle-third and uplift rules. |
| AV-CR-2604 Basis of Design - Structural | Rev. 3 | Occupancy classification, exposure classes, concrete rules, dimensioning, minimum thickness, cost basis. |
| Loudoun County AHJ letter LC-BD-26-0774 | 2026-08-14 | Frost-line requirement (Amendment 3) and presumptive-value prohibition (Amendment 4). |
| NOAA NCEI AFI product, 1981-2010 normals | current NCEI product | 100-year air-freezing index at station USC00444909. |
| Kettleridge Ground Systems budget proposal KGS-26-0917 | 2026-08-14 | Installed pier geometry, stiffness moduli, mobilisation and scheduling terms, unit prices, testing. |
| AV-CR-2604 bid schedule | Rev. 1 | Project budget unit prices for concrete, steel, excavation, backfill and dewatering. |
| AV-CR-2604 BIM parameter standard | Rev. 2 | Shape and rules of the two JSON parameter files. |
| AV-CR-2604 RFI log | closed RFIs through 2026-08-14 | Binding answers on bearing methods, settlement method, stress ratio, spacing, presumptive values, AFI edition, deep foundations and adjacent parcel. |

### 2.2 Documents reviewed and set aside

* **UFC 3-220-01N, *Foundation Design* (2005)** and **UFC 3-220-10N, *Soil Mechanics* (2005)** are the **cancelled predecessor volumes**. Their file names carry CANCELLED and the governing UFC 3-220-01 (2012, Change 3) and UFC 3-220-20 (2025) supersede them. They were read for background only and no requirement, factor or table from them is used.
* **AV-CR-2604 Geotechnical Addendum 1** is **superseded and withdrawn**. It reported a 4,000 psf presumptive bearing pressure; that value is not used. The Data Report Rev. 2 states: *"Revision 1 and Addendum 1 are superseded and are retained for record only."*
* **AV-CR-2604 Basis of Design, Rev. 1** is **superseded by Rev. 3**. Rev. 1 classified every building as Warehouse, assigned F0 to all concrete, permitted 1-in dimensioning and a 20-ft maximum bearing depth. Rev. 3 states: *"This revision supersedes Revision 1 of this basis of design in its entirety. Revision 1 is retained for record only."* Rev. 3 governs: the actual occupancy classes (Light Industrial/Public, Apartments/Office, Warehouse), the actual F/W/C exposure classes, 3-in dimensioning and the 15-ft maximum bearing depth.
* **NOAA NCEI AFI return periods, 1951-1980** is the **superseded edition** of the AFI product. The AHJ letter states: *"The air-freezing index shall be read from the CURRENT NCEI air-freezing-index return-period product, which is the product computed over the 1981-2010 normals period. The 1951-1980 return-period tables are the superseded edition of the same product and shall not be used for this permit."* RFI-007 confirmed the same answer. The 1951-1980 value of 416 F-days would have given a 30-in depth; it is not used.
* **Adjacent Parcel Report - Broadview Commons (2023)** is **information only**. RFI-013: *"No. Different property. Information only."* Its 5,500 psf recommendation does not apply.
* **FHWA GEC 6, *Shallow Foundations for Bridges*** is written for a different class of structure (highway bridges). It was used only as a cross-check on movement criteria and on the 1.5 sliding/overturning values; the governing UFC criteria are stricter (1/500 angular distortion and a 2.0 sliding factor of safety), and GEC 6 is not the basis of any design value.
* **EM 1110-2-2104 Table 3-1** load factors are for hydraulic structures. The load-combination memorandum states: *"The load factors of EM 1110-2-2104 Table 3-1 are for hydraulic structures and do NOT apply to this project."* They were set aside; the project load memo governs.
* **Presumptive bearing values (3,000 psf; 4,000 psf; 5,500 psf)** are rejected. The Data Report Rev. 2 states the 3,000 psf value *"is NOT a design value: it is not derived from a site-specific bearing-capacity and settlement analysis and it does not carry any factor of safety selected for this occupancy."* AHJ Amendment 4 states: *"The presumptive load-bearing values of the building code may not be used for the design of any foundation on this permit. A site-specific bearing-capacity and settlement analysis is required."* RFI-009 repeats the prohibition.
* **Deep foundations (drilled piers, driven piles)** are not used. RFI-015: *"They may be evaluated in the required foundation-type cost comparison, but the owner will not accept a deep-foundation alternative in Phase 1: no deep foundation contractor is under contract for the milestone window."*
* **The subgrade-reaction estimator** of the combined-footing/mat chapter is not the settlement method. RFI-019 states: *"The subgrade-reaction estimator of the combined-footing and mat chapter of the foundations manual is not the settlement method for isolated spread footings on this project."*
* **Proprietary vendor stress ratios** are not accepted. RFI-011: *"Use the value the governing FHWA ground-modification reference gives for structure foundation support under rigid footings. Values quoted in proprietary vendor design manuals are not accepted."*

### 2.3 Data cross-checks

The twelve boring logs were read against the Data Report Section 3 stratigraphy table; the contacts and SPT records agree, and that table was used for the station interpolation. The column-grid DXF and the base-reaction CSV were cross-checked: stations 0.0, 24.0, 44.0, 60.0, 72.0 and 77.0 ft and column sizes 24, 26, 28, 26 and 22 in agree, and the CSV service/strength reactions are the values used here. The NRCS SSURGO VA107 engineering-property data are consistent with the Data Report Section 5 index properties, and the NOAA NCEI station inventory confirms USC00444909 as the Lincoln, VA cooperative station. None of these cross-checks changes a design value.

## 3. Frost depth and bearing elevation

The County station of record is NOAA NCEI cooperative station **USC00444909 (LINCOLN, VA)**. The current 1981-2010 NCEI return-period product gives, in the 100-year column, **556 F-days**. The AHJ letter's frost table states:

> *"100-year return-period air-freezing index at the county station of record not exceeding 500 degree F-days ....... minimum depth of foundation bearing surface 30 in below finished grade / exceeding 500 degree F-days ........... minimum depth of foundation bearing surface 42 in below finished grade"*

Because 556 > 500, the applicable minimum bearing depth is **42 in below finished grade**. The superseded 1951-1980 product gives 416 F-days (which would have selected the 30-in row); it is set aside for the reasons quoted in Section 2.2. UFC 3-220-01 paragraph 2-4.8.4 requires use of the locally published frost line, which is exactly the County table. The adopted bearing depths are: **CR-P1 45 in; CR-P2 48 in; CR-P3 45 in; CR-P4 42 in; CR-P5 42 in; CR-P6 48 in**. All are multiples of 3 in, at or above the 42-in frost minimum, and below the BOD's 15-ft limit.

The finished-grade record confirms that existing grade is within 0.2 ft of finished floor elevation, so depth below finished grade equals depth below existing grade for frost and excavation. All pads bear above the stabilised groundwater (8.0, 9.0, 19.0, 8.0, 21.0 and 8.5 ft), so no construction dewatering is required (`dewatering_days = 0` on every pad).

## 4. Bearing capacity: methods, groundwater and factors of safety

### 4.1 Three methods, one reported value

UFC 3-220-01 paragraph 2-4.7.1 requires ultimate bearing capacity and settlement to be evaluated using *"a minimum of three (3) widely accepted methods of analysis."* The Data Report Rev. 2 repeats: *"The engineer of record shall establish the design bearing pressure from a site-specific analysis using not fewer than three widely accepted methods."* RFI-021 adds:

> *"Perform the three analyses and exercise engineering judgement. Report ONE net allowable bearing pressure per foundation - the value your design actually relies on - and show your work in the design basis. The reviewer will check that (a) the net applied bearing pressure does not exceed the reported allowable, and (b) the reported allowable is NOT MORE PERMISSIVE than the general bearing-capacity equation of the governing foundations manual evaluated for the same geometry, stratigraphy, groundwater condition and factor of safety. A value more conservative than that - the least of the three methods, for instance - is accepted without penalty."*

Every foundation was analysed with **Terzaghi (1943), Meyerhof (1963) and Brinch Hansen (1970)** using the general effective-stress equation of UFC 3-220-20 Eq. 5-15:

> *q_ult = c' N_c Psi_c + sigma'_zD N_q Psi_q + 0.5 gamma B N_gamma Psi_gamma*

with the bearing-capacity factors of UFC 3-220-20 Table 5-2 (at phi' = 26 deg: Terzaghi N_c = 27, N_q = 14, N_gamma = 11; Meyerhof N_c = 22, N_q = 12, N_gamma = 8.0; Brinch Hansen N_c = 22, N_q = 12, N_gamma = 7.9), the shape and depth factors of Tables 5-5, 5-6 and 5-8, and the effective-stress strength parameters of the Data Report Section 2 (Stratum I c' = 0.25 ksf, phi' = 26 deg, gamma = 118 pcf). The reported allowable is the **least of the three methods**, net of the surcharge (q_ult - sigma'_zD)/FS and rounded down to 0.1 ksf. This is conservative relative to any single method and is expressly accepted by RFI-021. Stratum I is a stiff residual silt/lean clay (SPT N60 generally 9-27, Es 85-250 ksf), so the general-shear mechanism is appropriate; no local-shear reduction was applied.

### 4.2 Factor of safety at each pad

UFC 3-220-01 Table 2-3 gives the minimum factors of safety for foundations in soil: *"Warehouse 2.5*"*, *"Apartments, Office 3.0"*, *"Light Industrial, Public 3.5"*. The BOD Rev. 3 occupancy table assigns each pad to one of those structure rows. The factors used are:

| Pad | Building | Occupancy row | FS applied |
|---|---|---|---|
| CR-P1 | Data Hall 1 | Light Industrial, Public | 3.5 |
| CR-P2 | Data Hall 2 | Light Industrial, Public | 3.5 |
| CR-P3 | Electrical Yard Building | Light Industrial, Public | 3.5 |
| CR-P4 | Administration and Operations Building | Apartments, Office | 3.0 |
| CR-P5 | Logistics and Spares Warehouse | Warehouse | **3.0** |
| CR-P6 | Data Hall 3 | Light Industrial, Public | 3.5 |

For CR-P5 the Warehouse row carries the footnote *"Use FS >3 for projects that require extreme limitations on total and differential movements such as super-flat warehouse floors that are needed to accommodate modern transport equipment."* The BOD does not identify a super-flat floor requirement for the Logistics and Spares Warehouse (it identifies only the exterior loading apron and the consequent F3 exposure). Because the footnote's threshold is ">3", the design adopts **FS = 3.0** at CR-P5 rather than the table minimum 2.5. This is the stricter reading of the footnote, eliminates the 20% capacity ambiguity that a 2.5 allowable would create, and is still above the table's 2.5 minimum. The reported allowable values at CR-P5 are therefore at FS = 3.0 and the maximum reported bearing utilisation is 0.937.

### 4.3 Groundwater correction

UFC 3-220-20 states: *"Groundwater correction is required when the groundwater table is higher than one footing width below the bearing elevation. Groundwater correction is only required for drained (effective stress) analysis."* Where applicable, the average effective unit weight in the failure zone was computed by EM 1110-1-1905 Eq. 1-6:

> *gamma'_H = gamma_sub + [(D_GWT - D)/H] gamma_w*, with *H = B tan(45 deg + phi'/2)* and *gamma_sub = gamma_total - 62.4 pcf*.

The Data Report Section 2 requires the submerged unit weight to be taken as total less 62.4 pcf. The stabilised groundwater depths are 8.0 ft (P1), 9.0 ft (P2), 19.0 ft (P3), 8.0 ft (P4), 21.0 ft (P5), and 8.5 ft (P6) below finished grade (Civil grading and groundwater record Section 2). The correction is active at P1, P2, P4 and P6, where the water table lies within one footing width of the base. At P3 and P5 the stabilised water table (19.0 ft and 21.0 ft) is below D + B for every adopted footing (the largest D + B is 18.5 ft at CR-P3 F3), so no correction is required and total unit weights are used. The correction reduces, never increases, the computed capacity; the reported allowable values at P1, P2, P4 and P6 already include it.

### 4.4 Bearing stratum

The Data Report Section 4 requires the base of Stratum I to be interpolated **linearly between the two borings of the pad using the foundation station**, rounded to 0.1 ft, with no extrapolation outside the boring interval. The two borings of every pad are at the first and last foundation stations (0.0 and 77.0 ft), so every Phase 1 foundation lies between them and interpolation governs. The resulting Stratum I bases (ft) are:

| Pad | F1 | F2 | F3 | F4 | F5 | W1 |
|---|---|---|---|---|---|---|
| CR-P1 | 6.0 | 8.0 | 9.7 | 11.1 | 12.1 | 12.5 |
| CR-P2 | 13.5 | 12.1 | 10.9 | 10.0 | 9.3 | 9.0 |
| CR-P3 | 5.5 | 6.0 | 6.4 | 6.7 | 6.9 | 7.0 |
| CR-P4 | 6.0 | 7.1 | 8.0 | 8.7 | 9.3 | 9.5 |
| CR-P5 | 4.5 | 4.8 | 5.1 | 5.3 | 5.4 | 5.5 |
| CR-P6 | 14.0 | 11.7 | 9.7 | 8.2 | 7.0 | 6.5 |

The adopted bearing depths put **all six pads in Stratum I** (the residual silt/lean clay). The declared `bearing_stratum` in the parameter file is therefore "I" for every foundation at every pad. The deepest bearing surface is 48 in (4.0 ft), and the shallowest Stratum I base is 4.5 ft (CR-P5 F1), so no foundation penetrates the Stratum I contact.

A deep Stratum II alternative was evaluated for CR-P3 and CR-P5. It removes the compressible residual clay from the influence zone and reduces settlement, but it requires excavation of 7.0-7.5 ft at P3 and 6.0 ft at P5, and with the civil 1.5H:1V side slope below 4 ft it is more expensive than the adopted shallow scheme at both pads. The selected designs therefore remain in Stratum I; the Stratum II properties (c' = 0, phi' = 33 deg, gamma = 126 pcf, Es = 1700/1800 ksf) are used only for the alternative pricing, not for the selected bearing check.

## 5. Settlement method and tolerable-movement criteria

### 5.1 Method applied

RFI-019 is the governing instruction on settlement. It states, in full:

> *"Apply LAYERED ELASTIC COMPRESSION: divide the soil below the bearing surface into layers, compute the net stress increment in each layer with the 2 vertical to 1 horizontal approximate stress distribution for a rectangular loaded area, and sum the layer compressions s = (delta sigma)(H)/Es using the pad-specific elastic moduli of the geotechnical data report. This is the method the governing FHWA ground-modification reference states as Equation 5-14, and using it for the unimproved case keeps the improved and unimproved cases consistent, because the lower-zone term of the two-layer aggregate-pier method is the same equation. Carry the compression integral to a depth of four times the footing width below the bearing surface, and in no case less than 40 ft. Subdivide that depth into UNIFORM LAYERS 0.25 ft THICK and take the stress increment at the mid-height of each layer; that discretisation is fine enough that the computed compression is stable to better than one per cent. The subgrade-reaction estimator of the combined-footing and mat chapter of the foundations manual is not the settlement method for isolated spread footings on this project."*

The calculation applied is therefore:

* net applied pressure q = P_service/(B L), with P_service the D + L base reaction;
* 2V:1H stress increment delta_sigma(z) = q B L / [(B+z)(L+z)] for a rectangular loaded area;
* layers 0.25 ft thick from the bearing surface to max(4B, 40 ft);
* Es taken at the mid-height of each layer from the pad-specific Data Report values (Stratum I 85-250 ksf; Stratum II 1400-1800 ksf; Stratum III 1700-3800 ksf);
* s = sum(delta_sigma H / Es), with H = 0.25 ft.

For improved footings the FHWA GEC 13 two-layer method is used (Eqs. 5-11 to 5-14): total settlement s_tot = s_uz + s_lz; upper-zone settlement s_uz = q_g/k_g (Eq. 5-13); lower-zone settlement from the bottom of the treated zone to the same max(4B, 40 ft) depth by the same 2V:1H layered compression (Eq. 5-14). The top-of-pier stress is

> **q_g = q n_s / (n_s R_a - R_a + 1)** (FHWA GEC 13 Eq. 5-12)

with n_s = 10 and the actual footing area replacement ratio. The settlement calculation uses the net applied pressure q = P/(B L); the top-of-pier stress reported in the parameter file, schedule and matrix is the **gross** value including the footing self-weight, (P + W_f)/(B L), which is conservative for the 18,000 psf limit. The pad-specific stiffness moduli k_g are the Kettleridge Section 3 design values (P1 165, P2 140, P4 195, P6 155 pci). Treatment depths of 8-9 ft were selected; at P1, P2 and P6 they reach or pass the Stratum I base so the lower zone is the stiff sand, not the residual clay.

### 5.2 Tolerable movement adopted

UFC 3-220-01 paragraph 2-4.7.1 states:

> *"Unless approved by the building official, total post construction settlement may not exceed tolerable limits based on building type and dimension, or 25.4 mm (1 in.), whichever is less. Differential settlements shall not result in an angular distortion in excess of 1/500. The angular distortion is defined as the difference in settlement between two points divided by the distance between the points."*

The adopted criteria are therefore **total settlement <= 1.0 in** and **angular distortion between adjacent foundation units <= 1/500 = 0.002**, with the angular distortion computed in consistent units as delta_s/(12 L_ft) for settlements in inches and bay lengths in feet. The predicted maximum total settlement is **0.880 in** (CR-P2 F3), and the predicted maximum angular distortion is **0.001417** (CR-P6 F5-W1), a utilisation of **0.71** of the limit. Every pad's maximum total settlement and maximum angular distortion are reported in the feasibility matrix. The design was proportioned so that no bay exceeds 0.0015 dimensionless angular distortion (75% of the 1/500 limit), leaving a 25% reserve for construction tolerance and for any difference in the settlement arithmetic.

### 5.3 Competing criterion rejected

FHWA GEC 6 (a bridge-shallow-foundation manual for a different class of structure) suggests *"total settlements are on the order of 25 mm (1 in) and differential settlements about half the total settlement"* and quotes 1/300 for masonry and 0.004-0.005 for bridges. Those are not adopted. The governing UFC criterion is the stricter **1/500 angular distortion** and the **1-in total settlement**; GEC 6's "about half the total" would permit a 0.44-in differential between CR-P2 F3 (0.880 in) and its neighbour; that is below the 1/500 limit over the 20-ft bay (0.002 x 20 x 12 = 0.48 in) but exceeds the 1/500 limit over the 12-ft bay (0.288 in), and it is not a code limit. The UFC 1/500 criterion therefore governs at every bay. The UFC criterion was applied exactly. The 1-in total settlement limit is from UFC 3-220-01 paragraph 2-4.7.1, not from the BOD; the BOD contains no settlement limit. No building-official approval of a larger movement was sought or assumed.

## 6. Structural design of the footings

Concrete design follows ACI CODE-318-19 as invoked by UFC 3-301-01 Section 2-7 and EM 1110-2-2104 Section 5.1. The load-combination memorandum assigns:

* **1.2D + 1.6L (STRENGTH_1.2D_1.6L)** for footing one-way shear, two-way (punching) shear and flexure;
* **D + L (SERVICE_D_PLUS_L)** for net allowable bearing and settlement;
* **0.6D + W** for sliding and net uplift of the shear-wall footing;
* **D + L + W** for the location of the resultant (overturning).

The factored soil pressure used for shear and flexure is q_u = (P_u + 1.2 W_footing)/(B L), where W_footing is the footing self-weight at 150 pcf. One-way shear is checked at d from the column or wall face; two-way shear is checked on the critical perimeter at d/2 from the column face. The strength-reduction factor is phi = 0.75 for shear and phi = 0.90 for flexure. The design was iterated so that the shear utilisation does not exceed **0.95** (a 5% reserve); the maximum reported shear utilisation is 0.949. The effective depth is d = t - 4 in, per BOD Rev. 3 Section 3 (3-in cover plus one bar diameter).

Flexural steel is designed at the column or wall face for the factored moment, with f_y = 60,000 psi. The project minimum ratio is **0.0018** in each direction (BOD Rev. 3 Section 3). For footings over 3 ft thick, UFC 3-220-01 Section 2-4.7.7 requires a minimum ratio of 0.0015 with No. 4 bars or larger at no more than 12 in, and adds:

> *"For footings over 0.914 m (3 ft) thick, the minimum ratio of reinforcement area to gross concrete area in each direction shall be 0.0015, with not less than one-half nor more than two-thirds of the total reinforcement required placed in any one face."*

The stricter project minimum 0.0018 total is applied everywhere. For the six footings thicker than 36 in (CR-P1 F2 and F3; CR-P2 F2 and F3; CR-P6 F2 and F3), the reported `reinforcement_ratio` is the **total** ratio in each direction, and the reinforcement is split **two-thirds in the bottom face and one-third in the top face**, so the 2/3 limit is satisfied. The bar size and spacing in the schedule are the bottom mat, which carries the full flexural As required; the top mat is detailed in the construction documents. For footings 36 in thick or less, the reported ratio is the bottom-mat ratio and no top mat is required. All reported ratios are at or above 0.0018; the provided bar size is No. 5 to No. 11 and the spacing is 12 in or less.

For the shear-wall footing W1, the main bars run transversely across the 177-180 in width and are distributed along the 288-in wall length. The reported ratio is the total transverse steel divided by the gross section **L x t = 288 x t**, which is the section width for the transverse bars; the bar schedule provides the required As (for example CR-P1 W1: As required 29.7 in2, at least 30.0 in2 provided). The longitudinal direction carries the 0.0018 minimum. The reported W1 ratios are therefore not referred to the short plan width; referring them to B x t would overstate the steel by L/B and is not the project convention.

No footing is thinner than **12 in** (BOD Rev. 3 Section 4); the thinnest used is 18 in (CR-P5 F1, F5 and W1). All plan dimensions and thicknesses are multiples of 3 in, and all bearing depths are multiples of 3 in.

### 6.1 Shear-wall footing stability

Each pad's W1 is a 24-ft-long, 12-in-thick shear-wall footing. The stability checks use the loads of the load-combination memorandum and the procedures of EM 1110-2-2502:

* **Sliding (0.6D + W):** base friction is tan(delta) = tan(2 phi'/3) = tan(17.3 deg) = 0.312 using the weaker Stratum I phi' = 26 deg at every pad, giving FS = 0.312 P_0.6D/W / H. The ratio is 2.23 at every pad (P1: 0.312 x 708/96 = 2.30; the minimum is 2.23 where H/P is highest). The load memo permits base friction plus not more than half the passive resistance; **no passive resistance is credited**, so the reported FS is conservative. UFC 3-220-01 Section 2-4.6.3 requires FS >= 2.0; 2.23 satisfies it with an 11% reserve. (FHWA GEC 6's 1.5 is a bridge/building cross-check only and is not the governing value.)
* **Overturning/resultant location (D + L + W):** e = M/P = 6.4 in at every pad. The W1 footings are 96-180 in wide (B/6 = 16.0-30.0 in) and 288 in long (L/6 = 48 in), so the resultant is within the middle third in both directions.
* **Uplift (0.6D + W):** the resistance is 0.6 x the unfactored dead load, ignoring footing and soil credit, giving FS = 0.6 x dead load / net uplift = **2.72** at every pad. The load memo permits credit for the footing self-weight and soil above the projection; omitting that credit is conservative. The 2.72 exceeds the 1.5 cross-check value and is reported as `uplift_fs`.
* **Bearing under D + L + W (added check):** the load memo assigns D + L + W to the location of the resultant, not to the allowable bearing pressure. Because IBC 1605.3.1 permits a one-third increase in allowable stress for wind combinations, the D + L + W toe pressure q_max = (P/A)(1 + 6e/B) was also checked against (4/3) q_allow. The worst case is CR-P5 W1 at 6.62 ksf against 7.07 ksf (0.94 of the increased allowable), and CR-P4 W1 at 6.30 ksf against 6.93 ksf (0.91); every pad passes. This check is additional to, not a replacement for, the D + L allowable check.

## 7. Concrete durability and sulfate exposure

The sulfate exposure condition is **not** assigned in the BOD. BOD Rev. 3 Section 2 states: *"The SULFATE exposure class is NOT assigned here: it must be established from the measured water-soluble sulfate concentration of the Stratum I soils at each pad."* The laboratory summary requires the more severe of the two Stratum I results per pad. The design values and the resulting classes are:

| Pad | Max SO4 (%) | EM 1110-2-2000 Table 2-2 condition | UFGS 03 30 00 sulfate class |
|---|---|---|---|
| CR-P1 | 0.14 | Moderate (0.10-0.20) | S1 |
| CR-P2 | 0.23 | Severe (>0.20) | S2 |
| CR-P3 | 0.07 | Negligible (<0.10) | S0 |
| CR-P4 | 0.11 | Moderate (0.10-0.20) | S1 |
| CR-P5 | 0.05 | Negligible (<0.10) | S0 |
| CR-P6 | 0.26 | Severe (>0.20) | S2 |

The concrete exposure classes assigned by the BOD are F1/W1/C1 for P1, P2, P3, P4 and P6, and **F3**/W1/C1 for P5 (the warehouse apron is exposed to de-icing chemicals). The applicable UFGS 03 30 00 limits are:

| Class | Max w/cm | Min f'c (psi) |
|---|---|---|
| F1 | 0.55 | 3500 |
| F3 | 0.40 | 5000 |
| W1 | 0.50 | 4000 |
| C1 | N/A | 2500 (plus 0.30 % max Cl-) |
| S0 | N/A | 2500 |
| S1 | 0.50 | 4000 |
| S2 | 0.45 | 4500 |

The most restrictive combination governs each pad: **CR-P1, CR-P3 and CR-P4: w/cm 0.50, f'c 4000 psi** (S1 or W1 governs); **CR-P2 and CR-P6: w/cm 0.45, f'c 4500 psi** (S2 governs); **CR-P5: w/cm 0.40, f'c 5000 psi** (F3 governs). The S1 concrete uses Type II or MS cement and the S2 concrete uses Type V or HS cement, with the UFGS 03 30 00 Section 2.5.2.4 restrictions (calcium chloride is not permitted for S2). Concrete assigned F1 or F3 is air-entrained in accordance with UFGS 03 30 00 Section 2.5.2.2. The BOD requires the *"lowest listed strength that satisfies both durability and structural demand"*; the bid schedule offers 3000, 4000, 4500 and 5000 psi. The selected strengths are exactly the four durability minima (4000, 4500, 5000) and no higher strength was specified.

## 8. Ground-improvement design parameters

The rammed aggregate pier (RAP) design uses the FHWA GEC 13 method, not a proprietary vendor method. The parameters and their authority are:

| Parameter | Adopted value | Authority |
|---|---|---|
| Stress concentration ratio, n_s | **10.0** | FHWA GEC 13 Section 4.2.1: *"For structure foundation support under rigid footings a somewhat higher stress ratio (10) may be considered"*. RFI-011 requires the FHWA value and rejects vendor values. |
| Minimum area replacement ratio, R_a | **0.33** | FHWA GEC 13 Section 4.2.2: *"A minimum replacement ratio of 0.33 is generally recommended, as noted in the HITEC Evaluation Report (Collin 2007)."* Every improved footing has R_a >= 0.3377. |
| Pier diameter | **30 in** | Kettleridge Section 2: *"Pier diameter (as installed by our rig) 30 in"*. |
| Minimum clear spacing | **1.0 ft** | Kettleridge Section 2: *"Minimum clear spacing between adjacent piers 1.0 ft"*; this fixes the maximum geometric R_a (0.46 for a staggered grid). |
| Pier layout | Square or staggered grid | Kettleridge Section 2 permits either; the staggered grid is used where R_a exceeds the square-grid unit-cell value, and the minimum clear spacing is maintained. |
| Minimum treatment depth | **8 ft** below footing soffit | Kettleridge Section 2. |
| Maximum treatment depth | **25 ft** below footing soffit | Kettleridge Section 2. Adopted depths are 8-9 ft, all within the range. |
| Maximum top-of-pier stress | **18,000 psf** | Kettleridge Section 2: *"Maximum design top-of-pier stress 18000 psf"*. The maximum computed gross stress is 14,934 psf, a 17% reserve. |
| Stiffness modulus, k_g | P1 165, P2 140, P4 195, P6 155 pci | Kettleridge Section 3 as-tested design values for the matrix soils of each pad. |
| Top-of-pier stress equation | q_g = q n_s/(n_s R_a - R_a + 1) | FHWA GEC 13 Eq. 5-12. |
| Upper-zone settlement | s_uz = q_g/k_g | FHWA GEC 13 Eq. 5-13. |
| Lower-zone settlement | Layered elastic compression from the treatment depth, same Eq. 5-14 | FHWA GEC 13 Eq. 5-14 and RFI-019. |
| Verification testing | 1 production modulus test per improved pad | Kettleridge Section 5: *"One production modulus test is required per improved building pad."* |
| Mobilisation | $40,000 per rig; at most 2 pads per rig | Kettleridge Section 4. |
| Pier price | $28.00 per vertical foot | Kettleridge Section 5. |
| Working platform | $2.40 per SY of improved footing plan area | Kettleridge Section 5. |
| Production test price | $9,500 each | Kettleridge Section 5. |

The area replacement ratio is R_a = n A_p/A, where n is the whole number of 30-in piers under the footing, A_p = 0.7854 x (2.5 ft)^2 = 4.909 ft^2, and A is the footing plan area. For each improved footing the number of piers is the smallest whole number that satisfies R_a >= 0.335 (a 1.5% margin over the 0.33 minimum), increased where necessary to meet the top-of-pier stress and settlement limits. The minimum reported R_a is 0.3377 and the maximum is 0.4086, both within the staggered-grid geometric limit of 0.46 fixed by the 1.0-ft minimum clear spacing. The pier count, diameter, depth, R_a and top-of-pier stress for every improved foundation are in `foundation_geometry.json` and the schedule.

The improved pads and their pier quantities are:

| Pad | k_g (pci) | Deepest treatment (ft) | Total pier LF | Piers |
|---|---|---|---|---|
| CR-P1 | 165 | 9 | 761 | F1 9x8, F2 16x8, F3 20x8, F4 14x8, F5 8x8, W1 25x9 |
| CR-P2 | 140 | 9 | 769 | F1 9x9, F2 17x8, F3 20x8, F4 14x8, F5 8x8, W1 27x8 |
| CR-P4 | 195 | 8 | 440 | F1 5x8, F2 10x8, F3 11x8, F4 8x8, F5 5x8, W1 16x8 |
| CR-P6 | 155 | 9 | 753 | F1 9x9, F2 16x8, F3 20x8, F4 14x8, F5 8x8, W1 26x8 |

All six foundations at each improved pad are on rammed aggregate piers. CR-P6 F5 is improved (123 x 123 x 27 in, 8 piers x 8 ft), not left as a large spread footing: the improved scheme is cheaper ($5,780 vs about $10,600 for the 201-in spread footing that would be needed to match the adjacent settlements) and the rig is already on CR-P6. The working platform is measured only over the improved footings, as Kettleridge Section 5 requires. One production modulus test is included for each improved pad.

## 9. Conflicts between documents and their resolution

| No. | Conflict | Documents | Governing resolution |
|---|---|---|---|
| 1 | Frost depth 30 in vs 42 in | AHJ letter Amendment 3; NOAA 1981-2010 vs 1951-1980 | Current 1981-2010 product gives 556 F-days > 500 -> **42 in**. The 1951-1980 416 F-days is superseded and not used. RFI-007 confirms. |
| 2 | AFI edition | AHJ Amendment 3; RFI-007 | **1981-2010** current product governs; 1951-1980 superseded. |
| 3 | Presumptive bearing 3,000 psf vs site-specific | Geotech Data Report Section 7; AHJ Amendment 4; RFI-009; UFC 3-220-01 2-4.5.2/2-4.6.4 | **Site-specific three-method analysis** governs; 3,000 psf rejected. |
| 4 | Presumptive bearing 4,000 psf vs 3,000 psf vs 5,500 psf | Addendum 1 (superseded); Data Report (preliminary); Adjacent parcel (information only) | None is a design value. **Site-specific analysis** governs; all three rejected. |
| 5 | Occupancy/exposure classes | BOD Rev. 1 (all Warehouse/F0) vs BOD Rev. 3 | **Rev. 3** governs: P1/P2/P3/P6 Light Industrial/Public; P4 Apartments/Office; P5 Warehouse; F1 except P5 F3; W1, C1. |
| 6 | Dimensioning and maximum depth | BOD Rev. 1 (1-in grid, 20 ft) vs BOD Rev. 3 (3-in grid, 15 ft) | **Rev. 3** governs: 3-in grid, 15-ft maximum. |
| 7 | Settlement method | RFI-019 vs EM 1110-1-1904/DM 7.1 (not in data room or cancelled) | **Layered elastic compression, 2V:1H, 0.25-ft layers, max(4B,40 ft)** per RFI-019. The subgrade-reaction estimator is rejected. |
| 8 | Bearing-capacity design value among three methods | UFC 3-220-01 2-4.7.1; RFI-021 | Report **one** value; use the **least of Terzaghi, Meyerhof and Brinch Hansen** (conservative, accepted by RFI-021). |
| 9 | Aggregate-pier stress ratio | FHWA GEC 13 vs proprietary vendor manuals | **n_s = 10** per FHWA GEC 13 and RFI-011; vendor values rejected. |
| 10 | Minimum area replacement ratio | FHWA GEC 13 Section 4.2.2; Kettleridge geometry | **R_a >= 0.33**; adopted minimum 0.3377; geometric maximum 0.46 from 1.0-ft clear spacing. |
| 11 | Footing spacing 1.5B | UFC 3-220-01 2-4.8.1 vs RFI-017 | RFI-017: the 1.5B provision is a **preliminary-sizing guideline**; size and price individual units, no overlap reduction. |
| 12 | Sliding FS 2.0 vs 1.5 | UFC 3-220-01 2-4.6.3 vs FHWA GEC 6 Section 8.5 | **2.0** governs (stricter). Reported FS 2.23 without passive credit. |
| 13 | Overturning: middle third vs FS 1.5 | Load memo Section 3 vs FHWA GEC 6 Section 8.4 | **Middle third** per the load memo; e = 6.4 in is within B/6 and L/6. FS 1.5 is a cross-check. |
| 14 | Load factors | EM 1110-2-2104 Table 3-1 (hydraulic) vs Load memo Section 2 | **Project load memo** governs; hydraulic factors expressly do not apply. |
| 15 | Minimum reinforcement ratio and thick-footing distribution | BOD 0.0018 vs UFC 2-4.7.7 0.0015 and 2/3 rule | **0.0018 total** governs (stricter); thick footings split 2/3 bottom and 1/3 top, satisfying the 2/3 rule; No. 5 or larger at <=12 in. |
| 16 | Sulfate exposure class | Lab summary vs BOD (BOD does not assign S) | Lab maximum per pad + EM 1110-2-2000 Table 2-2 + UFGS 03 30 00; **S1/S2/S0** as tabulated in Section 7. |
| 17 | Deep-foundation alternative | RFI-015 vs generic foundation-type comparison | **Not accepted in Phase 1**; only spread and RAP schemes priced. |
| 18 | Adjacent parcel data | Broadview Commons report vs project geotech | **Not applicable**; different property, information only. |
| 19 | Warehouse FS 2.5 vs "Use FS >3" footnote | UFC 3-220-01 Table 2-3 and its note; BOD Rev. 3 | **FS = 3.0** adopted at CR-P5: the BOD does not establish a super-flat floor, but 3.0 is the stricter reading of the ">3" note and removes the 20% capacity ambiguity. |
| 20 | Angular distortion units | UFC 3-220-01 2-4.7.1; prior in/ft arithmetic | Angular distortion is **dimensionless**: delta_s divided by the distance in the same units. The design uses delta_s/(12 L_ft) and compares with 1/500 = 0.002. The in/ft ratio is 12 times larger and is not used. |
| 21 | Top-of-pier stress net vs gross | FHWA GEC 13 Eq. 5-12; Kettleridge limit | Settlement uses net q; the reported and checked top-of-pier stress is **gross** (includes footing self-weight), which is conservative. The maximum gross q_g is 14,934 psf < 18,000 psf. |
| 22 | D + L + W bearing check | Load memo Section 2 vs IBC 1605.3.1 | D + L governs the allowable; D + L + W is checked for resultant location and, additionally, for toe bearing with the IBC one-third wind increase. All six W1 footings pass. |

## 10. Campus programme and cost optimisation

### 10.1 Alternatives priced for each pad

For every pad, both alternatives were designed to the same criteria and priced at the project unit prices. The "spread-only" alternative is an all-spread scheme that satisfies bearing, minimum width, shear, frost and the movement limits; where a shallow all-spread scheme cannot meet settlement, the least-cost all-spread alternative is a deep scheme bearing below the compressible Stratum I, and its (higher) cost is reported. The "improved" alternative is an all-foundation RAP scheme including the per-pad production test. The adopted decision is the cheaper compliant scheme at each pad.

| Pad | Spread-only cost | Improved cost | Decision | Reason |
|---|---|---|---|---|
| CR-P1 | $532,227 | **$88,034** | IMPROVED_SPREAD | Stratum I is 6.0-12.5 ft thick and soft (Es 110 ksf); a compliant all-spread scheme requires deep founding and very large footings, far more expensive than piers. |
| CR-P2 | $410,781 | **$94,441** | IMPROVED_SPREAD | Stratum I is 9.0-13.5 ft thick with Es 85 ksf; an all-spread scheme is far more expensive than piers. |
| CR-P3 | **$36,333** | $57,345 | SPREAD | Stratum I is only 5.5-7.0 ft thick; the shallow spread scheme at 45 in satisfies settlement and angular distortion and is cheaper than the all-improved scheme. |
| CR-P4 | $69,170 | **$47,790** | IMPROVED_SPREAD | Piers under the interior footings are cheaper than the large spread footings needed to control settlement, and the pad fits the second rig with no additional mobilisation. |
| CR-P5 | **$22,509** | $42,925 | SPREAD | Stratum I is only 4.5-5.5 ft thick; the shallow spread scheme at the 42-in frost minimum is the least-cost compliant scheme. |
| CR-P6 | $194,054 | **$90,992** | IMPROVED_SPREAD | Stratum I is 6.5-14.0 ft thick with Es 95 ksf; piers are much cheaper than an all-spread scheme with very large footings. |

The costs in this table are the **pad-level construction costs** (concrete, reinforcement, excavation, backfill, piers, working platform and the per-pad production test where improved). They exclude the campus rig mobilisation, which is added once in the campus total.

### 10.2 Rig programme

Kettleridge Section 4 states: *"Each mobilised rig can serve AT MOST 2 building pads within the Phase 1 milestone window. If more pads are to be improved than the mobilised rigs can serve in that window, an additional rig must be mobilised and paid for. Mobilisation is a lump sum per rig and is not prorated."*

Four pads are improved (P1, P2, P4 and P6). Two rigs are therefore mobilised: **RIG-1 serves CR-P1 and CR-P2; RIG-2 serves CR-P4 and CR-P6**. The mobilisation cost is 2 x $40,000 = **$80,000**. One production modulus test is required and priced for each improved pad; the plan reports one test per improved pad.

The campus programme was selected by comparing all subsets of the six pads at the priced alternatives and adding the correct number of rigs, ceil(k/2), for k improved pads:

* P1, P2 and P6 must be improved because their spread-only alternatives are deep and far more expensive; three improved pads already require two rigs.
* P4 is improved because its improved cost ($47,790) is lower than its spread-only cost ($69,170) and it fits on the second rig with no additional mobilisation.
* P3 and P5 are not improved. Their all-improved alternatives ($57,345 and $42,925) are more expensive than their all-spread schemes ($36,333 and $22,509), and adding either would require a third rig (+$40,000) because both rigs are already committed to P1, P2, P4 and P6. The direct saving does not justify the third mobilisation.

### 10.3 Cost total

| Item | Amount |
|---|---|
| CR-P1 (improved, incl. $9,500 test) | $88,034 |
| CR-P2 (improved, incl. $9,500 test) | $94,441 |
| CR-P3 (shallow spread) | $36,333 |
| CR-P4 (improved, incl. $9,500 test) | $47,790 |
| CR-P5 (shallow spread) | $22,509 |
| CR-P6 (improved, incl. $9,500 test) | $90,992 |
| Rig mobilisation (2 x $40,000) | $80,000 |
| **Campus total** | **$460,100** |

The cost build-up uses the bid schedule Rev. 1 prices: concrete at $196/$211/$228 per CY for 4000/4500/5000 psi; reinforcement at $1.42/lb with the pay quantity = 2 x ratio x gross footing volume x 490 pcf; excavation at $38/CY to the neat prism (vertical sides because all adopted depths are <=4 ft, with 1 ft working room each side); backfill at $46/CY = excavation less concrete; dewatering at $4,200/day but zero days on every pad because all bearing surfaces are above the stabilised groundwater. The RAP prices are $28/LF, $2.40/SY of improved footing plan area, $9,500 per production test, and $40,000 per rig.

## 11. Pad-by-pad summary

| Pad | Bearing depth (in) | Bearing stratum | FS | Decision | Max settlement (in) | Max angular distortion | Max q_net/q_allow | Pad cost |
|---|---|---|---|---|---|---|---|---|
| CR-P1 | 45 | I | 3.5 | IMPROVED_SPREAD | 0.738 | 0.001083 | 0.957 | $88,034 |
| CR-P2 | 48 | I | 3.5 | IMPROVED_SPREAD | 0.880 | 0.001350 | 0.947 | $94,441 |
| CR-P3 | 45 | I | 3.5 | SPREAD | 0.879 | 0.000917 | 0.933 | $36,333 |
| CR-P4 | 42 | I | 3.0 | IMPROVED_SPREAD | 0.660 | 0.000767 | 0.957 | $47,790 |
| CR-P5 | 42 | I | 3.0 | SPREAD | 0.646 | 0.000833 | 0.937 | $22,509 |
| CR-P6 | 48 | I | 3.5 | IMPROVED_SPREAD | 0.832 | 0.001417 | 0.952 | $90,992 |

The controlling foundation, the demand, the bearing check, the settlement, the angular distortion, the W1 stability checks (sliding, eccentricity, uplift and the D + L + W toe check) and the costs of both alternatives are tabulated for every foundation in `foundation_feasibility_matrix.md`. The parameter file and the schedule are generated from the same design table; every B, L, thickness, bearing depth, bar size, bar spacing, pier count, pier depth, area replacement ratio and settlement value agrees between them.

## 12. Assumptions, limitations and verification

* The design uses the service D + L reactions for bearing and settlement and the 1.2D + 1.6L reactions for shear and flexure, exactly as the load-combination memorandum directs. The wind reactions are used for the W1 sliding, overturning, uplift and D + L + W toe checks.
* The net bearing pressure is taken as the column service load divided by the footing plan area. The footing self-weight replaces excavated soil at the same elevation; including it in the net bearing pressure would be double counting. The footing self-weight is included in the factored shear and flexure pressure at 1.2 times 150 pcf, and in the reported gross top-of-pier stress.
* The settlement analysis uses the net pressure and the pad-specific Es values. The 0.25-ft layer discretisation was checked for stability by halving the layer thickness on representative foundations; the change was less than 1%, as RFI-019 states.
* The bearing-capacity analysis uses the properties of the stratum at the bearing elevation for the whole failure zone. All selected footings bear in Stratum I; where a Stratum I footing's failure zone passes into the stronger Stratum II, using Stratum I properties is conservative, and Stratum III is stronger still and is not credited.
* The W1 sliding check deliberately takes no passive-resistance credit. The reported FS = 2.23 therefore has additional reserve against the 2.0 requirement.
* The W1 uplift check deliberately takes no credit for the footing self-weight or the soil above the footing projection. The reported FS = 2.72 therefore has additional reserve.
* The design is a Phase 1 foundation-strategy package. Where the 1.5B footing-spacing guideline is not achieved (RFI-017), the affected foundations are to be detailed as combined footings in the construction documents; for this strategy study they are sized, scheduled and priced as individual units with no overlap reduction, as RFI-017 directs.
* No deep foundation, no presumptive bearing value, no cancelled or superseded criterion and no adjacent-parcel data is used anywhere in the design.

**Items requiring action by others before construction:** (1) the construction documents must detail the closely spaced footings as combined footings where the 1.5B guideline is not achieved, as RFI-017 directs; (2) the contractor must submit concrete mixes demonstrating the S1/S2 cement types, F1/F3 air entrainment and the F3 cementitious-material limits; (3) the specialty subcontractor must perform and submit one production modulus test for each improved pad (CR-P1, CR-P2, CR-P4, CR-P6); (4) the contractor must proof-roll and verify the bearing stratum at each footing excavation before placing concrete, in accordance with UFGS 31 00 00 Section 3.3.3; (5) the top reinforcement mat required for the six footings over 3 ft thick must be shown on the construction documents; and (6) no building-official approval of a reduced factor of safety, a larger movement or a presumptive bearing value is required or assumed.
* **Expansive-soil screening:** the Stratum I CL-ML has PI 14-18 and 60-67% passing the #200 sieve. Several samples are at or slightly above the IBC PI = 15 screening threshold; no swell test is in the data room. The footings bear at 42-48 in, at or below the 42-in frost depth, which reduces but does not eliminate moisture-driven volume change. The geotechnical engineer should confirm swell potential, and the slab-on-grade should be detailed for moisture control in accordance with UFC 3-220-01 Section 2-4.7.4.2. This is a slab/construction-phase item and does not change the footing bearing or settlement design, which is governed by the drained strength and elastic compression of the same stratum.
* **Seasonal groundwater:** the civil record reports 30-day stabilised design depths and an observed +/-1 ft seasonal variation. The analyses use the design depths. A 1-ft rise was checked: every reported allowable pressure remains at or above the recalculated value, and the minimum bearing factor of safety remains above its required value, so no minimum factor of safety is violated.
* **Pier installation below groundwater:** the RAP depths at CR-P1, CR-P2 and CR-P6 extend below the stabilised water table. The Kettleridge installed-per-foot price covers the pier installation means and methods; the bid schedule's per-day dewatering item is for the footing excavation, which is above groundwater at every pad, so `dewatering_days = 0`.

**Verification:** the deliverables were checked by re-reading the JSON and XLSX files and recomputing, from the submitted geometry, the net bearing pressure, the allowable bearing pressure, the settlement, the angular distortion in consistent units, the shear thickness, the reinforcement ratio and area, the pier replacement ratio, the top-of-pier stress, the treatment depth, the pier quantities, the sliding/overturning/uplift factors, the D + L + W toe pressure, the pad costs and the campus total. The recomputed values agree with the reported values; the maximum total settlement is below 1.0 in, the maximum angular distortion is below 1/500, and every bearing, sliding, overturning and uplift factor of safety is above its minimum.

**Conclusion:** the Phase 1 foundation programme is feasible and compliant at every one of the 36 foundations; no hard requirement blocks it, and the adopted programme is the least-cost compliant programme among the alternatives priced.
