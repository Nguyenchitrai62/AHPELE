# Conveyance Study - 13.8 kV Site Distribution

**Project:** Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California - PCSFA 24-0117

**Solicitation:** FA4610-26-R-0031, Section 01 11 00 Summary of Work: Conveyance Study, Amendment 0002 (2026-08-28)

**Study date:** 2026-09-15  |  **Bid opening:** 2026-10-08  |  **Construction:** 2027-01-04 to 2028-04-03 (15 months), midpoint 2027-08-18

**Route plan:** route_plan.svg (site coordinates in the C-101 frame; solid = CEDB/RMC, dashed = JB/HDD, squares = manholes/pull boxes).

## 1. Executive summary

Seven medium-voltage circuits were studied. The governing criteria (PCSFA-IEDS Rev 3, UFC 3-550-01, UFC 3-520-01, UFGS 33 71 02 and UFGS 26 20 00) permit concrete-encased ductbank (CEDB) for all six site circuits and for the underground risers of C06, overhead (OH) for C06 outside the C-101 industrial area (IEDS 4.1), and rigid metal conduit (RMC) for the in-building circuit C05. UEDB and DBC are excluded for every site circuit by IEDS 4.2 and HDD as a whole-run method by IEDS 4.3/UFC 3-550-01 3-11.4.1; OH is not predominant for C01-C04 and C07 because their routes lie inside the industrial area; EMT is excluded by UFGS 26 20 00 3.1.6.7 and both tray types by the 14 in ceiling space at COR-1D/COR-2 and the fully-enclosed requirement for MV cable. Every type was nevertheless priced as RFP 1.4 requires.

Recommended programme total project cost: **$1,852,180** (direct cost $1,309,355).

| Item | Recommended | Cable | Sets | Route (ft) | Total project cost | $/LF |
|---|---|---|---|---|---|---|
| C01 | CEDB | 500 kcmil | 2 | 860 | $377,440 | 438.78 |
| C02 | CEDB | 500 kcmil | 2 | 1170 | $456,779 | 390.41 |
| C03 | CEDB | 500 kcmil | 1 | 359 | $80,390 | 224.18 |
| C04 | CEDB | 250 kcmil | 1 | 1411 | $356,131 | 252.48 |
| C05 | RMC | 250 kcmil | 2 | 400 | $210,485 | 526.21 |
| C06 | OH | 350 kcmil + 1/0 ACSR OH | 1 | 1817 | $179,115 | 98.56 |
| C07 | CEDB | 250 kcmil | 1 | 674 | $191,840 | 284.63 |

## 2. Basis of estimate

- Labor: crew-book crews and the PCEC 2026 labor-unit database, with P-405 units converted at 67/80 and the mechanical-puller (0.85) and bucket-truck (0.85) multipliers of the database notes. Loaded rate = base x (1 + burden) + fringe; burden = FICA 7.65% + FUTA 0.60% + CA SUI 3.40% + WC class rate (20.39% line construction, 15.77% inside electrical, 19.00% laborer/operator).
- Equipment: EP 1110-1-8 Region VII (30 Nov 2016) total hourly rates, fuel and FOG adjusted per EP 3.9/3.10 from the Region VII base diesel $2.26/gal to the jobsite $4.38/gal (ratio 1.9381) and gasoline $2.49 to $5.12/gal (ratio 2.0562); rental equipment at RQ-26-0419.
- Materials: quote Q-2608-114 prices x (1 + recommended waste) x PPI adjustment 1.023796 (WPU102603 494.096 / 482.612) on indexed conductor items x 1.095 sales tax.
- Subcontracts: ADD-26-311 (HDD) and PJB-8817 (jack-and-bore) at quoted prices, no waste, tax or adjustment.
- Roll-up: JOOH 9.5%, HOOH 4.5% of direct+JOOH, profit 7.9494% by the weighted guidelines (weights from RFP 3.6 and UFC 3-740-05 11-2.2 for $4.2M, 15 months, 30% subcontracting), bond effective rate 1.2211% from the Sierra Surety Class B schedule with the 3-month (>12 month) surcharge applied to the seven recommended designs, escalation factor 1.019388 from UFS 3-701-01 Table 4-2 interpolated to 2027-08-18 over 2026-09-15, design contingency 5.0% of contract cost and SIOH 5.7% of contract plus contingency. Area cost factor 1.0 (not applied to a bottom-up local estimate).

| Item | Cable | Sets | Amp per set (A) | Total ampacity (A) | Design current (A) | Ampacity utilisation | 0.5 s SC rating (kA) | Bus fault (kA) | SC utilisation |
|---|---|---|---|---|---|---|---|---|---|
| C01 | 500 kcmil | 2 | 331.5 | 663.1 | 640 | 0.965 | 33.3 | 16.5 | 0.495 |
| C02 | 500 kcmil | 2 | 331.5 | 663.1 | 560 | 0.845 | 33.3 | 16.5 | 0.495 |
| C03 | 500 kcmil | 1 | 466.1 | 466.1 | 400 | 0.858 | 33.3 | 16.5 | 0.495 |
| C04 | 250 kcmil | 1 | 330.5 | 330.5 | 60 | 0.182 | 16.6 | 14.2 | 0.855 |
| C05 | 250 kcmil | 2 | 160.0 | 320.0 | 200 | 0.625 | 16.6 | 15.8 | 0.952 |
| C06 | 350 kcmil + 1/0 ACSR | 1 | 196.0 | 196.0 | 40 | 0.204 | 23.3 | 16.5 | 0.708 |
| C07 | 250 kcmil | 1 | 330.5 | 330.5 | 120 | 0.363 | 16.6 | 14.2 | 0.855 |

## 3. Design basis and constraints applied

- Cable: 15 kV, 133%, XLPE, copper-tape shield, aluminum, MV-105; three single conductors per set in one duct. Design current = feeder phase pickup from PDS Rev D. Ampacity from TD-15AL-133 at the governing condition: soil thermal resistivity of the nearest boring raised to the next tabulated value, earth ambient 25 C (factor), next higher circuit count and depth; building raceways 40 C. Short-circuit capability at the 0.5 s backup clearing time checked against the source bus fault current.
- C01/C02: 2 sets of 500 kcmil in 6 in EB-20 ducts, 3 ducts (1 spare), at 30 in cover. C02 rises to 63 in only where it passes beneath the T-2 telecom ductbank (15 in vertical separation); its Mission Drive crossing is a 30 in jack-and-bore. C03: 500 kcmil, 2 ducts (1 spare), 30 in cover except 56 in at the G-4 gas crossing (15.5 in vertical separation). C04: 250 kcmil, 2 ducts (1 spare), 6 in EB-20 at 30 in cover; the DC-1 crossing is a 6 in HDPE SDR 11 bore (D/d 3.90). C06: overhead 1/0 ACSR (196 A at 40 C) on seven Class 3 wood poles (5 x 45 ft, 2 x 50 ft at the MB-1 drive span; spans 244-271 ft <= 300 ft; poles set 6.5 ft/7.0 ft in soil per UFGS 33 71 01 3.1.3.1; conductor strung at 30% of the 4,380 lb rated breaking strength = 1,314 lb, within the 50% and 4,750 lb limits of UFC 3-550-01 3-10) outside the industrial area, with 350 kcmil underground risers (2 x 5 in EB-20 ducts, 1 spare) at SS-1 and at the GH-1 pad; the 350 kcmil riser is retained for its 23.3 kA short-circuit rating (250 kcmil would give 16.6 kA against a 16.5 kA bus, a 0.6% margin). C07: 250 kcmil, 2 ducts (1 spare), 5 in. C05: 2 sets of 250 kcmil in two 5 in RMC (D/d 3.63, fill 22.8%).
- Routes avoid retained-tree protection zones (1 ft radius per inch DBH), maintain 5 ft horizontal / 12 in vertical separation from the SUE-located utilities, do not open-cut Perimeter Road, Mission Drive, the MB-1 access drive or channel DC-1, and cross Mission Drive by jack-and-bore (RGS) and the channel by HDD (HDPE SDR 11, 140 ft, 50 ft beyond each bank).
- Manholes: precast 6x8x7 ft, 8 ft excavation with 2 ft clearance, box shield, 0.5 ft rock base, spaced <=600 ft with the submitted pulling calculation and within 100 ft of pad-mounted transformers; field long-sweep bends 25 ft radius elsewhere. Trench excavations 5 ft or deeper use a trench shield: the C02 63 in-cover segment is 6.55 ft deep and the C03 56 in-cover segment is 5.97 ft deep, and both are shielded. The 30 in-cover segments (3.71-3.80 ft deep) are unshielded.
- Cable pulling: every pull calculated from 100 lb feed tension, manufacturer friction factors, weight correction for the 3-cable configuration, bend-by-bend exponential tension and SWBP at 25 ft field-bend radius (36 in building elbows), against 0.006 lb/circular mil x two conductors (max 10,000 lb) and the approved 600 lb/ft SWBP.

## 4. Recommendations and alternatives by item

### C01 - SS1-F1 to MB1-ERA

**Recommendation: CEDB**, 500 kcmil, 2 set(s), route 860.2 ft, design current 640 A, ampacity per set 331.5 A at the governing condition, total $377,440 (438.78 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 860 | 695 | $86 | $59,443 | $11,735 | $170,005 | $25,640 | $266,822 | $377,440 | 438.78 |
| UEDB | N | 860 | 644 | $86 | $55,322 | $12,040 | $165,748 | $0 | $233,110 | $329,751 | 383.34 |
| DBC | N | 860 | 287 | $87 | $24,823 | $6,077 | $72,206 | $25,640 | $128,745 | $182,119 | 211.72 |
| HDD | N | 860 | 422 | $87 | $36,525 | $9,877 | $59,984 | $96,410 | $202,797 | $286,870 | 333.49 |
| OH | N | 860 | 199 | $88 | $17,497 | $4,718 | $36,294 | $0 | $58,509 | $82,766 | 96.22 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 515.2 | 30 | 1 x 3 x 6 in | 1 | N | B | none | N |
| 2 | JB | 40.0 | 30 | 1 x 3 x 6 in RGS | 1 | N | B | none | N |
| 3 | CE | 305.0 | 30 | 1 x 3 x 6 in | 1 | N | B | none | N |

Blended crew loaded labor rate for this recommendation: $86/MH; labor hours 694.8; direct cost $266,822.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | MH-1 | 200.0 | 612 | 42 | 3.82 | 20.6 |
| P02 | MH-1 | MH-2 | 260.2 | 734 | 11 | 3.82 | 20.6 |
| P03 | MH-3 | MH-2 | 280.0 | 620 | 0 | 3.70 | 21.9 |
| P04 | END | MH-3 | 120.0 | 467 | 42 | 3.82 | 20.6 |

Structures: MH-1, MH-2, MH-3.

### C02 - SS1-F2 to MB1-ERB

**Recommendation: CEDB**, 500 kcmil, 2 set(s), route 1170.0 ft, design current 560 A, ampacity per set 331.5 A at the governing condition, total $456,779 (390.41 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 1170 | 896 | $85 | $76,565 | $15,370 | $205,334 | $25,640 | $322,909 | $456,779 | 390.41 |
| UEDB | N | 1170 | 824 | $86 | $70,686 | $15,788 | $203,349 | $0 | $289,823 | $409,975 | 350.41 |
| DBC | N | 1170 | 373 | $86 | $32,233 | $8,180 | $92,188 | $25,640 | $158,241 | $223,843 | 191.32 |
| HDD | N | 1170 | 555 | $86 | $47,956 | $13,291 | $79,516 | $129,186 | $269,949 | $381,862 | 326.38 |
| OH | N | 1170 | 257 | $88 | $22,499 | $6,022 | $46,083 | $0 | $74,604 | $105,533 | 90.20 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 130.0 | 30 | 1 x 3 x 6 in | 1 | N | B | none | N |
| 2 | CE | 40.0 | 63 | 1 x 3 x 6 in | 1 | Y | B | box | N |
| 3 | CE | 415.0 | 30 | 1 x 3 x 6 in | 1 | N | B | none | N |
| 4 | JB | 40.0 | 30 | 1 x 3 x 6 in RGS | 1 | N | B | none | N |
| 5 | CE | 545.0 | 30 | 1 x 3 x 6 in | 1 | N | B | none | N |

Blended crew loaded labor rate for this recommendation: $85/MH; labor hours 896.0; direct cost $322,909.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | MH-1 | 130.0 | 807 | 42 | 3.82 | 20.6 |
| P02 | MH-1 | MH-2 | 400.0 | 981 | 7 | 3.82 | 20.6 |
| P03 | MH-2 | MH-3 | 200.0 | 474 | 0 | 3.70 | 21.9 |
| P04 | END | MH-3 | 440.0 | 1288 | 42 | 3.82 | 20.6 |

Structures: MH-1, MH-2, MH-3.

### C03 - SS1-F3 to CUP1-S

**Recommendation: CEDB**, 500 kcmil, 1 set(s), route 358.6 ft, design current 400 A, ampacity per set 466.1 A at the governing condition, total $80,390 (224.18 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 359 | 236 | $85 | $20,002 | $3,132 | $33,695 | $0 | $56,830 | $80,390 | 224.18 |
| UEDB | N | 359 | 201 | $85 | $17,143 | $3,159 | $33,584 | $0 | $53,885 | $76,225 | 212.57 |
| DBC | N | 359 | 111 | $86 | $9,518 | $1,747 | $17,189 | $0 | $28,454 | $40,250 | 112.25 |
| HDD | N | 359 | 104 | $87 | $9,008 | $2,174 | $14,180 | $31,792 | $57,154 | $80,849 | 225.46 |
| OH | N | 359 | 89 | $89 | $7,948 | $2,401 | $19,607 | $0 | $29,955 | $42,374 | 118.17 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 254.6 | 30 | 1 x 2 x 6 in | 1 | Y | B | none | N |
| 2 | CE | 104.0 | 56 | 1 x 2 x 6 in | 1 | Y | B | box | N |

Blended crew loaded labor rate for this recommendation: $85/MH; labor hours 235.8; direct cost $56,830.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | END | START | 358.6 | 2031 | 339 | 3.82 | 20.6 |

Structures: none.

### C04 - CUP1-E to TX-LS2

**Recommendation: CEDB**, 250 kcmil, 1 set(s), route 1410.5 ft, design current 60 A, ampacity per set 330.5 A at the governing condition, total $356,131 (252.48 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 1411 | 660 | $85 | $56,136 | $10,359 | $147,439 | $37,825 | $251,759 | $356,131 | 252.48 |
| UEDB | N | 1411 | 597 | $86 | $51,024 | $10,648 | $145,491 | $15,705 | $222,868 | $315,263 | 223.50 |
| DBC | N | 1411 | 262 | $86 | $22,495 | $5,353 | $44,057 | $37,825 | $109,731 | $155,222 | 110.04 |
| HDD | N | 1411 | 329 | $86 | $28,416 | $7,971 | $32,809 | $109,216 | $178,412 | $252,377 | 178.92 |
| OH | N | 1411 | 155 | $88 | $13,672 | $3,960 | $27,551 | $0 | $45,184 | $63,916 | 45.31 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 215.0 | 30 | 1 x 2 x 6 in | 1 | Y | C | none | N |
| 2 | JB | 40.0 | 30 | 1 x 2 x 6 in RGS | 1 | N | C | none | N |
| 3 | CE | 135.0 | 30 | 1 x 2 x 6 in | 1 | N | C | none | N |
| 4 | CE | 810.0 | 30 | 1 x 2 x 6 in | 1 | N | B | none | N |
| 5 | HDD | 140.0 | 120 | 1 x 2 x 6 in HDPE | 1 | N | B | none | N |
| 6 | CE | 70.5 | 30 | 1 x 2 x 6 in | 1 | N | B | none | N |

Blended crew loaded labor rate for this recommendation: $85/MH; labor hours 659.6; direct cost $251,759.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | MH-1 | 360.0 | 1365 | 32 | 4.36 | 15.8 |
| P02 | MH-1 | MH-2 | 500.0 | 653 | 0 | 4.51 | 14.8 |
| P03 | MH-2 | MH-3 | 490.0 | 1304 | 19 | 3.90 | 19.7 |
| P04 | END | MH-3 | 60.5 | 288 | 32 | 4.51 | 14.8 |

Structures: MH-1, MH-2, MH-3.

### C05 - MSG-A to USS-A1

**Recommendation: RMC**, 250 kcmil, 2 set(s), route 400.0 ft, design current 200 A, ampacity per set 160.0 A at the governing condition, total $210,485 (526.21 $/LF).

Governing clause: PCSFA-IEDS Rev 3 5.1; UFGS 26 20 00 3.1.6.7; UFC 3-520-01 Table 3-1.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| RMC | Y | 400 | 537 | $102 | $54,784 | $2,939 | $91,075 | $0 | $148,797 | $210,485 | 526.21 |
| EMT | N | 400 | 426 | $102 | $43,469 | $2,284 | $47,093 | $0 | $92,846 | $131,337 | 328.34 |
| TRAY-EN | N | 400 | 444 | $102 | $45,377 | $2,395 | $58,373 | $0 | $106,145 | $150,150 | 375.38 |
| TRAY-LD | N | 400 | 420 | $102 | $42,930 | $2,253 | $48,486 | $0 | $93,668 | $132,501 | 331.25 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | RMC | 400.0 |  | 1 x 2 x 5 in RMC |  | N | B | none | N |

Blended crew loaded labor rate for this recommendation: $102/MH; labor hours 536.5; direct cost $148,797.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | PB-1 | 335.0 | 1030 | 107 | 3.63 | 22.8 |
| P02 | END | PB-1 | 65.0 | 342 | 44 | 3.63 | 22.8 |

Structures: PB-1.

### C06 - SS1-F4 to TX-GH1

**Recommendation: OH**, 1/0 ACSR overhead conductors on 7 wood poles with 350 kcmil underground riser cable, 1 set(s), route 1817.3 ft, design current 40 A, overhead ampacity 196.0 A at 40 C (riser cable 386.0 A in duct) at the governing condition, total $179,115 (98.56 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.1 - overhead permitted outside the C-101 industrial area and outside the W-3 crane area; underground risers at both ends.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 1970 | 872 | $85 | $74,254 | $14,023 | $216,095 | $22,120 | $326,493 | $461,848 | 234.44 |
| UEDB | N | 1970 | 799 | $86 | $68,351 | $14,498 | $217,317 | $0 | $300,166 | $424,607 | 215.54 |
| DBC | N | 1970 | 320 | $86 | $27,557 | $7,024 | $61,919 | $22,120 | $118,620 | $167,796 | 85.18 |
| HDD | N | 1970 | 448 | $86 | $38,738 | $11,054 | $53,510 | $150,392 | $253,694 | $358,869 | 182.17 |
| OH | Y | 1817 | 369 | $87 | $32,095 | $7,446 | $87,080 | $0 | $126,621 | $179,115 | 98.56 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 202.4 | 30 | 1 x 2 x 5 in | 1 | N | B | none | N |
| 2 | OH | 1545.5 |  | ACSR 1/0 on wood poles |  | N | B | none | N |
| 3 | CE | 69.5 | 30 | 1 x 2 x 5 in | 1 | N | B | none | N |

Blended crew loaded labor rate for this recommendation: $87/MH; labor hours 369.1; direct cost $126,621.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | MH-1 | 142.4 | 620 | 44 | 3.51 | 24.4 |
| P02 | RP-1 | MH-1 | 60.0 | 332 | 44 | 3.51 | 24.4 |
| P03 | RP-2 | MH-2 | 30.4 | 288 | 44 | 3.51 | 24.4 |
| P04 | END | MH-2 | 39.1 | 301 | 44 | 3.51 | 24.4 |

Structures: MH-1, RP-1, P-2, P-3, P-4, P-5, P-6, RP-2, MH-2.

### C07 - CUP1-N to TX-W3

**Recommendation: CEDB**, 250 kcmil, 1 set(s), route 674.0 ft, design current 120 A, ampacity per set 330.5 A at the governing condition, total $191,840 (284.63 $/LF).

Governing clause: PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1; UFGS 33 71 02 3.7.9.

| Type | Admissible | Length ft | Labor MH | Avg labor $/MH | Labor $ | Equipment $ | Material $ | Subcontract $ | Direct $ | Total project $ | $/LF |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CEDB | Y | 674 | 322 | $85 | $27,554 | $5,050 | $80,892 | $22,120 | $135,617 | $191,840 | 284.63 |
| UEDB | N | 674 | 298 | $86 | $25,615 | $5,206 | $77,526 | $0 | $108,347 | $153,265 | 227.40 |
| DBC | N | 674 | 125 | $86 | $10,813 | $2,479 | $23,539 | $22,120 | $58,951 | $83,390 | 123.72 |
| HDD | N | 674 | 171 | $87 | $14,827 | $3,912 | $16,990 | $55,006 | $90,736 | $128,352 | 190.43 |
| OH | N | 674 | 104 | $89 | $9,274 | $2,791 | $21,264 | $0 | $33,329 | $47,146 | 69.95 |

| Seg | Method | Length ft | Cover in | Ducts (rows x cols x size) | Spare | Reinforced | Soil | Protection | Dewater |
|---|---|---|---|---|---|---|---|---|---|
| 1 | CE | 310.0 | 30 | 1 x 2 x 5 in | 1 | N | C | none | N |
| 2 | JB | 40.0 | 30 | 1 x 2 x 5 in RGS | 1 | N | B | none | N |
| 3 | CE | 324.0 | 30 | 1 x 2 x 5 in | 1 | N | C | none | N |

Blended crew loaded labor rate for this recommendation: $85/MH; labor hours 322.4; direct cost $135,617.

| Pull | From | To | Length ft | Max tension lb | Max SWBP lb/ft | Jam ratio | Fill % |
|---|---|---|---|---|---|---|---|
| P01 | START | MH-1 | 405.0 | 942 | 38 | 3.63 | 22.8 |
| P02 | MH-2 | MH-1 | 252.0 | 577 | 8 | 3.79 | 20.9 |
| P03 | MH-2 | END | 17.0 | 228 | 38 | 3.79 | 20.9 |

Structures: MH-1, MH-2.

## 5. Government-furnished document findings

| ID | Document | Defect | Correction used |
|---|---|---|---|
| F01 | Protective Device Settings Schedule Rev D | Rev D phase pickup F1 = 640 A but One-Line E-001 Rev B and superseded Rev C show 560 A | Used 640 A per IEDS 1.3 precedence (current settings schedule governs over one-line) |
| F02 | E-001 One-Line Diagram Rev B | 51P pickup 560 A conflicts with PDS Rev D 640 A | Used 640 A (PDS Rev D, 2026-06-30) |
| F03 | RFP 01 11 00 Amd 0001 (superseded) | Amd 0001 states JOOH 8.5% and midpoint 2027-06-30; Amd 0002 states JOOH 9.5% and midpoint 2027-08-18 | Used Amd 0002 values (JOOH 9.5%, midpoint 2027-08-18) |
| F04 | Attachment J-3 Wage Determination CA20260022 | Mod 2 (2026-01-30) superseded by Mod 5 (2026-08-06) under 29 CFR 1.6 | Used Modification 5 rates |
| F05 | SUE-24-0117 Utility Survey vs C-101 | Record depth 72 in but field-measured top of pipe 56 in (16 in shallower); C-101 note still says top approx 72 in | Used 56 in per survey (IEDS 1.3(5)) and set duct crossing to maintain 12 in vertical separation |
| F06 | GEO-24-0117 Geotechnical Report | Table 2 classifies all borings as OSHA Type B, but B-7 has SP sand 3-9 ft with groundwater at 4.0 ft and B-10 has SM sand 2-12 ft with groundwater at 3.0 ft | Classified B-7/B-10 areas as OSHA Type C per IEDS 4.12 and 29 CFR 1926 Subpart P App. A; Type B elsewhere |
| F07 | C-101 Site Utility Plan Rev 4 | C-101 omits tree T-208 (170,395, 14 in DBH) which the arborist survey marks retain; C-101 labels only T-201..T-207, T-209, T-210 | Used TS-24-0117 per IEDS 1.3(7); routing kept clear of T-208 protection zone (14 ft) |
| F08 | C-101 Site Utility Plan Rev 4 | Text label at (286,640) but stub-out circle and polyline terminus at (280,640) - 6 ft discrepancy | Used (280,640), the drawn stub-out circle |
| F09 | C-101 Site Utility Plan Rev 4 | Text label at (1092,730) but the entry-zone line is on the MB-1 west wall x=1100 (y 700-760) | Used (1100,730), perpendicular entry through the wall per RFP 1.3 |
| F10 | Government Estimate Template PCSFA FY26 | Template applies Area Cost Factor 1.16 (Los Angeles AFB Site #1) to a bottom-up estimate already priced with local wage determination, local quotes and Region VII equipment rates | Applied ACF = 1.0 per RFP 3.1 and UFS 3-701-01 Chapter 4 (ACF applies to unit-cost programming estimates) |
| F11 | A-501 MB-1 Ceiling Space Schedule Rev 1 | Available ceiling space 14 in is less than the 18 in (6 in tray + 12 in access headroom) required by IEDS 5.1 and UFC 3-520-01 Table 3-1 art. 392, so a continuous tray route from ER-A to MR-1 does not exist | TRAY-EN and TRAY-LD evaluated and marked not permitted; RMC recommended |
| F12 | SUE-24-0117 Utility Survey | Report cover date 2025-03-28 but Transmittal T-0117-09 lists the survey as 2026-04-18 | Used survey content as current (transmittal status current); date discrepancy has no design effect |
| F13 | GEO-24-0117 Geotechnical Report | Report dated 2025-05-16 but transmittal lists GEO-24-0117 as 2026-03-27 | Used report content as current; no design effect |
| F14 | C-101 Site Utility Plan Rev 4 | General note numbering starts at 8 with notes 1-7 absent | No design effect; notes present were applied |
| F15 | UFGS 33 71 02 3.7.9 vs PCSFA-IEDS 4.3 | UFGS table permits unreinforced ductbanks under light/moderate paved areas; IEDS 4.3 requires reinforcement under P-1 and CUP-1 yard | Applied the stricter IEDS requirement: reinforced ductbank under P-1 and CUP-1 yard |
| F16 | UFS 3-701-01 (2026) Table 4-2 | Published escalation factor for FY2030 (1.107331) is identical to FY2029 although the annual rate column is 2.0 percent, so the table omits one year of compounding | Not used: this study interpolates only between the 2025-10-01, 2026-10-01 and 2027-10-01 rows (1.021, 1.042441, 1.064332) |
| F17 | RFI Log FA4610-26-R-0031 | RFI-08 asking whether COR-2 ceiling space is available was withdrawn by the contractor, leaving the 14 in COR-2 space in force | Used 14 in COR-2 and COR-1D spaces as limiting; tray not permitted |
| F18 | Transmittal T-0117-09 | Transmittal lists the wage determination as Attachment J-3 Modification 2 although Modification 5 (2026-08-06) is the latest published modification | Applied Modification 5 per 29 CFR 1.6 |
| F19 | C-101 Site Utility Plan Rev 4 | Text labels at (286,520), (240,706) and (180,474) are offset about 6 ft from the drawn stub-out circles at (280,520), (240,700) and (180,480) | Used the drawn stub-out circles (280,520), (240,700), (180,480) |
| F20 | C-101 Site Utility Plan Rev 4 | Text label at (1330,412) but the entry-zone line is on the MB-1 south wall y=420 between x=1300 and x=1360 | Used (1330,420), perpendicular entry through the wall |
| F21 | C-101 Site Utility Plan Rev 4 | Text labels at (470,952), (608,1020) and (470,1068) are offset from the drawn entry-zone lines at y=960, x=600 and y=1060 | Used the wall lines (470,960), (600,1020), (470,1060) |
| F22 | C-101 Site Utility Plan Rev 4 | Pad squares are centred at (1800,130), (1760,1160) and (1030,1180) while the transformer text labels are at (1800,122), (1760,1152) and (1030,1172) - an 8 ft offset (the label is 5 ft beyond the 6 x 6 ft pad edge) | Used the pad centres per C-101 note 9 and RFP 1.3 (served at the pad): routes end at (1800,130), (1760,1160) and (1030,1180) |

## 6. Requirement register

The full register is in the workbook Register sheet (94 requirements with document, clause, value and applicability).

## 7. Recommended design take-off derivation

Totals below are computed from the submitted Segments/Structures geometry by the RFP 3.7 conventions and reconcile to the Takeoff sheet. Excavation/backfill include the manhole volumes; pavement is the clipped length in P-1/CUP-1 yard; TBOX includes the deep shielded segments and 20 LF per manhole; circuit-feet = sets x (underground route + 6 ft per MH + 36 ft for the two equipment terminals + 40 ft per riser pole).

| Item | Type | CE ft | MH | JB crossings | HDD ft | Ducts | Envelope W x H in | Trench bottom ft | Excavation CY | Backfill CY | Concrete CY | Rebar lb | Pave SY | TBOX LF | Circuit-ft | TERM | Fireproof LF |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C01 | CEDB | 820.2 | 3 | 40 | 0 | 1x3 | 31.88 x 12.62 | 3.66 (depth 3.80-3.80) | 556.5 | 410.1 | 63.1 | 0 | 0.0 | 60 | 1828 | 12 | 216 |
| C02 | CEDB | 1130.0 | 3 | 40 | 0 | 1x3 | 31.88 x 12.62 | 3.66 (depth 3.80-6.55) | 730.9 | 552.4 | 86.9 | 194 | 0.0 | 100 | 2448 | 12 | 216 |
| C03 | CEDB | 358.6 | 0 | 0 | 0 | 1x2 | 22.25 x 12.62 | 2.85 (depth 3.80-5.97) | 168.0 | 142.0 | 19.5 | 1175 | 108.8 | 104 | 395 | 6 | 0 |
| C04 | CEDB | 1230.5 | 3 | 40 | 140 | 1x2 | 22.25 x 12.62 | 2.85 (depth 3.80-3.80) | 628.8 | 478.3 | 67.1 | 705 | 86.3 | 60 | 1465 | 6 | 108 |
| C05 | RMC | 0 | 0 | 0 | 0 | 1x2 | 5.563 OD RMC | - | 0 | 0 | 0 | 0 | 0 | 0 | 868 | 12 | 0 |
| C06 | OH | 271.8 | 2 | 0 | 0 | 1x2 | 20.13 x 11.56 | 2.68 (depth 3.71-3.71) | 189.6 | 132.3 | 12.9 | 0 | 0.0 | 40 | 400 | 6 | 72 |
| C07 | CEDB | 634.0 | 2 | 40 | 0 | 1x2 | 20.13 x 11.56 | 2.68 (depth 3.71-3.71) | 322.9 | 243.9 | 30.0 | 0 | 0.0 | 40 | 722 | 6 | 72 |

C05 uses two 5 in RMC conduits (1 x 2), a 400 ft route plus two 7 ft rises; circuit-feet = 2 x (400 + 14 + 20) = 868. The route has two 90-degree field bends (at 1130,705 and 1440,705) plus the two 7 ft riser elbows, 360 degrees in total; one 36 x 36 x 12 junction box at the second bend (PB-1, 1440,705) splits the run into pulls of 180 and 90 degrees, satisfying IEDS 5.3 (bends between pull points not more than 270 degrees). The box is an angle pull (5 in conduit in and 5 in out on adjacent faces), so the NFPA 70 minimum dimension invoked by UFGS 26 20 00 3.1.9.2 is 6 x 5 + 5 = 35 in, within the 36 in box. No straight-run pull box is used and no pull exceeds 335 ft.

## 8. Rates used

| Labor class | WD group | Base $/hr | Fringe $/hr | Burden % | Loaded $/hr | Crew | Crew average loaded $/hr |
|---|---|---|---|---|---|---|---|
| LINEMAN | ELEC1245-001 | 70.16 | 24.71 | 20.39 | 109.18 | CR-DU,CR-CP,CR-SP,CR-OH,CR-OH2,CR-OH3,CR-STR | 83.61, 86.21, 90.00, 90.00, 90.00, 96.39, 86.17 |
| EQSPEC | ELEC1245-001 | 53.30 | 22.26 | 20.39 | 86.43 | CR-EX,CR-BF,CR-CP,CR-MH | 83.84, 83.86, 86.21, 84.92 |
| GROUNDMAN | ELEC1245-001 | 40.76 | 21.76 | 20.39 | 70.83 | CR-DU,CR-CP,CR-SP,CR-OH,CR-OH2,CR-OH3,CR-STR | 83.61, 86.21, 90.00, 90.00, 90.00, 96.39, 86.17 |
| ELECTRICIAN | ELEC0011-004 | 60.80 | 31.59 | 15.77 | 101.98 | CR-IN,CR-IS | 101.98, 103.74 |
| SPLICER_IN | ELEC0011-004 | 63.84 | 31.59 | 15.77 | 105.50 | CR-IS | 103.74 |
| LAB1 | LABO0300-003 | 46.48 | 25.95 | 19.00 | 81.26 | CR-EX,CR-CO | 83.84, 81.26 |
| LAB3 | LABO0300-003 | 47.58 | 25.95 | 19.00 | 82.57 | CR-TM,CR-BF | 82.57, 83.86 |
| LAB4 | LABO0300-003 | 49.13 | 25.95 | 19.00 | 84.41 | CR-MH | 84.92 |
| PUMPOP | ENGI0012-024 | 63.40 | 33.20 | 19.00 | 108.65 | CR-DW | 108.65 |

| Equipment ID | Description | Source | Adjusted hourly rate $/hr |
|---|---|---|---|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET | EP 1110-1-8 Region VII H25CA040; fuel/FOG adjusted | 58.68 |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48 IN MAX DEPTH | EP 1110-1-8 Region VII T30DW022; fuel/FOG adjusted | 14.61 |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY | EP 1110-1-8 Region VII L50CA001; fuel/FOG adjusted | 30.98 |
| C10BO003 | COMPACTOR, VIBROPLATE, 2,250 LBS IMPACT | EP 1110-1-8 Region VII C10BO003; fuel/FOG adjusted | 2.90 |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON | EP 1110-1-8 Region VII C80TE008; fuel/FOG adjusted | 61.06 |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, 3 IN | EP 1110-1-8 Region VII P50WC002; fuel/FOG adjusted | 3.85 |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | Rental quote RQ-26-0419 | 96.00 |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb | Rental quote RQ-26-0419 | 58.50 |
| RQ-TBX | Trench shield (box), 8 ft x 20 ft, steel | Rental quote RQ-26-0419 | 7.25 |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | Rental quote RQ-26-0419 | 11.80 |

| Supplier item | Description | Unit | Quoted price | Waste | Indexed (PPI) | Priced material rate |
|---|---|---|---|---|---|---|
| CBL-500 | 15 kV 133% XLPE Al 500 kcmil | LF | 9.10 | 3% | yes | 10.508 |
| CBL-350 | 15 kV 133% XLPE Al 350 kcmil | LF | 7.45 | 3% | yes | 8.602 |
| CBL-250 | 15 kV 133% XLPE Al 250 kcmil | LF | 6.20 | 3% | yes | 7.159 |
| EB20-6 | PVC Type EB-20 6 in duct | LF | 5.60 | 5% | no | 6.439 |
| EB20-5 | PVC Type EB-20 5 in duct | LF | 4.15 | 5% | no | 4.771 |
| RGS-5 | RGS 5 in | LF | 61.00 | 5% | no | 70.135 |
| RGS-6 | RGS 6 in | LF | 79.50 | 5% | no | 91.405 |
| CONC-3000 | Ready-mix concrete 3000 psi | CY | 212.00 | 8% | no | 250.711 |
| REBAR-4 | Reinforcing steel #4/#3 ties | LB | 1.18 | 5% | no | 1.357 |
| MH-PRECAST | Precast MV manhole 6x8x7 | EA | 16850.00 | 0% | no | 18450.750 |
| TERM-KIT | 15 kV cold-shrink termination kit | EA | 265.00 | 0% | no | 290.175 |
| ACSR-1/0 | ACSR 1/0 Raven | LF | 0.62 | 2% | yes | 0.709 |
| ACSR-336.4 | ACSR 336.4 kcmil Linnet | LF | 1.72 | 2% | yes | 1.967 |
| POLE-45 | Wood pole 45 ft Class 3 | EA | 1480.00 | 0% | no | 1620.600 |
| POLE-50 | Wood pole 50 ft Class 3 | EA | 1760.00 | 0% | no | 1927.200 |
| XARM-ASSY | 8 ft crossarm assembly | EA | 385.00 | 0% | no | 421.575 |
| GUY-ASSY | Down guy assembly | EA | 420.00 | 0% | no | 459.900 |
| RISER-ASSY | Riser pole termination assembly | EA | 3950.00 | 0% | no | 4325.250 |
| PBOX-36 | Pull box 36x36x12 NEMA 1 | EA | 1180.00 | 0% | no | 1292.100 |

## 9. Conclusions

All seven circuits can be built with the recommended conveyances within the governing criteria. No design requires a criteria waiver. The principal cost driver is concrete-encased ductbank (concrete, reinforcement and excavation), followed by 15 kV cable. The recommended programme is the lowest-cost permitted combination: for C01-C04 and C07 the other site types are excluded by mandatory installation criteria (IEDS 4.1-4.3), and for C06 both CEDB and OH are permitted and OH has the lower total project cost. The in-building circuit C05 can only use RMC, so its cost is a consequence of the fire and ceiling-space criteria rather than of the type choice.