# CONTINUATION SHEET - AMENDMENT 0003

To: Contracting Officer, Code ACQ42, NAVFAC Pacific. From: Designer of Record, Calder Ridge Engineering.
Date: 14 September 2026

Work order 74213 - Fleet Data Center Increment 2 - Naval Support Activity Ventura Bay, California
Solicitation N40085-26-R-2041 (BP-2, Central Utility Plant and Site Utilities)
File 74213Amend0003.pdf; Amendment 0003 to the solicitation, issued with Standard Form 30 as the coversheet. Drawing attachment files 74213Amend0003dwg1of3.pdf, 74213Amend0003dwg2of3.pdf and 74213Amend0003dwg3of3.pdf.

DRAWINGS:

On NAVFAC Drawing No. 74213-GI001 (GI-001)

ADD the drawings listed below to the DRAWING INDEX, under the discipline and drawing number shown. They accompany this Amendment:

S-201A   74213-S201A   BRACED BAY FRAMING ELEVATIONS - ADDED SHEET
M-501A   74213-M501A   CHILLER PAD ANCHORAGE DETAILS - ADDED SHEET

REPLACE the drawings listed below in the DRAWING INDEX, under the discipline and drawing number shown. They accompany this Amendment:

GI-001   74213-GI001   DRAWING INDEX - REPLACED SHEET
C-101   74213-C101   SITE UTILITY PLAN - REPLACED SHEET
S-101   74213-S101   CUP FOUNDATION PLAN - REPLACED SHEET
S-102   74213-S102   CUP ROOF FRAMING PLAN - REPLACED SHEET
S-301   74213-S301   CUP BUILDING SECTIONS - REPLACED SHEET
S-502   74213-S502   FRAMING DETAILS - REPLACED SHEET
M-101   74213-M101   CUP CHILLED WATER PLAN - REPLACED SHEET
M-301   74213-M301   CHILLED WATER PLANT SECTIONS - REPLACED SHEET
M-401   74213-M401   CHILLER BAY ENLARGED PLAN - REPLACED SHEET
M-501   74213-M501   PIPING DETAILS - REPLACED SHEET
M-502   74213-M502   EQUIPMENT ANCHORAGE DETAILS - REPLACED SHEET
E-001   74213-E001   ELECTRICAL PANEL SCHEDULES - REPLACED SHEET
E-101   74213-E101   CUP POWER PLAN - REPLACED SHEET
E-501   74213-E501   ELECTRICAL DETAILS - REPLACED SHEET

On NAVFAC Drawing No. 74213-GI001 (GI-001)
   Drawing Index: two sheets added (S-201A, M-501A) and fourteen sheets replaced under this Amendment; the index is regenerated in the order of the governing CAD standard.

On NAVFAC Drawing No. 74213-C101 (C-101)
   Site Utility Plan: fire water main alignment revised to obtain the required separation from the duct bank; the crossing callout at the duct bank is revised.

On NAVFAC Drawing No. 74213-S101 (S-101)
   Foundation Plan: anchor rod embedment callout revised to the embedment required by the assigned seismic design category and the associated foundation plan note revised.
   Foundation Plan: callout added to new sheet S-201A for the braced bay framing elevations.

On NAVFAC Drawing No. 74213-S102 (S-102)
   Roof Framing Plan reissued for reference coordination with the revised framing details on S-502 and the revised longitudinal section on S-301.

On NAVFAC Drawing No. 74213-S201A (S-201A)
   New sheet S-201A added: braced bay framing elevations with brace work points and connection references.

On NAVFAC Drawing No. 74213-S301 (S-301)
   Building Sections reissued for reference coordination with the revised equipment anchorage detail on S-502.

On NAVFAC Drawing No. 74213-S502 (S-502)
   Equipment Anchorage Detail: cast-in anchor DELETED and REPLACED with a post-installed anchor suitable for the post-tensioned slab.

On NAVFAC Drawing No. 74213-M101 (M-101)
   Chilled Water Plan: chilled water supply main size callout revised to match the pump head calculated in the mechanical Design Analysis.

On NAVFAC Drawing No. 74213-M301 (M-301)
   Plant Section A: chilled water header lowered to clear the roof structure shown on the structural sections.
   Plant Section B: chiller shown in phantom line.

On NAVFAC Drawing No. 74213-M401 (M-401)
   Chiller Bay Enlarged Plan: callout added to new sheet M-501A for the chiller pad anchorage details.

On NAVFAC Drawing No. 74213-M501 (M-501)
   Pipe Support Detail: hanger rod spacing matched to the trapeze support spacing used on the prior CUP project.

On NAVFAC Drawing No. 74213-M501A (M-501A)
   New sheet M-501A added: anchorage details for the two added chiller housekeeping pads, including seismic restraint.

On NAVFAC Drawing No. 74213-M502 (M-502)
   Equipment Anchorage Details reissued for reference coordination with the revised anchorage on S-502.

On NAVFAC Drawing No. 74213-E001 (E-001)
   Panel Schedules: panel schedule column order aligned with the reviewer convention; ratings and circuiting unchanged.

On NAVFAC Drawing No. 74213-E101 (E-101)
   Power Plan: feeder tag leaders moved to the load side of each disconnect.

On NAVFAC Drawing No. 74213-E501 (E-501)
   Electrical Details reissued for reference coordination with the revised anchorage on S-502.

SPECIFICATIONS:

PROJECT TABLE OF CONTENTS

No specification section is added, deleted or replaced by this Amendment.

DOCUMENT 00 01 15 LIST OF DRAWINGS

1.2  Contract Drawings

ADD the drawings listed below. They accompany this Amendment.

DRAWING NO.   REVISION NO.   NAVFAC DWG NO.   TITLE
S-201A   3   74213-S201A   BRACED BAY FRAMING ELEVATIONS
M-501A   3   74213-M501A   CHILLER PAD ANCHORAGE DETAILS

The drawings listed below are deleted and replaced as of 14 September 2026, and accompany this Amendment.

GI-001   3   74213-GI001   DRAWING INDEX
C-101   3   74213-C101   SITE UTILITY PLAN
S-101   3   74213-S101   CUP FOUNDATION PLAN
S-102   3   74213-S102   CUP ROOF FRAMING PLAN
S-301   3   74213-S301   CUP BUILDING SECTIONS
S-502   3   74213-S502   FRAMING DETAILS
M-101   3   74213-M101   CUP CHILLED WATER PLAN
M-301   3   74213-M301   CHILLED WATER PLANT SECTIONS
M-401   3   74213-M401   CHILLER BAY ENLARGED PLAN
M-501   3   74213-M501   PIPING DETAILS
M-502   3   74213-M502   EQUIPMENT ANCHORAGE DETAILS
E-001   3   74213-E001   ELECTRICAL PANEL SCHEDULES
E-101   3   74213-E101   CUP POWER PLAN
E-501   3   74213-E501   ELECTRICAL DETAILS

COST:

No change in construction cost. The corrections are clarifications and coordination corrections within the scope of the work already solicited; there is no addition, deletion or change of a bid item, quantity or unit price. The Government cost of issuing the corrections is recorded in the design basis: 57,886.92 USD for BP-2 and 46,558.66 USD for BP-3.

--End of Amendment 0003--

## BP-3 - Data Hall 210 Shell and Interiors (solicitation N40085-26-R-3018)

The BP-3 EOR review corrections are incorporated in the design before the solicitation is advertised. The corrected package is issued as the pre-advertisement final design for advertisement on 9 November 2026, so no change number is assigned and no continuation sheet is submitted for BP-3. The 15 corrected existing sheets and the two added sheets A-402 and M-502 are delivered in the two BP-3 drawing bundles listed in the issue plan. The eight unchanged sheets (A-002, A-401, E-101, G-001, M-501, S-102, S-301 and T-101) are not part of the reissue and keep their existing title blocks. EOR-3-030 is closed by a documented non-concurrence because the deck span arrow is a drafting preference and adopting it would add two sheets and a third bundle for more than the non-concurrence charge.
