# Design Basis - EOR Review Corrections, Work Order 74213

Fleet Data Center Increment 2, Naval Support Activity Ventura Bay, California. BP-2 Central Utility Plant and Site Utilities (solicitation N40085-26-R-2041) and BP-3 Data Hall 210 Shell and Interiors (solicitation N40085-26-R-3018). Source-of-record date for the review record: 24 August 2026; production start 31 August 2026.

```json
{
 "packages": {
  "BP-2": {
   "issue_state": "AMENDMENT",
   "change_number": "0003",
   "overflow_option": 2,
   "revision_layers": [
    "Z-ANNO-REVC",
    "Z-ANNO-REVS"
   ],
   "n_bundles": 3,
   "production_days": 14,
   "delay_days": 1,
   "backcheck_window_days": 15,
   "ledger": {
    "bundles_usd": 14400,
    "sheets_usd": 20426.92,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 3360,
    "overflow_option_usd": 1760,
    "non_concurrence_usd": 2400,
    "delay_usd": 2740,
    "total_usd": 57886.92
   },
   "title_block_defects": [
    {
     "sheet": "E-501",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    },
    {
     "sheet": "S-301",
     "defect": "CHK_EQUALS_DRW"
    }
   ]
  },
  "BP-3": {
   "issue_state": "PRE_ADVERTISEMENT_REISSUE",
   "change_number": "",
   "overflow_option": "NONE",
   "revision_layers": [
    "Z-ANNO-REVC",
    "Z-ANNO-REVS"
   ],
   "n_bundles": 2,
   "production_days": 12,
   "delay_days": 0,
   "backcheck_window_days": 30,
   "ledger": {
    "bundles_usd": 9600,
    "sheets_usd": 21758.66,
    "added_sheets_usd": 12800,
    "revision_marks_usd": 0,
    "overflow_option_usd": 0,
    "non_concurrence_usd": 2400,
    "delay_usd": 0,
    "total_usd": 46558.66
   },
   "title_block_defects": [
    {
     "sheet": "A-501",
     "defect": "CHK_EQUALS_DES"
    },
    {
     "sheet": "M-101",
     "defect": "SEAL_DISCIPLINE_MISMATCH"
    }
   ]
  }
 },
 "governing_standards": [
  "FC 1-300-09N, Design Procedures Criteria, 17 May 2024, Change 1 dated 17 April 2025",
  "ERDC/ITL SR-24-3, A/E/C CAD Standard, Release 6.2 (2024)",
  "ERDC/ITL SR-23-1, A/E/C Graphics Standard, Release 2.2 (August 2023)",
  "ER 1165-2-217, Review Policy, 1 May 2021 (adopted for this work order by the Contracting Officer memorandum of 26 August 2026)",
  "ERDC/ITL SR-21-6, Record Package Guidance, Best Practices, August 2021 (markup and record-package conventions adopted by the Contracting Officer memorandum of 26 August 2026)",
  "ER 415-1-11, BCOES Reviews, 1 January 2013",
  "FAR 52.236-25, Requirements for Registration of Designers (48 CFR 52.236-25)",
  "Contracting Officer memorandum, work order 74213 change numbers and issue of the EOR review corrections, 26 August 2026",
  "A-E Production and Reprographics Rate Schedule, work order 74213, effective 26 August 2026",
  "Solicitation schedule, BP-2 N40085-26-R-2041 and BP-3 N40085-26-R-3018"
 ],
 "rejected_standards": [
  "UFC 1-300-09N, 2005 with Change 7 - cancelled; FC 1-300-09N (2024, Change 1) is the current design procedures criteria and supersedes it.",
  "A/E/C CAD Standard, Release 6.0 (ERDC/ITL TR-12-6) - superseded by A/E/C CAD Standard Release 6.2 (ERDC/ITL SR-24-3); only the current release governs.",
  "GSA PBS CAD Standard 2021 - another agency owner legacy standard, not adopted for this NAVFAC work order.",
  "ERDC/ITL SR-21-6 record-package deliverable requirements - the Contracting Officer memorandum adopts only its markup and record-package conventions, not its record-package deliverables.",
  "ER 1110-1-8159, DrChecks, 1 January 2015 - system administration guidance for the DrChecks tool; the Contracting Officer memorandum adopts only ER 1165-2-217 and ERDC/ITL SR-21-6, and no ER 1110 clause is applied to this issue.",
  "Fire protection comment log FP-2-004/007/011/015 - another A-E task order and another discipline; filed for coordination only and outside the BP-2 and BP-3 revision scope.",
  "FY23 record prints 55210_FY23CUP_M-501_RECORD.pdf and 55210_FY23CUP_S-501_RECORD.pdf - record drawings from an earlier contract, reference only; they are not the work order 74213 issue and no change is made against them.",
  "Superseded 90 percent BP-2 prints and 60 percent BP-3 prints - they predate the sheet renumbering and are not the issue any change is made against.",
  "Sheet index export sheet_index_export_BP-2_90pct_SUPERSEDED.xlsx - a 90 percent reference export that predates the sheet renumbering; the current database export of 24 August 2026 is used instead."
 ],
 "rate_parameters": {
  "production_start": "2026-08-31",
  "sheets_per_day": 4,
  "days_per_bundle": 3
 },
 "void_markups": [
  {
   "comment_id": "EOR-2-017",
   "reason": "Author is not listed on the reviewer roster for this review, so the markup is not a review comment and cannot direct a design change."
  },
  {
   "comment_id": "EOR-2-019",
   "reason": "The markup annotation carries no creation timestamp, so it cannot be shown to have been made within the review period or authenticated as a review comment; it cannot direct a change."
  },
  {
   "comment_id": "EOR-2-021",
   "reason": "The markup is drawn on the superseded 90 percent submittal print of S-102, which is not the current issue and is not the issue any change is made against."
  },
  {
   "comment_id": "EOR-2-033",
   "reason": "Closed in the 60 percent review with a notation that it was elevated for resolution; that closure was never reopened, so the markup cannot direct a further change."
  },
  {
   "comment_id": "EOR-3-012",
   "reason": "The markup is drawn on the superseded 60 percent submittal print of T-501, which is not the current issue and is not the issue any change is made against."
  },
  {
   "comment_id": "EOR-3-020",
   "reason": "The markup annotation carries no creation timestamp, so it cannot be shown to have been made within the review period or authenticated as a review comment; it cannot direct a change."
  },
  {
   "comment_id": "EOR-3-022",
   "reason": "Author is not listed on the reviewer roster for this review, so the markup is not a review comment and cannot direct a design change."
  },
  {
   "comment_id": "EOR-3-036",
   "reason": "Closed in the 60 percent review with a notation that it was elevated for resolution; that closure was never reopened, so the markup cannot direct a further change."
  }
 ]
}
```

## 1. Documents that govern, and documents set aside

The governing design procedures criteria is FC 1-300-09N, 17 May 2024 with Change 1 of 17 April 2025. Its paragraph 12-3.3.4 fixes the order of precedence for CAD standards: the requirements of its own Chapter 12 come first, then the latest releases of the DoD A/E/C CAD Standard and the A/E/C Graphics Standard, then the National CAD Standard. The current releases in the project file are the A/E/C CAD Standard Release 6.2 (ERDC/ITL SR-24-3) and the A/E/C Graphics Standard Release 2.2 (ERDC/ITL SR-23-1).

Set aside: UFC 1-300-09N (2005, Change 7) is cancelled and is superseded by the FC; the A/E/C CAD Standard Release 6.0 (TR-12-6) is superseded by Release 6.2; the GSA PBS CAD Standard 2021 is another agency standard; ER 1110-1-8159 is DrChecks system administration guidance that the Contracting Officer memorandum does not adopt; the fire protection comment log belongs to a separate A-E task order and discipline; the FY23 record prints belong to an earlier contract; and the superseded 90 percent prints, 60 percent prints and 90 percent index export are not the issue any change is made against.

The Contracting Officer memorandum of 26 August 2026 adopts ER 1165-2-217 and the markup and record-package conventions of ERDC/ITL SR-21-6 for this work order. ER 415-1-11 governs the timing of the review backcheck. FAR 52.236-25 requires that design work be prepared, reviewed and approved by registered professionals in the particular professional field involved, which is the basis of the seal findings below.

The PPI/RFI log was reviewed. PPI-2-001 confirms the chiller basis of design; PPI-2-002 declines the pipe insulation substitution; PPI-2-003 says the duct bank concrete strength is clarified by the specification; and RFI-3-001 says the data hall slab flatness tolerance is answered by specification 03 30 00. Every entry records that no amendment is required, so none of them adds a correction to this issue or changes a sheet.

## 2. Revision-graphics layer conflict resolved (item a)

The two shipped documents that disagree are FC 1-300-09N and the A/E/C CAD Standard Release 6.2. FC 1-300-09N paragraph 12-3.6.1 places revision clouds on layer Z-ANNO-REVC and revision symbols, notes and revision-block entries on layer Z-ANNO-REVS. The A/E/C CAD Standard Release 6.2 assigns the same two functions to G-ANNO-REVC and G-ANNO-REVS. The clause that fixes the order of precedence is FC 1-300-09N paragraph 12-3.3.4: the requirements of its own Chapter 12 rank ahead of the A/E/C CAD Standard and the A/E/C Graphics Standard, which in turn rank ahead of the National CAD Standard. The revision-graphics requirement sits in the FC Chapter 12, so the FC prevails and the layers actually used for every revised sheet in this issue are Z-ANNO-REVC (clouds) and Z-ANNO-REVS (revision triangles, indicators, notes and the Revision (Issue) block entries). The A/E/C CAD Standard G-ANNO-REVC and G-ANNO-REVS layer names were not used. Every revised sheet therefore carries its change clouded on Z-ANNO-REVC with an equilateral triangle numbered 3 beside the cloud, and the Revision (Issue) block entry and note text on Z-ANNO-REVS; the two added BP-2 sheets carry the same mark 3 with the description SHEET ADDED IN ACCORDANCE WITH AMDT 0003.

## 3. BP-3 issue state (item b)

BP-3 has not been advertised. The earlier solicitation schedule export shows a scheduled advertisement of 12 October 2026, but the later Contracting Officer memorandum of 26 August 2026 states that BP-3 is scheduled to advertise on 9 November 2026; the memorandum is the later dated instrument and controls, so the advertisement date used is 9 November 2026 and the bid opening date remains 12 November 2026.

The review regulation is ER 415-1-11. It gives two durations. Its paragraph g requires the backcheck to be started 30 calendar days before advertising and requires all comments to be resolved before bid opening or proposal evaluation. Its paragraph e, subparagraph (4) allows about 15 calendar days for backchecking of comments. For a package whose corrections are incorporated before advertisement, the 30-day window binds, because the backcheck must precede the advertisement itself. The 15-day period is the backcheck allowance that binds when corrections are issued as an amendment after advertisement, where resolution must precede bid opening.

Production of the BP-3 corrections takes 12 calendar days from the 31 August 2026 start: 17 sheets at 4 sheets per calendar day is 4.25 days, rounded up to 5 days, plus 2 bundles at 3 days each (6 days), plus 1 day for the single non-concurrence (EOR-3-030). Production finishes on 12 September 2026. The 30-day backcheck window opens on 10 October 2026, so the finish is well before the window opens and the 9 November 2026 advertisement does not move. The title block ISSUE DATE on the 15 reissued existing sheets and on the two added sheets is NOVEMBER 2026, the month of advertisement. The eight unchanged sheets A-002, A-401, E-101, G-001, M-501, S-102, S-301 and T-101 are not part of the corrected-design reissue and keep the AUGUST 2026 date of their last issue; re-plotting them would add sheet re-issue charges for no design change and no schedule benefit. BP-3 is therefore issued as a pre-advertisement reissue of the corrected design, not as an amendment: no change number is assigned, no continuation sheet is submitted, and no revision-block entry is made. The two added sheets are numbered A-402 and M-502, and the two bundles are 74213dwg1of2.pdf and 74213dwg2of2.pdf. The alternative course, advertising on 9 November and amending afterwards, was rejected because it would add revision marks and revision-block overflow charges for no schedule gain and would require a continuation sheet and a change number that the pre-advertisement course avoids.

## 4. BP-2 issue state and Revision (Issue) block overflow (item c)

BP-2 was advertised on 6 July 2026 and its bid opening is 28 September 2026, so the only lawful issue state is an amendment to the solicitation. Two amendments have already been issued, so the next number in numerical order, in the three-cipher form required by FC 1-300-09N paragraph 18-3, is 0003. The amendment is documented on a continuation sheet with the Standard Form 30 coversheet. The 15-day backcheck period of ER 415-1-11 paragraph e, subparagraph (4) applies: the 16-sheet issue takes 4 production days at 4 sheets per calendar day, plus 3 bundles at 3 days each (9 days), plus 1 day for the single non-concurrence (EOR-2-011), for 14 production days from 31 August 2026. Production finishes on 14 September 2026, the backcheck opens on 15 September 2026 and takes 15 calendar days, so the controlling completion is 29 September 2026 and it is 1 day past the 28 September 2026 bid opening. The bid opening therefore moves 1 calendar day to 29 September 2026 and the extension charge is 2,600 x 1 + 140 x 1 = 2,740.00 USD.

The Revision (Issue) block provided by the A/E/C Graphics Standard holds eight rows. Six of the BP-2 sheets in this issue already carry eight entries: C-101, M-101, M-501, S-101, S-102, S-502. The graphics standard offers two overflow options and requires the chosen option to be used consistently across the whole set. Option 1 (replace the oldest entry, 520 USD per revised full sheet) would cost 6 x 520 = 3,120 USD. Option 2 (spill above the eighth row, 880 USD per revised full sheet that carries three or more drawing blocks, nothing where the spill area is unoccupied) is charged only on M-501 and S-502, which carry three or more drawing blocks each, and costs 2 x 880 = 1,760 USD; the other 4 full sheets carry one drawing block each and cost nothing. Option 2 was adopted set-wide and Option 1 was rejected on cost: 3,120 USD against 1,760 USD, a saving of 1,360 USD, with the spill confined to the unoccupied area above the block on the multi-block sheets. The option is applied to every revised sheet in the set, not sheet by sheet, and the new entry is placed above the existing entries (row 9 on the full sheets, the next free row on the others).

## 5. Disposition method, void markups and non-concurrences

Of the 34 comments, 17 are directive design or coordination findings and are all incorporated; 8 markups cannot direct a change and are closed void or closed by elevation; 2 non-directive comments are answered by documented non-concurrences; and 7 non-directive preferences are adopted because adoption costs less than the non-concurrence charge. The disposition register carries the response, resolution and every changed and impacted location for each comment.

Every comment in the two EOR markup logs was assessed against the four-part comment convention of ER 1165-2-217 paragraph 5.8.3 and answered with the three-part response of paragraph 5.8.7 (concur or non-concur, how the comment is resolved, and every location affected). Where a markup cannot direct a change it was closed as void with the ground stated, and no sheet was changed for it:

- EOR-2-017 - Author is not listed on the reviewer roster for this review, so the markup is not a review comment and cannot direct a design change.
- EOR-2-019 - The markup annotation carries no creation timestamp, so it cannot be shown to have been made within the review period or authenticated as a review comment; it cannot direct a change.
- EOR-2-021 - The markup is drawn on the superseded 90 percent submittal print of S-102, which is not the current issue and is not the issue any change is made against.
- EOR-2-033 - Closed in the 60 percent review with a notation that it was elevated for resolution; that closure was never reopened, so the markup cannot direct a further change.
- EOR-3-012 - The markup is drawn on the superseded 60 percent submittal print of T-501, which is not the current issue and is not the issue any change is made against.
- EOR-3-020 - The markup annotation carries no creation timestamp, so it cannot be shown to have been made within the review period or authenticated as a review comment; it cannot direct a change.
- EOR-3-022 - Author is not listed on the reviewer roster for this review, so the markup is not a review comment and cannot direct a design change.
- EOR-3-036 - Closed in the 60 percent review with a notation that it was elevated for resolution; that closure was never reopened, so the markup cannot direct a further change.

Six yellow text notes reading CHECKED - NO COMMENT (K. Aoyama) are participation notes with no comment record, and the four fire protection comments in the other-discipline log belong to a separate A-E task order; none is an EOR review comment of BP-2 or BP-3, so none is carried into the disposition register. The markup colour convention of ERDC/ITL SR-21-6 distinguishes additions (green), deletions (red) and items requiring clarification (blue); the blue markups are the non-directive preferences. Under ER 1165-2-217 paragraph 5.8.5 a comment that only enforces a personal preference is not directive. Each non-directive comment was priced both ways and the cheaper lawful course taken.

EOR-2-011 (bearing area table relocation) is documented as a non-concurrence because adopting it would change C-501/A and would draw in C-301, at 2 x 1,150 + 6.8 x 26 + 2 x 240 = 2,956.80 USD including the two revision marks, against 2,400 USD for the documented non-concurrence. Both courses leave production at 14 days because the adopted alternative removes the non-concurrence day but adds two sheets and one production day, so the non-concurrence is 556.80 USD cheaper, and the arrangement as drawn is legible and has no code basis for change.

EOR-3-030 (repeat the deck span direction arrow) is documented as a non-concurrence because adopting it would change S-301 and would draw in S-102, at 2 x 1,150 + 8.64 x 26 = 2,524.64 USD, and it would raise the BP-3 issue from 17 to 19 sheets, from 91.2 MB to 103.6 MB, and therefore from two bundles to three, adding 4,800 USD in bundle setup and 2 production days. The documented non-concurrence costs 2,400 USD; the arrangement as drawn is legible and the preference has no code basis. The other seven non-directive markups were adopted because they cost less than a non-concurrence: most sit on sheets this issue already reissues and cost only the markup extent (26 USD per square inch), and the three that draw in a sheet not otherwise in the issue (EOR-2-013 on E-001, EOR-3-032 on M-301 and EOR-3-034 on T-501) each cost less than the 2,400 USD non-concurrence charge plus its processing day.

Reference sweep. The reference graph was read from the callout bubbles printed in the production data of each sheet. The drawings README explains that a callout belongs to the drawing block it is drawn inside and points to the drawing block it calls out, so the graph is block-to-block rather than sheet-to-sheet. A callout for a detail points to a 5-series sheet, an enlarged area to a 4-series sheet, a section to a 3-series sheet and an elevation to a 2-series sheet (A/E/C Graphics Standard paragraphs 4.2.4.2 to 4.2.4.4); every callout in both sets was checked against those couplings. Reissue was propagated in the reverse direction: a change to a drawing block reaches only the drawing blocks whose callouts point at it, and those blocks in turn reach the blocks that call them out. The BP-2 change to the equipment anchorage in S-502/A, for example, reaches E-501/A, M-501/A, M-502/A and S-301/2, and those in turn reach E-101, M-101, M-401 and S-102. The BP-3 change to the base plate in S-501/A reaches A-501/A, E-501/A and S-101, and those reach A-101, A-301 and E-102. Changes to a different block on the same sheet do not propagate; for example, the M-301 plant section B change does not reach M-101, which calls out section A only.

## 6. Title block findings

Each sheet in the two issues was read against FC 1-300-09N paragraph 12-4.1: the SAT-TO statement and date must be present, the CHK initials may not be the same as the DES or DRW initials, and the electronic seal must be that of the discipline responsible for the sheet, consistent with FAR 52.236-25. The SAT-TO statement and date are present on every sheet read, so no sheet is reported for that item. The non-compliant sheets in the two issues are:

- BP-2 E-501 - seal is for a different discipline than the sheet content
- BP-2 S-301 - CHECKED BY initials equal DRAWN BY initials
- BP-3 A-501 - CHECKED BY initials equal DESIGNED BY initials
- BP-3 M-101 - seal is for a different discipline than the sheet content

These are corrected on the reissued sheets before signature and seal: the CHK initials are assigned to a checker other than the designer or drafter, and the seal is replaced with the seal of the discipline responsible for the sheet (electrical for BP-2 E-501, mechanical for BP-3 M-101, structural for BP-2 S-301). Sheets not in the issue were not reissued and their defects are not charged to this issue; C-102 in BP-2 carries CHK-equals-DES and T-101 in BP-3 carries CHK-equals-DRW, and both should be corrected at their next reissue.

## 7. Issue content, packaging and cost

**BP-2** - AMENDMENT. 16 sheets in the issue (14 reissued, 2 added), 3 bundles. Ledger: bundles $14,400.00; sheets including markup incorporation $20,426.92; added sheets $12,800.00; revision marks $3,360.00; overflow option $1,760.00; non-concurrence $2,400.00; delay $2,740.00; total $57,886.92 USD.

**BP-3** - PRE_ADVERTISEMENT_REISSUE. 17 sheets in the issue (15 reissued, 2 added), 2 bundles. Ledger: bundles $9,600.00; sheets including markup incorporation $21,758.66; added sheets $12,800.00; revision marks $0.00; overflow option $0.00; non-concurrence $2,400.00; delay $0.00; total $46,558.66 USD.

Bundling observes the 50 MB drawing-PDF limit of FC 1-300-09N paragraph 12-3.5.1. Each bundle is at or below 50 MB and complete discipline sets are kept whole, as paragraph 12-3.5.2.1 requires. BP-2 uses three bundles: mechanical 46.0 MB, structural 38.3 MB, and civil with electrical and the drawing index 35.2 MB. BP-3 uses two bundles: architectural with the drawing index 45.5 MB, and structural with mechanical, electrical and telecommunications 45.7 MB. No discipline set is split in either package. Every bundle is bookmarked by discipline and by sheet, and the sheets are signed and sealed before delivery per paragraph 12-3.5.2.

Production duration follows the rate schedule note: the whole-day ceiling of sheets produced divided by 4 sheets per day, plus 3 days per bundle, plus 1 day per non-concurrence. The extension charge uses D = max(0, production finish + backcheck window - controlling deadline) and the rate 2,600 x D + 140 x D squared from the Contracting Officer memorandum of 26 August 2026.

The sheets line folds in the markup incorporation charge at 26 USD per square inch (BP-2 166.42 square inches, BP-3 173.41 square inches) because the ledger structure carries no separate markup line; the sheet re-issue charge alone is 1,150 USD per sheet. The BP-2 area is the sum of the eleven valid incorporated markups (seven directives and four adopted preferences); the BP-3 area is the sum of the thirteen valid incorporated markups (ten directives and three adopted preferences). The void markups, the S-502 strike-out line and the non-concurred markups are not charged because they are not incorporated. The combined Government cost of issuing both sets of corrections is 104,445.58 USD, delivered as the one submission this memorandum package accompanies.

Added sheets follow the shipped standards for the issue state. For the advertised BP-2 set the existing sheet numbers are not changed and the two inserted sheets take the supplemental designator of the preceding sheet in their series, M-501A and S-201A, as A/E/C CAD Standard paragraph 2.4.4.1 provides. For the pre-advertisement BP-3 set resequencing is still available, so the two new sheets take the next free sequence numbers in their type series, A-402 (large-scale view) and M-502 (details).

## 8. Actions before the issue is released

- The designer of record corrects the CHECKED BY initials on BP-2 S-301 and BP-3 A-501, replaces the seal on BP-2 E-501 and BP-3 M-101 with the seal of the responsible discipline, then signs and seals every reissued sheet before the bundles are delivered, per FC 1-300-09N paragraph 12-4.1 and FAR 52.236-25.
- The reviewer backchecks the documented non-concurrences on EOR-2-011 and EOR-3-030 within the backcheck period that follows the production finishes, per ER 1165-2-217 paragraph 5.8.2 and ER 415-1-11 paragraph e, subparagraph (4).
- The Contracting Officer issues Standard Form 30 with continuation sheet 74213Amend0003.pdf and drawing attachments 74213Amend0003dwg1of3.pdf to 3of3.pdf for BP-2, and places the corrected BP-3 package on the 9 November 2026 advertisement (Contracting Officer memorandum of 26 August 2026, paragraphs 1 to 3).
- The designer of record corrects the CHECKED BY initials on BP-2 C-102 and BP-3 T-101 at their next reissue, per FC 1-300-09N paragraph 12-4.1.

The constraint register records each governing clause, value and the sheets, comments or bundles it binds.

