# Building B - seismic diaphragm and shear wall design basis
**Design format: LRFD.** All forces and capacities in this package are strength-level. Deck capacity uses $\phi=0.60$ (AISI S310); embedded connectors, base tie-downs and wall anchors use $\phi=0.75$ (RPC-CAT-2026 Rev 3); steel members use $\phi=0.90$ (AISC 360). The package is not an ASD package and does not mix allowable and factored values.
**Documents used.** SDC-02 Rev 2 (2026-08-14) is the governing structural design criteria; DAP-2 Rev 1 (2026-07-31) is the governing analysis protocol; PR-07 (2026-08-03) is the peer-review requirement; OBD-CDDC-B Rev 4, RFI-041 (closed), ERL-2026-08, PCS-014, A-101 Rev 3, S-201 Rev 2, PC-101 Rev 2 (record), PC-301 Rev 2, BDS-2026-DT Rev 6, RPC-CAT-2026 Rev 3, PROC-114 Rev 2, ERC-07 Rev 1, GEO-2026-071, CDDC-SV-2026-041, M-601 Rev 3 and T-2026-118 supply the balance. The 90_archive documents (SM-2019-04, WM-2026-09, A-101 Rev 1, GEO-2019-118) are record-only under T-2026-118 and are not used as requirements.
## 1. Seismic basis
| Parameter | Value | Source |
|---|---|---|
| Risk category | III | OBD-CDDC-B Rev 4 s1.4; SDC-02 Rev 2 s2 |
| Importance factor $I_e$ | 1.25 | SDC-02 s2; ASCE/SEI 7-22 s11.5.1, Table 1.5-2 |
| Site class | D ($V_{s,100}=905$ ft/s) | GEO-2026-071 s4; SDC-02 s3 |
| $S_{DS}$, $S_{D1}$ | 0.44, 0.24 | USGS ASCE 7-22, Risk Category III, Site Class D (SDC-02 s3) |
| Seismic design category | D | SDC-02 s3; ASCE/SEI 7-22 s11.6 (both $S_{DS}$ and $S_{D1}$) |
| $R$, $\Omega_0$, $C_d$ | 4, 2.5 (2.0 collectors), 4 | UFC 3-301-01 Table 3-1 row A.6; footnote b; SDC-02 s4 |
| $T=C_t h_n^x$ | 0.2434 s | ASCE/SEI 7-22 Eq. 12.8-7; $C_t=0.02$, $x=0.75$, $h_n=28$ ft |
| $C_s=S_{DS}/(R/I_e)$ | 0.1375 | ASCE/SEI 7-22 Eq. 12.8-2; Eq. 12.8-3 gives 0.3080 and Eq. 12.8-4 gives 0.0242, so Eq. 12.8-2 governs |
| $W$ | 2,270.5 kip | WEIGHTS sheet |
| $V=C_sW$ | 312.2 kip | ASCE/SEI 7-22 Eq. 12.8-1 |
The building is one storey. ASCE/SEI 7-22 s12.8.3 puts the whole base shear at the roof for $T<0.5$ s. The diaphragm design force is $F_{px}=C_s w_{px}$ (Eq. 12.10-1), bounded by $0.11w_{px}\le F_{px}\le0.22w_{px}$ (Eqs. 12.10-2 and 12.10-3). For E-W loading $w_{px}=1,446.8$ kip and $F_{px}=198.9$ kip; for N-S loading $w_{px}=1,652.7$ kip and $F_{px}=227.2$ kip. The bounds are satisfied in both directions.
## 2. Seismic force-resisting system
**Selected system: intermediate precast concrete shear walls, R = 4, $\Omega_0$ = 2.5 (2.0 for collectors and their connections), $C_d$ = 4.** The permitting clause is UFC 3-301-01 Table 3-1 row A.6, which the project adopts in lieu of ASCE/SEI 7-22 Table 12.2-1 (SDC-02 s1 and s4). The row permits intermediate precast shear walls in Seismic Design Category D up to a structural height of 40 ft. Building B is 28 ft to the roof diaphragm (A-101 Rev 3 note 2), so the system is permitted. Detailing follows ACI 318-19 s18.2.1.6 for intermediate precast structural walls (UFC Table 3-1 row A.6). The panels are 8 in solid normal-weight precast, 100 psf, spanning vertically from the foundation to the roof and cantilevered 3 ft above it to the parapet; they are the only seismic force-resisting elements (SDC-02 s4; S-201 Rev 2 note 5). There are no interior shear walls or braced frames.
**Why this is the cost-efficient choice.** The three catalogue systems in PROC-114 are ordinary precast, intermediate precast and special precast. Ordinary precast is not permitted (NP) in SDC D (UFC Table 3-1 row A.7), so it cannot be used. Special precast has $R=5$ and would reduce the seismic force by 20 %, but it requires the RPC-60D (JC3) connector, which is the only connector qualified under ACI 318-19 s18.5.2 (RPC-CAT-2026 Rev 3 s2), and the special-precast detailing premium is $4,120 per panel against $1,850 for intermediate. On 81 panels the premium alone is $183,870 more and the JC3 connectors add about $51,300 on 60 joints, so the special system would exceed the $395,000 cap before any deck or anchorage cost. Intermediate precast with JC1 connectors ($385 each, $V_n=24$ kip, $\phi V_n=18$ kip) is therefore the lowest-cost system that is permitted at this height and seismic design category. The joint demand is at most 6.36 kip, so one JC1 per joint is sufficient.
## 3. As-built geometry and conflicts
The design uses the erected geometry recorded in ERL-2026-08 and accepted by RFI-041, not the detailed PC-101 Rev 2 layout (RFI-041 response; A-101 Rev 3 note 6; PR-07). The S wall piers are 0-18, 32-48, 62-78, 93.5-109.5, 123.5-138, 152-196 and 200-240 ft; the N wall segments are 0-24, 28-60, 60-72 (L-1 spandrel), 72-154, 154-170 (L-2 spandrel) and 170-240 ft; the W wall segments are 0-12, 16-66 and 110-180 ft, with EY-1 a full-height gap at 66-110 ft; the E wall segments are 0-72, 86-108, 108-120 (L-3 spandrel), 120-150 and 154-180 ft. The Stage A spandrel solid fraction is $(28-10)/28=0.643$ for the 10 ft elevated louvres L-1, L-2 and L-3, measured on the 28 ft cantilever to the diaphragm because DAP-2 s3 says the parapet above the diaphragm is not part of the in-plane cantilever.
| # | Conflict | Resolution used | Governing record |
|---|---|---|---|
| 1 | Risk Category II on the architectural cover sheet versus Risk Category III | Risk Category III, $I_e=1.25$ | OBD-CDDC-B s1.4; SDC-02 s2 expressly supersedes the cover block |
| 2 | GEO-2019-118 (Parcel 4B, ASCE 7-16) and the ASCE 7-16 RC II Site C motions versus GEO-2026-071 and the ASCE 7-22 RC III Site D motions | Site Class D; $S_{DS}=0.44$, $S_{D1}=0.24$; SDC D | GEO-2026-071 s4; SDC-02 s3 |
| 3 | PC-101 record panel layout versus erected panel positions | Erected positions per ERL-2026-08 | RFI-041 response; A-101 Rev 3 note 6; PR-07 |
| 4 | PCS-014 N-12 10 ft panel with a 16 ft L-2 louver versus the 16 ft erected opening at 154-170 ft | 16 ft opening at 154-170 ft; the PCS row is a casting label | RFI-041; ERL-2026-08; PCS-014 note |
| 5 | PC-101 16 ft D-4/D-5 pier versus the erected 14.5 ft pier | 14.5 ft pier from 123.5 to 138.0 ft | ERL-2026-08; RFI-041 |
| 6 | PC-101 40 ft EY-1 versus the 44 ft field-widened opening | 44 ft at 66-110 ft, modelled as a full-height gap | ERL-2026-08 FC-018; RFI-041; PC-301 W elevation |
| 7 | Spandrels versus full-height gaps | Elevated L-1, L-2, L-3 are spandrels (0.643); EY-1 and the S dock doors, P-1, P-2, P-3, P-4 and D-6 reach the foundation and are gaps | DAP-2 s3; PC-301 elevations |
| 8 | FEMA P-2082-1 permits 12.10.3/12.10.4 versus SDC-02 s5 | 12.10.1 and 12.10.2 | SDC-02 s5; the FEMA document is a reference copy |
| 9 | UFC Table 3-1 $\Omega_0=2.5$ versus the flexible-diaphragm reduction | 2.0 for collectors and their connections | UFC Table 3-1 footnote b; SDC-02 s4 |
| 10 | WM-2026-09 wind memorandum versus the seismic demand | Seismic governs; the wind memorandum is record-only | SDC-02 s1/s4/s5; T-2026-118 |
| 11 | 90_archive documents versus the current set | Record-only; not used | T-2026-118 |
| 12 | BDS Table 4 values for three or more spans versus the opening-adjacent deck | The deck runs 30 spans N-S; RO-1/RO-2 are framed; the runs on each side remain three or more spans | S-201 Rev 2 note 1; BDS-2026-DT Rev 6 Table 4 |
| 13 | 81 erected panels versus the Stage A spandrel subdivisions | 81 panels (S 19 + N 28 + W 15 + E 19) and 60 joints (S 12 + N 22 + W 12 + E 14) for quantity; the 4 ft W-15 panel is an erected non-lateral spandrel | PCS-014; PROC-114 RATES B29 |
The thirteen conflicts are the complete list found in the record. Where two documents conflict and neither is expressly superseded, the resolution takes the stricter reading for the design: e.g. the erected D-3 opening of 15 ft 6 in is used rather than the 14 ft detailed opening, and the 44 ft EY-1 is used rather than the 40 ft record opening.
## 4. Analysis
**Protocol.** The analysis follows DAP-2 Rev 1, as SDC-02 s10 and PR-07 require. Stage A is the in-plane model of each precast wall segment: each panel is a cantilever fixed at the foundation and free at the top with $u$, $v$ and $\theta$ at the top; $f_{uu}=h^3/(3EI)+h/(GA_v)$, $f_{u\theta}=h^2/(2EI)$, $f_{\theta\theta}=h/EI$; $E_c=57,000\sqrt{f'_c}$ psi for $f'_c=6,000$ psi; $G_c=E_c/2.4$; $A_v=5/6A_g$; $I=0.50I_g$ (DAP-2 s3, which is the governing source for the 0.50 value). Adjacent panels are connected by vertical joint springs equal to the number of connectors times the connector stiffness (JC1: $1\times210=210$ kip/in). A panel tie-down carries its own base couple on a 0.8 times panel length lever arm plus the coupling axial force (DAP-2 s3). The base moment is taken with the sign convention that reproduces the published VP-1 value 88.91 kip-in/kip.
**Stage A verification (DAP-2 Appendix A, VP-1).** The implementation reproduces the published values exactly:
| Quantity | DAP-2 target | Computed |
|---|---|---|
| $k_{seg}$ | 1,279.4 kip/in | 1,279.4 kip/in |
| Joint 1 shear per kip | 0.2630 kip/kip | 0.2630 kip/kip |
| Joint 2 shear per kip | 0.2527 kip/kip | 0.2527 kip/kip |
| Panel 1 base moment | 88.91 kip-in/kip | 88.91 kip-in/kip |
| Panel 1 axial | 0.2630 kip/kip | 0.2630 kip/kip |
| $k_{seg}$ with no connectors | 769.2 kip/in | 769.2 kip/in |
**Stage B.** The roof is a plane-stress membrane on a 10 ft square grid; elements whose centroid falls inside RO-1 (96-156, 108-148 ft) or RO-2 (36-116, 36-56 ft) are removed (392 elements of 432). $D=\mathrm{diag}(A',A',G')$ with $A'=1,740$ kip/in and $G'$ from BDS Table 4 for the zone pattern (all zones P5: $G'=61$ kip/in); Poisson's ratio is zero; integration is 2x2 Gauss (DAP-2 s4). The wall segments are springs to ground distributed over the nodes they span, and the perpendicular wall lines are in the model to resist plan rotation. Chords/collectors are two-node bars with $E=29,000$ ksi and the catalogue area. Accidental torsion is 5 % of the plan dimension perpendicular to the loading times the total applied diaphragm force, applied as a mass-proportional rotational field, with $A_x$ from the rigid model capped at 3.0 (DAP-2 s5; ASCE/SEI 7-22 s12.8.4.2 and s12.8.4.3).
**Envelope.** Every design force - zone shear, wall-line force, wall-segment force, chord and collector axial force - is the largest of the flexible, rigid and semi-rigid idealisations (DAP-2 s6.3; PR-07; SDC-02 s10). The flexible idealisation is a simple beam spanning between the two wall lines that resist the direction, with unit shear equal to beam shear divided by the net diaphragm depth and chord force equal to beam moment divided by the same depth; accidental torsion is not transferred in the flexible idealisation. The wall-line flexible floor includes the parallel walls' own inertia, which DAP-2 s5 delivers directly to the wall line: $F_{flex}=F_{px}/2+C_sw_{wall}$. The 100/30 cases add 0.30 of the companion orthogonal case with the same mass case, eccentricity sign and stage (DAP-2 s6.4).
**Ax and equilibrium.** The rigid-model $A_x$ is 1.00 for every final case: the maximum wall-line displacement does not exceed 1.2 times the average, so no torsional amplification is required. The S11 erection case gives $A_x=1.39$ because the partial diaphragm west of X=180 ft is torsionally irregular. The sum of the wall-spring reactions equals $F_{px}$ plus the parallel-wall inertia applied directly at the wall lines; the equilibrium ratio is 0.9986 to 1.0000 for every case (STAGE_B_ANALYSIS sheet).
**Collector force.** The Stage B bar axial force is taken as the cumulative sum of the element forces along the run, not the single largest element force; the cumulative value is the axial force at the section and is the quantity DAP-2 s6.3 requires for the chord and collector envelope. The collector force is the same quantity on the wall line perpendicular to the loading; it is amplified by $\Omega_0=2.0$ (SDC-02 s5; UFC Table 3-1 footnote b). The design force is $\max(\text{chord envelope},\ \Omega_0\times\text{collector envelope})$.
## 5. Diaphragm and wall forces
The effective seismic weight is 2,270.5 kip: roof 784.0 kip (20 psf over 39,200 sq ft net deck), phase-1 roof-top units 45.0 kip (M-601 Rev 3), and the four wall lines 1,716.1 plf each over their lengths (S 411.9, N 411.9, W 308.9, E 308.9 kip). The wall tributary weight is 1,716.1 plf from the 31 ft panel propped at the 28 ft diaphragm, $100\times31^2/(2\times28)$ (FEMA P-2192-V1 s7.6.1 Step 1 form; SDC-02 s6). The phase-2 mass case adds 16.0 kip (two 8 kip units). $V=C_sW=0.1375\times2,270.5=312.2$ kip.
**Wall-line forces (envelope, kip).** The complete 12-case table is in the WALL_FORCES sheet; the values below are that table.
| Case | Dir | S | N | W | E | $A_x$ | Governing use |
|---|---|---|---|---|---|---|---|
| S01 | X | 156.1 | 179.3 | 9.4 | 9.4 | 1.00 | base/future |
| S02 | X | 164.6 | 171.3 | 18.3 | 18.3 | 1.00 | base/future |
| S03 | Y | 4.3 | 4.3 | 156.1 | 170.9 | 1.00 | base/future |
| S04 | Y | 11.5 | 11.5 | 164.7 | 156.1 | 1.00 | base/future |
| S05 | X | 157.4 | 180.6 | 56.2 | 60.7 | 1.00 | 100/30 |
| S06 | Y | 60.9 | 62.9 | 170.2 | 161.6 | 1.00 | 100/30 |
| S07 | X | 157.2 | 180.8 | 9.3 | 9.3 | 1.00 | base/future |
| S08 | Y | 4.3 | 4.3 | 157.2 | 172.9 | 1.00 | base/future |
| S09 | X | 168.8 | 176.0 | 67.8 | 65.4 | 1.00 | 100/30 |
| S10 | Y | 60.8 | 62.9 | 170.5 | 162.7 | 1.00 | 100/30 |
| S11 | X | 55.8 | 47.0 | 0.0 | 0.0 | 1.39 | erection |
| S12 | Y | 34.7 | 34.7 | 102.8 | 0.0 | 1.00 | erection |
The governing wall-line force is 168.8 kip on S (S09), 180.8 kip on N (S07), 170.5 kip on W (S10) and 172.9 kip on E (S08). The S01 and S03 values are the DAP-2 flexible floor of 156.1 kip, not a model result: $198.9/2+0.1375\times411.9=156.1$ for S, and $227.2/2+0.1375\times308.9=156.1$ for W. The S11/S12 erection cases use the partial Stage B model of ERC-07 s4; the E wall has no diaphragm support in that stage and its diaphragm force is zero (it is braced temporarily).
**Deck attachment zones.** All twelve zones use pattern P5 (36/9 support fastening, #12 TEK @ 9 in sidelap, $S_n=1,835$ plf, $G'=61$ kip/in, $\phi S_n=1,101$ plf) from BDS-2026-DT Rev 6 Table 4. Net areas deduct the geometric overlap of RO-1 and RO-2; the total is 39,200 sq ft. The worst zone shear is Z10 at 1,075 plf, utilisation 0.976; Z2 is 1,035 plf (0.940), Z6 1,039 plf (0.944), Z11 986 plf (0.896). The BDS Table 4 note limits the values to panels of three or more spans. The roof deck is continuous N-S over 30 spans between the S and N walls; RO-1 and RO-2 are local openings framed with the OP-1/OP-2 lines, and the deck runs on each side of each opening remain three or more spans. The panel immediately at an opening edge is the end panel of that run; its span to the first joist is not greater than the tabulated 6 ft, and the zone design shear is a section mean taken away from the discontinuous edge. I therefore apply the BDS three-span values to the zone diaphragm, which is the reading supported by the S-201 Rev 2 note 1 framing and the A-101 Rev 3 opening layout. The vendor table does not publish a one-span value; the OP-1/OP-2 framing and the P5 pattern are the heaviest available.
**Chords, collectors and drag struts.**
| Line | Member | Chord envelope (kip) | Collector envelope (kip) | Design force (kip) | $\phi P_n$ compression (kip) | Utilisation |
|---|---|---|---|---|---|---|
| CH-S | C3 | 83.9 | 123.4 | 246.7 | 272.0 | 0.907 |
| CH-N | C3 | 51.0 | 91.6 | 183.3 | 272.0 | 0.674 |
| CH-W | C2 | 66.4 | 38.7 | 77.4 | 86.5 | 0.895 |
| CH-E | C2 | 66.9 | 36.1 | 72.2 | 86.5 | 0.835 |

The CH lines are continuous on all four diaphragm edges (SDC-02 s5) and are also continuous across every wall opening 12 ft or wider, so they serve as the drag struts required by SDC-02 s5. The S-201 Rev 2 schedule's DR-* lines lie on the same alignments as the CH lines; under S-201 note 3 ("a line left out costs nothing and carries nothing") the DR-* candidate lines are left out and their collector force is carried by the continuous CH member. The design_records lists them as C0 for that reason; the DXF shows the DR runs on the CH lines with their forces. The eight roof-opening chords OP-1S/N/W/E and OP-2S/N/W/E are C1 L4x4x3/8; the largest opening-chord force is 16.2 kip (OP-2S), below the C1 compression capacity of 42.1 kip at 8 ft.
The 8 ft unbraced length is the wall-anchor spacing, which is 8 ft on all four walls. C1/C2/C3 capacities at $KL=8$ ft are 42.1/86.5/272.0 kip compression and 128.7/213.8/410.4 kip tension (AISC 360 E3, $F_y=50$ ksi). The C3 W8x31 on S/N is governed by the amplified collector force; the C2 L6x4x1/2 on W/E is governed by the chord force and its amplified collector component.
## 6. Wall anchorage and the parapet cantilever
The wall-to-diaphragm anchorage follows ASCE/SEI 7-22 s12.11.2.1 with the flexible-diaphragm amplification $k_a$. The span $L_f$ is 180 ft for the S/N walls and 240 ft for the W/E walls (UFC 3-301-01 Figure 3-1; SDC-02 s6). $k_a=1+(L_f/100)^2$ is 4.24 and 6.76 respectively, capped at 2.0, so $k_a=2.0$ on every wall. The total lever-action wall tributary weight is $W_p=100\ \mathrm{psf}\times31^2/(2\times28)=1,716.1$ plf. The anchorage force is $F_p=0.4S_{DS}k_aI_eW_p=0.4\times0.44\times2.0\times1.25\times1,716.1=755.1$ plf.
The **parapet transfer** requested by the template is the portion of the wall weight delivered to the roof by the wall above the top of deck: the 3 ft parapet weighs $100\times3=300$ plf, and its roof reaction is $300\times(28+1.5)/28=316.1$ plf. The 316.1 plf is the parapet transfer; it is not the total $W_p$. The anchorage force uses the total $W_p=1,716.1$ plf, because the panel below the deck also delivers its lever-action reaction to the roof (FEMA P-2192-V1 s7.6.1 Step 1; SDC-02 s6). Both numbers are reported separately in PARAPET_ANCHORAGE and design_record.json.
**Anchor selection.** The W and E walls run N-S, perpendicular to the E-W joists, so joist seats occur at those walls and WA1 joist-seat anchors are used at 8 ft: demand $755.1\times8/1000=6.04$ kip, capacity $\phi T_n=0.75\times9.4=7.05$ kip, utilisation 0.857. The S and N walls run E-W, parallel to the joists; there are no joist seats there, so WA2 embed-plate-and-strap anchors are used at 8 ft: demand 6.04 kip, capacity $0.75\times18.6=13.95$ kip, utilisation 0.433. The subdiaphragm depth is 6.0 ft (joist spacing) and the span is 8.0 ft, so $L/d=1.33\le2.5$ (ASCE/SEI 7-22 s12.11.2.2.1). Continuous ties are the joists at 6 ft (S-201 Rev 2 note 4).
## 7. Governing constraint per wall line
| Wall | Max wall force (case) | Joint connector JC1 $\phi V_n=18$ kip | Base tie-down BA2 $\phi T_n=66$ kip | Wall anchor $\phi T_n$ (kip) | Governing check |
|---|---|---|---|---|---|
| S | 168.8 (S09) | 6.36 / 18 = 0.353 | 64.59 / 66 = 0.979 | 6.04 / 13.95 = 0.433 | base tie-down (BA2) 0.979 |
| N | 180.8 (S07) | 4.12 / 18 = 0.229 | 40.34 / 66 = 0.611 | 6.04 / 13.95 = 0.433 | base tie-down (BA2) 0.611 |
| W | 170.5 (S10) | 6.09 / 18 = 0.339 | 60.51 / 66 = 0.917 | 6.04 / 7.05 = 0.857 | base tie-down (BA2) 0.917 |
| E | 172.9 (S08) | 5.42 / 18 = 0.301 | 52.28 / 66 = 0.792 | 6.04 / 7.05 = 0.857 | wall anchor 0.857 |

The S wall governs the base tie-down at 64.59 kip against 66.0 kip (utilisation 0.979; the governing panel is the 10 ft panel at the start of the 32.0 ft segment). The W wall base tie-down is 60.51 kip (0.917). The E wall is governed by its WA1 anchor at 0.857. The N wall is governed by its base tie-down at 40.34 kip (0.611). No wall line is governed by the panel joint connector: the largest joint demand is 6.36 kip on S against $\phi V_n=18$ kip (0.353).
## 8. Cost
| Item | Quantity and rate | Amount |
|---|---|---|
| Deck attachment, P5 | 39,200 sq ft x $2.47/sq ft | $96,824 |
| C3 W8x31, S/N chords/collectors/drag struts | 480 lf x $36.20/lf | $17,376 |
| C2 L6x4x1/2, W/E chords/collectors | 360 lf x $18.90/lf | $6,804 |
| C1 L4x4x3/8 opening chords | 400 lf x $11.40/lf | $4,560 |
| JC1 joint connectors | 60 joints x 1 x $385 | $23,100 |
| BA2 base tie-downs | 81 panels x $910 | $73,710 |
| WA2 wall anchors, S/N | 60 x $172 | $10,320 |
| WA1 wall anchors, W/E | 45 x $96 | $4,320 |
| Intermediate precast SFRS premium | 81 panels x $1,850 | $149,850 |
| **Installed cost** | | **$386,864** |
| Capital cap (PROC-114) | | $395,000 |
| Margin | | $8,136 (2.1 %) |
The quantity basis is PROC-114 RATES B29: deck attachment on the net roof area of each zone, chords/collectors/drag struts on the full length of the line, joint connectors on the number of vertical joints inside the wall segments times the connectors per joint, base tie-downs one assembly per erected panel, wall anchors on the wall length divided by the anchor spacing, and the SFRS premium on every erected panel. The 81 panels are PCS-014's S 19 + N 28 + W 15 + E 19; the 60 joints are S 12 + N 22 + W 12 + E 14. The 4 ft W-15 panel is an erected non-lateral spandrel counted for the base tie-down and premium; it is not a Stage A segment because the P-3 opening reaches the foundation. The installed cost is below the $395,000 cap by $8,136 (2.1 %). The 11 ft deep wall above EY-1 is a non-lateral shell spandrel outside the 81-panel PCS-014 lateral count and outside the PROC-114 lateral scope; its cost is excluded, because DAP-2 s3 treats EY-1 (which reaches the foundation) as a gap and the spandrel carries no in-plane lateral force.
## 9. Alternatives rejected
1. **Special precast shear walls ($R=5$, $C_d=5$).** Permitted in SDC D to 160 ft (UFC Table 3-1 row A.1) and would reduce $C_s$ to 0.11, but the special premium is $4,120/panel ($+$183,870 on 81 panels) and the RPC-60D JC3 connector is $1,240 each ($+$51,300 on 60 joints); the total would exceed the cap before deck and anchorage. The intermediate system is the cost-efficient permitted choice.
2. **Ordinary precast shear walls.** NP in SDC D (UFC Table 3-1 row A.7); not permitted.
3. **C1 L4x4x3/8 edge chords/collectors.** $\phi P_n=42.1$ kip compression at 8 ft is below the S-line design force 246.7 kip (and below the W/E design force 77.4 kip); rejected.
4. **C2 L6x4x1/2 on S/N.** $\phi P_n=86.5$ kip is below the S-line design force 246.7 kip; rejected (C2 is adequate and used on W/E, where the design force is 77.4 kip).
5. **C3 W8x31 on W/E.** $\phi P_n=272$ kip is adequate but the rate is $36.20/lf against $18.90/lf for C2; the W/E design force is only 77.4 kip, so the C3 is an unnecessary cost; rejected.
6. **C4 W12x53.** $\phi P_n=540$ kip would give more reserve but $62.50/lf would add about $22,000 and push the total over the cap; rejected.
7. **Separate DR-* drag-strut members in addition to the CH chords.** The S-201 schedule puts the DR lines on the same alignments as the CH lines; two members on one line would duplicate the 840 lf cost. S-201 note 3 permits a line to be left out; the continuous CH member carries the collector/drag force. Rejected.
8. **JC2 or JC3 joint connectors.** JC1 $\phi V_n=18$ kip exceeds the largest joint demand 6.36 kip. JC2 and JC3 cost $610 and $1,240 against $385 and increase the panel coupling and tie-down demands; rejected.
9. **JC0 isolated panel piers.** Would reduce the S tie-down but JC1/JC2 are the connectors qualified for intermediate precast shear walls (RPC s2); JC0 is not a qualified intermediate-precast joint. Rejected.
10. **BA3 base tie-downs on all panels.** BA3 $\phi T_n=126$ kip against the largest demand 64.59 kip; the extra $14,630 would raise the total to $401,494, over the cap. BA2 is adequate. Rejected.
11. **WA1 on the S/N walls.** The joists run parallel to the S/N walls, so there are no joist seats and WA1 is not constructible there; WA2 embed-plate-and-strap is used. Rejected.
12. **WA3 anchors.** $\phi T_n=23.25$ kip is more than the 6.04 kip demand and costs $305 against $96/$172; rejected.
13. **P4 attachment in the high-shear zones.** P4 $\phi S_n=852$ plf is below the 1,075 plf Z10 demand; P5 is required. All zones use P5, which also gives the reserve at Z2/Z6/Z11. Rejected.
14. **Flexible-only distribution.** PR-07 and SDC-02 s10 require the envelope of flexible, rigid and semi-rigid; a flexible-only distribution is not accepted. Rejected.
15. **ASCE 7-22 12.10.3 or 12.10.4.** SDC-02 s5 expressly says they are not used on this project. Rejected.
16. **Mixed BA1/BA2 base tie-downs.** BA1 $\phi T_n=33$ kip is below the governing panel demand on every wall (S 64.59, W 60.51, E 52.28, N 40.34 kip), so the wall-level base anchor must be BA2. A per-panel mix would save about $6,240 on the 16 panels whose individual demand is at or below 31.35 kip, not the $30,030 estimated in the review (which assumed only four panels need BA2); the template's wall-level base_anchor mark and the PROC-114 one-assembly-per-panel quantity basis report BA2 for all panels, and that conservative uniform selection is kept so the record and the cost table agree. Rejected as a record-keeping/cost-optimisation change, not a safety issue.
17. **Modelling EY-1 as a spandrel.** DAP-2 s3 defines a spandrel as an opening that does not reach the foundation; PC-301 shows EY-1 from the wall base to +20 ft. EY-1 is a gap; ignoring the 11 ft deep precast beam above it is conservative for the W-wall force distribution and the deflection still satisfies the 4.0 in limit. Rejected.
## 10. Deflection and drift
Diaphragm deflection is taken from the semi-rigid Stage B model and amplified as $C_d\delta/I_e$ (SDC-02 s7; DAP-2 s6.2). The maximum amplified diaphragm-plus-wall deflection is 2.60 in at S10, against the Engineer of Record's permissible 4.0 in (SDC-02 s7; OBD s3.1), utilisation 0.651. The maximum amplified storey drift is 0.259 in at S10, against the ASCE/SEI 7-22 Table 12.12-1 allowable for Risk Category III "all other structures" of $0.015h_{sx}=0.015\times28\times12=5.04$ in, utilisation 0.051. The S11/S12 erection cases are lower (0.68 and 2.24 in). The S03/S04 values (2.56/2.59 in) are the largest base cases because the N-S diaphragm is 240 ft long; the limit is still satisfied with 35 % reserve.
## 11. Erection-stage design
ERC-07 s3 sets the construction-stage seismic load at 0.5 times the permanent-condition load; all other parameters (importance factor, response modification, accidental torsion) are unchanged. ERC-07 s4 identifies the governing temporary condition: the perimeter panels are erected and braced but the roof deck east of X=180 ft is not yet fastened; the fastened diaphragm does not extend over that part of the plan and the wall segments there have no diaphragm support. Cases S11 (X) and S12 (Y) of SDC-02 s8 are that condition. The Stage B model for S11/S12 therefore uses only the mesh west of X=180 ft (284 elements) and removes the E-wall springs; the S/N springs east of X=180 ft are removed as well. The resulting wall forces are S11: S 55.8, N 47.0, W 0, E 0 kip; S12: S 34.7, N 34.7, W 102.8, E 0 kip. The E wall's diaphragm force is zero in that stage; its own construction-stage inertia is $0.5C_s\times308.9=21.2$ kip, carried by 9 raking braces at 20 ft (12 kip each = 108 kip; utilisation 0.196). The eastern S/N segments carry 4.7 and 8.3 kip, carried by 6 braces at 20 ft (72 kip; utilisation 0.181). The permanent connections are not relied on for the unfastened stage. The temporary support and the 12 kip/20 ft brace requirements are 29 CFR 1926.704(a)/ERC-07 s2.
## 12. Verification and quality checks
The package was recomputed from its own files. The Stage A implementation reproduces DAP-2 Appendix A VP-1 exactly (Table in Section 4). The Stage B equilibrium ratio (sum of wall spring reactions divided by $F_{px}$ plus parallel-wall inertia) is 0.9986 to 1.0000 for every case. The following checks all pass:
| Check | Demand | Capacity | Utilisation |
|---|---|---|---|
| Deck zone Z10 (worst) | 1,075 plf | 1,101 plf | 0.976 |
| Base tie-down S (worst panel) | 64.59 kip | 66.0 kip | 0.979 |
| Base tie-down W | 60.51 kip | 66.0 kip | 0.917 |
| Base tie-down E | 52.28 kip | 66.0 kip | 0.792 |
| Base tie-down N | 40.34 kip | 66.0 kip | 0.611 |
| Wall anchor W/E (WA1 @ 8 ft) | 6.04 kip | 7.05 kip | 0.857 |
| Wall anchor S/N (WA2 @ 8 ft) | 6.04 kip | 13.95 kip | 0.433 |
| Chord/collector CH-S (C3) | 246.7 kip | 272.0 kip | 0.907 |
| Chord/collector CH-W (C2) | 77.4 kip | 86.5 kip | 0.895 |
| Diaphragm deflection | 2.60 in | 4.00 in | 0.651 |
| Storey drift | 0.259 in | 5.04 in | 0.051 |
| Installed cost | $386,864 | $395,000 | 0.979 |

The closest checks are deck Z10 (0.976), base tie-down S (0.979) and installed cost (0.979); all are below 1.00 with the reserve stated. The collector member CH-S is at 0.907, the wall anchor W/E at 0.857, and the joint connectors at 0.353 or less. No hard check is at or above unity. The `ahpele_reqscan.py --register` check reports 162 register rows with no missing values, no unmatched documents and no multi-clause rows; `--check` reports 25/25 strong project-document candidates reviewed.
## 13. Direct answers to the brief
**What system did you select and why is it cost-efficient?** Intermediate precast concrete shear walls, $R=4$, $\Omega_0=2.5$ (2.0 collectors), $C_d=4$, permitted by UFC 3-301-01 Table 3-1 row A.6 in SDC D to 40 ft at a 28 ft height. It is the cheapest permitted system: ordinary precast is NP in SDC D and special precast costs $+$235,000 or more in premium and JC3 connectors, over the cap.
**How did you resolve the conflicts?** The thirteen resolutions in Section 3; the key ones are Risk Category III (not II), Site Class D and the ASCE 7-22 RC III Site D motions (not GEO-2019-118/Parcel 4B), the erected geometry of RFI-041/ERL-2026-08 (not PC-101), the 44 ft EY-1 and 16 ft L-2, the DAP-2 gap-versus-spandrel rule, 12.10.1/12.10.2 (not 12.10.3/12.10.4), $\Omega_0=2.0$ for collectors, and the archive documents as record-only.
**What is the governing check on each wall line?** S: base tie-down BA2 64.59/66 = 0.979; N: base tie-down BA2 40.34/66 = 0.611; W: base tie-down BA2 60.51/66 = 0.917; E: wall anchor WA1 6.04/7.05 = 0.857. Joint connectors are not governing on any line (max 6.36/18 = 0.353).
**What alternatives did you reject?** Special and ordinary precast, C1/C2/C4 edge chords, C3 on W/E, separate DR members, JC2/JC3/JC0 joints, BA3 all panels, WA1 on S/N, WA3, P4 in high-shear zones, flexible-only distribution, 12.10.3/12.10.4, and EY-1 as a spandrel. The reasons are in Section 9.
**What is the installed cost against the budget?** $386,864 against the $395,000 cap: $8,136 (2.1 %) under. The cost covers deck attachment, chords/collectors/drag struts, joint connectors, base tie-downs, wall anchors and the intermediate-precast SFRS premium at the PROC-114 Rev 2 rates.
**What do the five deliverables contain?** `design_record.json` is the machine-readable design (SFRS, seismic basis, as-built piers, deck zones, collector lines, wall lines, conflicts, reported forces and cost). `diaphragm_plan.dxf` has the two roof plan views (E-W and N-S) with $w_{px}$, the zone shears and patterns, the four wall-line forces, the CH/DR/OP runs and their axial forces, the deck zone boundaries, the revision block and the LRFD statement. `seismic_calculations.xlsx` has the six required sheets plus deck zones, Stage A VP-1/segments/tie-downs, Stage B analysis, checks, shear cases and cost. `constraint_register.xlsx` has 162 requirement rows with document, clause, value and items bound. This file is the design basis narrative.
**Design conclusion.** The package is a complete, LRFD, DAP-2-compliant design of the Building B lateral load path. Every hard check has a positive margin; the two closest are the deck at Z10 (0.976) and the S base tie-down (0.979), both below 1.00 with the demand and capacity reported. The installed cost is $8,136 below the cap. The design is issued for the delegated design of Building B.
