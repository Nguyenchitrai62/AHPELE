# Design basis - Condenser water heat rejection replacement, Papago Federal Center, Phoenix, Arizona

Revision C issue, September 2026 (incorporating RFI-031 of 21 August 2026 and RFI-034 of 4 September
2026). Prepared for the General Services Administration by Sandoval Klee Mechanical Engineers, PC. This
basis accompanies `CT_SCHEDULE_CUP.dxf`, `CT_CALC_CUP.xlsx`, `CT_SCHEDULE_ANNEX.dxf`,
`CT_CALC_ANNEX.xlsx`, `CT_SCHEDULE_LAB.dxf` and `CT_CALC_LAB.xlsx`.

## 1. Governing documents and status

DC-02 Revision 3 (14 August 2026) is the governing design-criteria memorandum and is the authority for the
hierarchy below. The documents applied are:

* UFC 3-410-01, *Heating, Ventilating and Air Conditioning Systems* (28 July 2025, Change 1) - adopted in
  full; governs the outdoor design condition for equipment sizing (paragraph 2-4.2.4).
* GSA PBS-P100, *Facilities Standards for the Public Buildings Service* (2024) - adopted in full; governs
  plant configuration, the cooling-robustness (redundancy) wet-bulb basis (5.1.3), siting separations
  (Table 5.2), materials (5.3.3.11) and the roof-to-basin clearance (5.3.2.3).
* UFM 3-230-13, *Industrial Water Treatment* (5 February 2026) - adopted for the treatment programme, the
  water balance and the scaling indices.
* UFC 3-230-13 (2023) - SUPERSEDED by UFM 3-230-13; retained for reference only and not cited as
  authority. UFC 3-400-02 (2018, Change 2) - CANCELLED; retained for reference only and not cited as
  authority; no design value is taken from it.
* 10 CFR Part 431 Subpart B (electric motors) and 10 CFR Part 436 Subpart A (life-cycle cost).
* EC-01 Life-Cycle Cost Analysis Criteria, Revision 0 - adopted; the base date, schedule, basic design,
  cost data and study period of the life-cycle cost analysis.
* *Annual Supplement to NIST Handbook 135*, 2025 edition (NIST data release doi:10.18434/mds2-3848) -
  adopted as the source of the discount rate and present-value factors. NIST IR 85-3273-39 (2024 edition)
  is SUPERSEDED and none of its rates, factors or example numbers is used.
* EnergyPlus reference implementation source (`CondenserLoopTowers.cc`, `ChillerElectricEIR.cc`,
  `Psychrometrics.cc`/`.hh`, `CurveManager.cc`) and the performance data sets `Chillers.idf` and
  `PerfCurves.idf` - adopted as the simulation basis: the variable-speed tower approach correlation and its
  validity limits, the fan power and water-use treatment, the electric chiller capacity and input-ratio
  model, and the psychrometric property relations.
* Section 23 65 00 - Cooling Towers (14 August 2026). Section 23 25 00 is a closed-hydronic excerpt and
  does not apply to the open condenser water system.
* WT-01 Revision 1 (14 August 2026); PW-LTR-014 (3 July 2026); PW-LTR-019 Amendment No. 1 (2 September
  2026); UT-01 (22 September 2025); RFI-031 (21 August 2026); RFI-034 (4 September 2026).
* M-401 Revision C (31 July 2026) - governs the equipment zones and outdoor air intake positions. M-401
  Revision B is SUPERSEDED and its zones and intakes are not used. S-401 Revision C (31 July 2026) governs
  the allowable superimposed loads. E-501 and E-601 Revision C govern the motor control centres.
* Vendor submittals VD-01 to VD-05 (reviewed, 2026).

## 2. Documented conflicts

CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE GSA PBS-P100 5.3.1

CONFLICT 2: ADOPTED UFM 3-230-13 5-3 | SET ASIDE UFC 3-230-13 5-3

CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401 Revision B

Conflict 1 is resolved as DC-02 paragraph 2 allocates outdoor design conditions for equipment sizing to the
adopted HVAC criteria: the tower is sized on the 1.0 percent annual wet bulb plus the 5 deg F adder of UFC
3-410-01 paragraph 2-4.2.4, not on the 0.4 percent dew-point basis named in PBS-P100 paragraph 5.3.1. The
0.4 percent evaporation design wet bulb that PBS-P100 5.1.3 names is retained for the cooling-robustness
(redundancy) calculation only, with the same 5 deg F adder (DC-02 5.2, 6.3 and RFI-031 Response 1); the two
bases are therefore applied to the two different calculations the two documents govern, and neither is
waived. Conflict 2 is the edition conflict between the two industrial water treatment manuals; DC-02
paragraph 2 and RFI-031 Response 3 make the 2026 UFM the governing edition, and the 2023 document is not
cited as authority. Conflict 3 is the roof plan revision; DC-02 paragraph 2 and RFI-031 Response 3 make
M-401 Revision C governing, and Revision B's zones and intake positions are not used.

Two further disagreements in the library are resolved by the same hierarchy. PBS-P100 paragraph 5.3.3.11
prohibits galvanised steel on water-contact surfaces while the VD-01 standard offering is the G-235
galvanised casing; the project requirement governs and SS-304 is selected. PBS-P100 paragraph 5.3.5.3 caps
open-system total dissolved solids at 1,500 ppm while the reclaimed supply already contains 1,720 ppm before
any concentration; DC-02 paragraph 2 expressly states that the cap does not govern this reclaimed-water
supply and that the alkalinity range of the same paragraph is met by the WT-01 acid feed, so no
cycles-of-concentration limit is taken from PBS-P100. The 2024 NIST supplement is superseded by the 2025
data release for every rate and factor (EC-01 4), and Section 23 25 00 is expressly a closed-hydronic
excerpt that does not apply to the open condenser water system.

## 3. Weather basis

Governing station: Phoenix Airport (NCEI station 72278023183), Local Climatological Data for the three
complete calendar years 2022, 2023 and 2024 (DC-02 5.1). Only FM-15 and FM-16 observations are used; daily
and monthly summary rows are excluded. The resulting period of record is 26,527 hourly observations.

Percentiles are taken over the whole POR as one annual population (DC-02 5.2):

* 1.0 percent annual wet bulb = 75.0 deg F; design outdoor wet bulb for tower sizing = 75.0 + 5.0 =
  **80.0 deg F** (UFC 3-410-01 2-4.2.4).
* 0.4 percent annual wet bulb = 76.0 deg F; failure-case (redundancy) wet bulb = 76.0 + 5.0 =
  **81.0 deg F** (PBS-P100 5.1.3, DC-02 5.2 and 6.3, RFI-031 Response 1).
* 99.6 percent annual dry bulb = **41.0 deg F** (DC-02 5.4). It is above 32 deg F, so no basin heater and
  no heat-traced makeup are required; `BASINHEATER` is NO on all three schedules.

The two adopted documents state the wet-bulb basis differently and the difference is applied deliberately:
UFC 3-410-01 2-4.2.4 (1.0 percent + 5 deg F) governs tower selection and the design point, while PBS-P100
5.1.3 (0.4 percent evaporation design wet bulb + 5 deg F) governs the failure case only. The design wet
bulb of 80.0 deg F coincides with the maximum inlet wet bulb of the adopted YorkCalc performance object
(26.6667 deg C); the reference implementation clamps the inlet wet bulb there and the value is not
extrapolated (DC-02 6.8, RFI-031 Response 1).

Mean station pressure over the POR = 28.722 inHg = 97,264 Pa; this is the barometric pressure used in the
psychrometric routines (DC-02 5.5). The scenario bins are 2 deg F wet-bulb bins and 5 deg F dry-bulb bins
with edges at whole multiples of the width from zero, bin mid-points, and counts scaled to 8760 hours per
year (DC-02 5.3). The 180 populated bins sum to exactly 8760 hours. Where a dry-bulb mid-point falls below
its wet-bulb mid-point the dry bulb is set equal to the wet-bulb mid-point.

## 4. Evaporation formulation

The water balance, the allocation and discharge checks and the `WaterBalance` sheet use the
**SATURATED-EXIT** formulation of DC-02 paragraph 7, the moist-air method of the adopted reference
implementation's tower water-use routine: the inlet air enthalpy is that of saturated air at the inlet
wet-bulb temperature, the outlet air is saturated at the inlet enthalpy plus the water-side heat rejection
divided by the air mass flow, and the evaporated mass is the air mass flow times the rise in specific
humidity, converted to a volume with the density of water. The water density is the DC-02 7 expression
rho = 1000 x (1 - (T + 288.9414)/(508929.2 x (T + 68.12963)) x (T - 3.9863)^2) kg/m3 at the mean of the
inlet dry-bulb and the saturated outlet air temperatures, not below 4 deg C. Blowdown is E/(COC-1) less
drift and makeup is the sum of evaporation, drift and blowdown. Drift is the certified DE-2 rate applied to
the design flow per cell, the number of cells in service and the air flow ratio (VD-04 1).

SATURATED-EXIT is also the formulation EC-01 paragraph 6 requires the life-cycle cost analysis to price,
so the water balance and the life-cycle cost use the same water quantities. The LOSS-FACTOR formulation of
UFM 3-230-13 is not used anywhere in the package; it is recorded here only to state the choice. Each
workbook declares `EvaporationMethod = saturated-exit`, and the schedule declares
`EVAPMETHOD = SATURATED-EXIT`; the two agree.

## 5. Calculation method

* **Tower.** Each cell is modelled with the variable-speed `CoolingTowerPerformance:YorkCalc` correlation
  (counterflow) of the adopted performance data set: the approach is evaluated at the water flow rate
  ratio, air flow rate ratio, inlet wet bulb and range, in the SI units of the object, and converted to
  deg F. The object's limits are applied at every scenario (WFR 0.75-1.25, range 2-40 deg F, approach
  2-72 deg F, L/G <= 8); the inlet wet bulb is clamped to the object's 26.6667 deg C maximum, which is the
  design value at this site, and the water flow rate ratio is never clamped or extrapolated (DC-02 6.8).
* **Fan.** Full speed when the full-speed outlet is warmer than the setpoint; modulation between the 30
  percent minimum controllable air flow and full speed to hold the setpoint; minimum-speed cycling below
  that; free convection at an air flow ratio of 0.125 with the fan off. Fan shaft power follows the cube
  law of VD-02, divided by the motor efficiency and the 0.97 VFD efficiency to give electrical input.
* **Chiller.** The three procured machines are modelled with their `Chiller:Electric:EIR` data sets:
  available capacity = reference capacity x CAPFT at the design leaving chilled water temperature and the
  operating entering condenser water temperature; power = (available capacity/COP_ref) x EIRFT x
  EIRFPLR(PLR) x cycling fraction. The entering condenser water temperature is the tower supply
  temperature. Staging is the smallest number of machines whose available capacity (CAPFT x reference
  capacity, without the maximum part-load ratio) meets the block load (DC-02 6.5).
* **Pumps.** One constant-speed pump per running chiller, head H = H_static + (H_pipe + H_condenser)
  (Q/Q_ref)^2 with the DC-02 6.4 constants, shaft power QH/(3960 eta) and electrical input
  shaft x 0.7457/eta_motor.
* **Cells.** Cells are isolated one at a time only when the per-cell flow would fall below the effective
  minimum, the larger of the VD-01 minimum flow and 0.75 x nominal (DC-02 6.6). Fans of cells in service
  modulate together.
* **Reset.** CWS setpoint = larger of the scheduled floor and outdoor wet bulb + offset, never below the
  chiller minimum entering condenser water temperature (DC-02 6.7). A condenser water bypass holds the
  setpoint when the tower would otherwise overcool. Floors and offsets: CUP 65 deg F / 11 deg F; ANNEX
  80 deg F / 11.5 deg F; LAB 58 deg F / 8.5 deg F.
* **Design point.** All chillers and all cells in service at full fan speed at 80.0 deg F wet bulb and the
  design block load. `DesignPoint` reports the achieved values; the DXF carries the scheduled, conservative
  CWS, which is the reset setpoint at the design wet bulb (91.0 / 91.5 / 88.5 deg F).
* **Redundancy.** Largest cell out of service, design condenser water flow unchanged, remaining cells at
  full fan speed, at 81.0 deg F wet bulb (evaluated at the object's 80.0 deg F clamp). Redundancy capacity
  is the sum of the machines' available capacity at the CWS the remaining cells produce.

## 6. Plant selections

| Plant | Cells | Model | Total flow (gpm) | Per cell (gpm) | WFR | CWS floor/offset (deg F) | COC | Material | Eliminator | Motor |
|---|---|---|---|---|---|---|---|---|---|---|
| CUP | 4 | CTX-0600-S | 1800 | 450.0 | 0.750 | 65 / 11.0 | 4.13 | SS-304 | DE-2 | 20 hp, 91.7 %, 6 pole TEFC |
| ANNEX | 4 | CTX-0600-S | 1800 | 450.0 | 0.750 | 80 / 11.5 | 3.99 | SS-304 | DE-2 | 20 hp, 91.7 %, 6 pole TEFC |
| LAB | 3 | CTX-0900-H | 2025 | 675.0 | 0.750 | 58 / 8.5 | 3.86 | SS-304 | DE-2 | 20 hp, 91.7 %, 6 pole TEFC |

The cell count is a whole multiple of the number of chillers (4/2, 4/2, 3/3) and all cells of a plant are
identical (DC-02 6.1). The design flow gives 900 gpm per chiller at CUP and ANNEX and 675 gpm at LAB,
inside the VD-03 limits (750-1800 gpm for CH-A/CH-B, 532-1278 gpm for CH-C), and 450 or 675 gpm per cell,
inside the VD-01 limits (300-720 gpm for the CTX-0600, 450-1080 gpm for the CTX-0900). The flow rate ratio
is 0.750, the lower limit of the performance object, at all three plants: it is the LCC-optimal flow
because the pump power and the condenser range fall with flow and the small approach penalty is more than
offset by the lower condenser water temperatures the chillers see. Every fan motor is on a VFD and is the
premium-efficiency offering, which is the only offering that meets the federal minimum efficiency of
10 CFR 431.25 Table 3 for an enclosed 6-pole motor.

Materials: PBS-P100 5.3.3.11 prohibits galvanised steel on water contact surfaces, so G-235 is not used.
SS-304 is the lowest life-cycle cost compliant option (FRP-PV is cheaper first cost but its 20-year life
requires a replacement at year 21 that costs more than the first-cost saving). Drift: DE-2 is the
lowest-cost eliminator that meets the Section 23 65 00 2.3 limit of 0.002 percent; DE-3's extra cost is not
recovered by the very small water saving.

## 7. Governing constraints

The six relative margins are evaluated as DC-02 paragraph 9 defines them, with the peak coincident demand
and annual makeup reported in the workbooks and the scheduled design approach (CWSDESIGN less WBDESIGN):

| Plant | water allocation | electrical capacity | roof area | structural capacity | condenser flow limit | tower capability |
|---|---|---|---|---|---|---|
| CUP | 0.0541 | 0.0283 | 0.2727 | 0.0250 | 0.2000 | 0.5126 |
| ANNEX | 0.0035 | 0.0327 | 0.3120 | 0.0565 | 0.2000 | 0.5048 |
| LAB | 0.0197 | 0.0125 | 0.2244 | 0.0162 | 0.2688 | 0.2957 |

GOVERNING CONSTRAINT CUP: structural capacity (relative margin 0.0250)

GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0035)

GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0125)

CUP: the four CTX-0600-S cells stand two in the 126 psf framing zone (CUP-S1) and two in the 120 psf zone
(CUP-S2). The operating weight is 23,400 lb over the 200 sq ft support frame, 117.0 psf, so the S2 cells
give (120 - 117.0)/120 = 0.0250. The electrical margin is (528 - 513.0)/528 = 0.0283
and the water margin 0.0541; both are larger than the structural margin, so structural
capacity governs. The two margins are within 0.004 of each other, so either name is admissible under
DC-02 9; structural capacity is stated because it is the smallest.

ANNEX: annual makeup is 12,555 kgal against the amended firm allocation of 12,600 kgal (PW-LTR-019),
a margin of 0.0035. The electrical margin is (590 - 570.7)/590 =
0.0327 and the structural margin 0.0565; both are larger, so the
water allocation governs. The allocation, not the energy or the first cost, is what limits the ANNEX design:
the lowest-LCC four-cell CTX-0600-S arrangement is adopted with a raised 80 deg F
floor and an 11.5 deg F reset offset, which reduce the tower air flow and the
evaporation enough to bring the annual makeup inside the firm allocation. The margin is small because the
allocation is the binding constraint; the scheduled cycles of concentration are one hundredth below the
allowable and the makeup is computed with the exact adopted simulation basis.

LAB: peak coincident demand 633.1 kW against the 641.14 kW spare (660 kW less the 18.86 kW of the
three RFI-034 exhaust fans), a margin of 0.0125. The structural margin is
(126 - 123.96)/126 = 0.0162 and the water margin 0.0197; both are within 0.004 of the
electrical margin or larger, so electrical capacity governs. The CTX-0900-H casing is selected for LAB
because its lower fan power is what keeps the plant inside the MCC-R3 spare; the CTX-0900-S alternative
exceeds the spare capacity at every feasible control setting.

The design point achieved values are: CUP CWS 85.36 deg F, range 12.66 deg F, approach
5.36 deg F, CWR 98.02 deg F, heat rejection 11,395,759 Btu/h; ANNEX CWS
85.69 deg F, range 13.68 deg F, approach 5.69 deg F, CWR
99.38 deg F; LAB CWS 85.99 deg F, range 14.60 deg F, approach
5.99 deg F, CWR 100.58 deg F. The scheduled CWS is 91.0, 91.5 and 88.5 deg F
respectively, the reset setpoint at the design wet bulb, so the tower-capability margin is positive at the
design point and the schedule is conservative as DC-02 6.9 permits. At the scheduled CWS the available
capacities are 876 / 901 / 1,275 tons against the 820 / 880 / 1,070 ton block loads, so the machines carry
the load at the scheduled entering condenser water temperature as DC-02 6.9 requires.

## 8. Water chemistry, cycles of concentration and allocation

The analysis of record is the 26 July 2022 complete analysis of the Water Quality Portal result set (WT-01
paragraph 2): dissolved calcium 109 mg/L as Ca (calcium hardness 109 x 2.497 = 272.2 mg/L as CaCO3),
dissolved alkalinity 195 mg/L as CaCO3, total dissolved solids 1720 mg/L as measured residue on evaporation
(the value of record; the 1610 mg/L constituent-computed value is not used), dissolved sulfate 205 mg/L and
dissolved silica 16.0 mg/L. The earlier 2021 analysis and the field-parameter-only visits are superseded.

The acid feed holds the circulating M-alkalinity at 120 mg/L as CaCO3; total dissolved solids and calcium
hardness cycle with the cycles of concentration (WT-01 3). The allowable cycles are the lowest of the
manual's silica limit (150/16.0 = 9.375) and the cycles at which the Practical (Puckorius) Scaling Index
at the design condenser water return temperature equals the programme's 5.60 minimum: 4.14
at CUP's 98.02 deg F CWR, 4.00 at ANNEX's 99.38 deg F and
3.88 at LAB's 100.58 deg F. The scheduled cycles of 4.13,
3.99 and 3.86 are one hundredth below those limits and give PSI
5.602, 5.602 and 5.604, at or above 5.60. The calcium carbonate and
calcium sulfate predictions do not control because the inhibitor package addresses both, and calcium
phosphate does not apply because the circulating orthophosphate is held below 10 ppm (WT-01 4).

The return temperature used for the index is the CWR the `DesignPoint` sheet reports - the temperature the
selected cells actually produce at the design point with every chiller and every cell at full fan speed -
not the scheduled supply plus range (WT-01 4: "the return temperature the selected cells actually produce
there ... not a scheduled figure"). The design point sheet reports 98.02, 99.38
and 100.58 deg F.

At the scheduled cycles the SATURATED-EXIT water balance gives annual makeup 9,743 /
12,555 / 17,057 kgal against the firm allocations of 10,300 / 12,600 (PW-LTR-019
amended) / 17,400 kgal; peak-day makeup 49,828 / 53,136 / 74,540 gal
against 58,000 / 62,000 / 80,000 gal; and peak-day blowdown 12,035 / 13,287 /
19,266 gal against 14,500 / 15,800 / 20,800 gal. All three plants are inside their allocation,
peak-day and discharge limits. The peak day is the design outdoor wet bulb, the design block load and the
112 deg F dry bulb at which the M-603 block load is reached, as PW-LTR-014 paragraph 2 defines it.

## 9. Life-cycle cost analysis

The base date is 1 October 2025, with a one-year design and construction period and beneficial occupancy on
1 October 2026 (EC-01 2 and 3). The study period is 26 years from the base date: one construction year plus
the 25-year service life of the longest-lived admissible casing (SS-304 or SS-316), as 10 CFR
436.14(d)(2)(i) requires for mutually exclusive alternatives. Investment is a lump sum at the base date;
energy, water and non-fuel O&M costs accrue from beneficial occupancy, so their present values use the
2025 supplement's factors for years 2 through 26, that is the tabulated 26-year factor less its year-1
term (10 CFR 436.16(c), 436.17(b), 436.17(d)).

The real discount rate is 3.0 percent (the DOE floor in the 2025 Discount Rate Memo). The electricity
uniform present worth factor is that of the 2025 supplement for Arizona, Mountain division, commercial
sector, electricity: UPV*(26) = 16.30610; the year-1 term is 1/1.03 = 0.97087, and costs begin at
beneficial occupancy in year 2, so the factor used is 16.30610 - 0.97087 = 15.33522. The water factor
restates the Authority's 3.5 percent nominal forecast with the supplement's 1.5 percent long-term inflation
rate, giving a 1.9704 percent real escalation, and uses years 2-26: 21.77700. The non-fuel O&M factor is the
3.0 percent annuity over years 2-26: 16.90597.

Prices: electricity $0.0712/kWh plus $17.80/kW-month applied to the peak coincident demand for all twelve
months because of the UT-01 ratchet; reclaimed makeup $1.94/kgal and blowdown $3.20/kgal; water treatment
$0.42/kgal of makeup; routine maintenance $3,200 per cell-year; investment from VD-05 (cell base price plus
the SS-304 and DE-2 and premium-motor adders, rigging at 0.85 USD/lb of operating weight, connections
14,000 USD/cell and plant controls 60,000 USD/plant). The SS-304 cells have a 25-year life equal to the
service period, so there is no replacement and no salvage.

Basic design (EC-01 5): three CTX-0900-S cells at 2,100 gpm, fixed 85 deg F setpoint, COC 3.0, DE-2,
SS-304 and the premium motor, evaluated with the same simulation basis and priced the same way. Its
life-cycle costs are 5,889,905 USD (CUP), 7,893,801 USD (ANNEX) and
8,065,801 USD (LAB).

| Plant | Investment (USD) | LCC (USD) | Basic LCC (USD) | Net savings (USD) |
|---|---|---|---|---|
| CUP | 786,200 | 5,649,350 | 5,889,905 | 240,555 |
| ANNEX | 786,200 | 7,647,135 | 7,893,801 | 246,666 |
| LAB | 926,220 | 7,774,824 | 8,065,801 | 290,978 |

The selected design of each plant is a compliant design at or within 0.2 percent of the highest net savings
found in the search over cell model, cell count, design flow, reset floor and offset, casing, material and
eliminator. The LAB plant
uses the CTX-0900-H casing because its fan power is low enough to keep the peak coincident demand inside
the MCC-R3 spare; the CUP and ANNEX plants use the CTX-0600-S because the larger casings do not fit the
framing zones structurally. ANNEX's selection is water-limited: the annual makeup is held inside the
12,600 kgal firm allocation by the 80 deg F floor and the 11.5 deg F
reset offset, which reduce the annual tower air flow and the evaporation. The selected point is on the
allocation-limited frontier: lower floors or lower offsets exceed the allocation, and higher floors or
higher offsets reduce the net savings. The remaining annual margin is 45 kgal (0.36 percent), which is the
reserve the firm allocation itself allows at this plant; the cycles of concentration are one hundredth
below the allowable so that part of the reserve is not consumed by schedule rounding.

## 10. Margins, judgement calls and interpretations

* The scheduled CWS is the reset setpoint at the design wet bulb, deliberately conservative relative to the
  85.36-85.99 deg F the cells achieve at full fan speed (DC-02 6.9). `DesignPoint`
  reports the achieved value, not the scheduled value; the two are separated exactly as DC-02 Appendix A.2
  requires. The tower-capability margin is computed from the scheduled approach.
* The cycles of concentration are set one hundredth below the allowable cycles at the design CWR, so the
  PSI stays at or above 5.60 with a visible reserve against the two-decimal rounding of the schedule.
* Evaporation: SATURATED-EXIT is declared and used for the water balance, the allocation and discharge
  checks and the life-cycle cost. It is the moist-air method of the adopted reference implementation and
  the method EC-01 6 prices, so the declared balance, the priced balance and the simulation basis are the
  same. LOSS-FACTOR is not used.
* The design point CWR used for the scaling index is the achieved full-fan return temperature the
  `DesignPoint` sheet reports, as WT-01 4 directs. The scheduled supply is warmer, which is conservative for
  the design point check but is not used to compute the index.
* Air-inlet clearance: the 6 ft clearance of VD-01 7 is held between adjacent cells and to the equipment
  zone boundary. CUP places four 10 ft x 20 ft cells on a 74 ft x 32 ft envelope inside the 74 ft x 44 ft
  zone; ANNEX places the same four cells on a 70 ft x 32 ft envelope inside its 74 ft x 44 ft zone; LAB
  places three 12 ft x 32 ft cells on a 60 ft x 44 ft envelope inside the 74 ft x 46 ft zone. All cells are more than 25 ft from the fixed outdoor air intakes (PBS-P100 Table 5.2): the nearest
  cell face is 32 ft (CUP), 34 ft (ANNEX) and 46 ft (LAB) from the intake. No reduced-clearance
  recirculation analysis is required.
* Structural: the cells are placed entirely within one framing zone each. CUP has two cells in CUP-S1
  (126 psf) and two in CUP-S2 (120 psf); ANNEX has two in ANNEX-S1 (128 psf) and two in ANNEX-S2 (124 psf);
  all three LAB cells are in LAB-S1 (126 psf). The operating weight per support area is 117.0 psf for
  the CTX-0600-S and 123.96 psf for the CTX-0900-H.
* The LAB motor control centre spare is reduced by the three RFI-034 exhaust fans: 3 x 7.5 hp x 0.7457 /
  (0.917 x 0.97) = 18.86 kW, so the spare is 660 - 18.86 = 641.14 kW, not 660 kW. MCC-R1 and MCC-R2 are
  unaffected by RFI-034.
* Redundancy is evaluated at 81.0 deg F, but the performance object clamps the inlet wet bulb to 80.0 deg F,
  so the calculated redundancy capacity is the capacity at 80.0 deg F; this is the adopted simulation basis
  and is applied consistently to the design and the basic design. The cell-out flow per remaining cell is
  600 gpm (CUP, ANNEX) and 1,012.5 gpm (LAB), inside the VD-01 limits and the WFR limit of 1.25.
* The `FanPLR` column is reported as 1.0 whenever the fans run (full speed or modulating), 0.0 when the fans
  are off, and the cycling ratio when the cells cycle at minimum speed, as DC-02 Appendix A.2 defines. The
  speed is reported separately as `AirFlowRatio`.
* The water balance uses drift at the design flow per cell times the air flow ratio (VD-04 1: drift varies in
  proportion to air flow).

## 11. Issue status and actions

No item in the library blocks the issue of this design. The three plants meet every hard limit checked:
the peak coincident demand is inside the motor control centre spare, the annual and peak-day reclaimed
water use is inside the firm allocation, the peak-day blowdown is inside the discharge limit, the
redundancy capacity exceeds the design block load, the cycles of concentration are below the allowable
cycles and the scaling index is at or above 5.60, and every cell is inside its equipment zone, inside one
framing zone and inside the allowable superimposed load.

The actions that remain are execution actions for others, and none changes the design: the contractor is to
provide the automatic blowdown valve and chemical feed (Section 23 65 00 2.4, UFC 3-410-01 Section 908.5),
the makeup and blowdown meters (PW-LTR-014 4), the equalising lines and automatic cell isolation (Section
23 65 00 2.7, PBS-P100 5.3.2.3) and the 4 ft dunnage (PBS-P100 5.3.2.3); the separate Laboratory Wing exhaust
fan contract must connect EF-L7, EF-L8 and EF-L9 to MCC-R3 as RFI-034 describes before the heat rejection
plant is commissioned; and the ANNEX allocation reassignment of PW-LTR-019 takes effect on 1 October 2026,
the beneficial occupancy date used in the analysis. The selected CTX Series C cells are certified to CTI
STD-201 under VD-01 1, so no CTI ATC-105 field acceptance test is required. No industrial discharge permit
is needed because the peak-day blowdown is below the PW-LTR-014 limit, and no electrical service upgrade is
needed because each plant's peak is below its MCC spare capacity.
