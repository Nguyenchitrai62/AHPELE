# Method of Procedure - PCW cleaning, flushing, passivation and turnover

**Project:** Tull Creek Data Hall - Process Cooling Water (PCW) loop  
**Document:** MOP and design basis for Section 23 25 16 (Rev 3, 2026-07-14)  
**Contractor:** flushing contractor (commissioning engineer of record)  
**Turnover milestone:** TM-4, day 47 from mobilisation (CX-01 Rev B); last programmed activity finishes at hour 721.4 (day 30.1)

**Summary of the programme.** Eight circuits, C1 to C8; total programme cost **$96,771**; 623,234 gal of water drawn (peak day 80,197 gal against the 92,000 gal daily limit); 538,725 gal of effluent, of which 307,678 gal to the metered manhole MH-14 (38.5 per cent below the 500,000 gal authorisation) and 231,047 gal by vacuum tanker; two rented skids and two crews; chemical cleaning complete on day 15 (TM-2 is day 22), film formation complete on day 29 (TM-3 is day 44) and turnover complete on day 30, inside TM-4 at day 47. Every circuit passes every one of its constraint families; section 7 states, per circuit, which constraint has the least room and how much.

## 1. Purpose and scope

This MOP is the design basis and the execution narrative for the pre-operational cleaning,
flushing, chemical cleaning, rinsing, passivation and turnover of the eight tie-in-bounded PCW
circuits C1 to C8, and it discharges the obligations of Section 23 25 16 cl.1.6. It is issued
with the flush plan (`flush_plan.csv`), chemistry plan (`chemistry_plan.csv`), acceptance matrix
(`acceptance_matrix.csv`), schedule (`schedule.csv`), resource and cost statement
(`resources.json`) and constraint register (`constraint_register.csv`). Every figure in this
document is taken from those files; where a figure is recomputed the source is named.

Scope boundary: the hydrostatic test pump, the portable holding tank used to move a cascaded
displacement or to hold softened water between tie-ins, and the fine filtration below the VD-05
strainer (380 micron) that CP-311, CP-321 and CP-331 require at 50 micron and CDU-301/CDU-302
require at 300 micron are Contractor scope within the lump-sum mobilisation; they carry no price
line in the cost statement (Section 23 25 16 cl.3.10 f).

## 2. Governing documents and document status

| Document | Revision / date | Status | Use in this package |
|---|---|---|---|
| Section 23 25 16 - PCW Cleaning, Flushing and Passivation | Rev 3, 2026-07-14 | IFC - governing | all method, limits and the cost basis |
| Section 23 21 16 - Hydronic Piping (excerpt) | Rev 3, 2026-07-14 | IFC - governing | roughness, pressure ratings, hydrostatic test |
| Section 01 91 13 - General Commissioning Requirements | Rev 2, 2026-05-28 | IFC - governing | evidence rule for accepted test results, crew limit |
| UFC 3-230-13 Industrial Water Treatment O&M | 1 March 2023 | current edition - governing | closed-system programmes, passivation, rinse criterion, bacterial limit |
| DOE-HDBK-1012/3-92 Fluid Flow Vol. 3 | 1992 | governing by adoption in 23 25 16 cl.1.2 | hydraulic relations |
| 40 CFR 403 General Pretreatment Regulations | 2024 | governing by adoption | discharge prohibitions |
| 29 CFR 1910.1200 Hazard Communication | 2024 | governing by adoption | safety section 11 |
| SW-01 Construction Water Availability Memorandum | 2026-07-02 | governing, as varied by SI-04 | water rates and daily limits |
| SI-04 Construction Water During Utility Main Works | 2026-07-24 | governing variation of SW-01 cl.1 | days 2, 3 and 6 |
| SI-05 Flush Skid Delivery | 2026-07-27 | governing variation of SW-01 cl.3 | FS-1200-A from hour 48 |
| SW-02 Municipal Water Analysis | 2026 | governing | makeup quality |
| SW-03 Sanitary Sewer Discharge Authorization **Rev B** (IWD-2026-0417) | Rev B, 2026-07-21 | governing - supersedes Rev A | 500,000 gal cap, $9.40/kgal, local limits |
| RFI-031 Discharge Route and Metering | 2026-07-06 | governing for the tanker route and rate | MH-14, $168.00/kgal |
| SW-04 Temporary Power Availability | Rev B | governing | kW at each tie-in |
| CX-01 Turnover Milestones | Rev B | governing - contractual | TM-2 day 22, TM-3 day 44, TM-4 day 47 |
| CX-02 Hydrostatic Test Record | partial | record only - four charts missing | retest decision |
| CX-03 Prefunctional Checklist Template | current | governing form | log form |
| M-601 Pipe Schedule | Rev C | governing | lines, lengths, legs, L/D, inside diameters |
| M-602 Equipment Schedule | Rev C | governing | hold-up, dP, max dP, max T, particle size, ratings, bypass |
| M-603 Valve and Tie-In Schedule | Rev C | governing | tie-in tags and locations |
| M-PID-101/102/103/104, M-ISO-201..204 | Rev C | governing | circuit line assignment and static lift |
| C-101 Site Logistics and Laydown | Rev B | governing | skid pads, tanker standing, SV-2 softener |
| VD-01..VD-06, VD-07 SDS pack | Rev B where stated | reviewed submittals - governing | skid curves, limits, strainer, chemistry, SDS |

### 2.1 Documents read and rejected (not cited in the constraint register)

| Document | Why not used |
|---|---|
| UFC 3-240-13FN Industrial Water Treatment (2005), marked CANCELLED | cancelled by Section 23 25 16 cl.1.2; every passivation time and dose quoted from it is taken from the current UFC 3-230-13 instead |
| M-PID-103 PCW CDU Distribution **Rev A**, marked SUPERSEDED | superseded by Rev C (M-601 Note 5); Rev A assigns line 4033 to C4 with 2 legs, Rev C to C5 with 3 legs. Rev C used |
| SW-03 Sanitary Sewer Discharge Authorization **Rev A** | superseded by Rev B (2026-07-21). Rev A quotes a 540,000 gal cap (repeated in RFI-031 of 2026-07-06), $11.20/kgal and sets no molybdenum limit; Rev B quotes 500,000 gal, $9.40/kgal and a 0.5 mg/L molybdenum limit. Rev B applied |
| RFI-009 Roof curb flashing | roofing scope only, no mechanical content |
| Section 22 11 23 Domestic Water Pumps | expressly excludes the PCW system ("not flushed under Section 23 25 16") |
| VD-08 Air-cooled chiller ACCH-500 submittal | expressly not part of the PCW loop |
| 40 CFR 122 NPDES Permit Programs | no NPDES permit is invoked; discharge is to the POTW under 40 CFR 403 as SW-03 states |
| VD-06 product NB-700 (nitrite-borax-azole blend) | offered for comparison only (VD-06 Note 4); nitrite programmes are excluded by the makeup analysis, see 5.5 |

## 3. Circuit definition and physical basis

Circuit limits are the tie-in valves of M-603 read on the P&ID sheets (M-603 Note 1). The line
assignment is read from the drawings because M-601 does not tabulate circuits (M-601 Note 1):

| Circuit | Description | Lines (M-601) | Components (M-602) | Tie-in | Static lift (M-ISO) |
|---|---|---|---|---|---|
| C1 | PCW primary header and pump gallery | 1041, 1042, 1043 x4, 1044 x4 | PMP-101, BT-101 | MER-1 | 26 ft |
| C2 | PCW heat exchanger bay A | 2011, 2012, 2013 x3 | HX-201A | MER-1 | 22 ft |
| C3 | PCW heat exchanger bay B | 2021, 2022, 2023 x2 | HX-201B | MER-2 | 22 ft |
| C4 | PCW CDU distribution north | 4021, 4022, 4023 x2, 4024 x4 | CDU-301, CP-311 | L3-N | 48 ft |
| C5 | PCW CDU distribution south | 4031, 4032, 4033 x3, 4034 x4 | CDU-302, CP-321 | L3-S | 44 ft |
| C6 | PCW CDU distribution west | 4041, 4042, 4043 x3 | CP-331 | L3-W | 48 ft |
| C7 | PCW fan-wall coil branch | 5011, 5012, 5013 x4 | CL-401 | ROOF | 72 ft |
| C8 | PCW makeup and fill riser | 6011, 6012, 6013 x2 | ST-601 | YARD | 14 ft |

| Circuit | Pipe volume (gal) | FLUSH volume V_f (gal) | SYSTEM volume V_s (gal) | Bypassed hold-up (gal) |
|---|---|---|---|---|
| C1 | 25583 | 32983 | 32983 | 0 |
| C2 | 5596 | 5596 | 7946 | 2350 |
| C3 | 6203 | 6203 | 8553 | 2350 |
| C4 | 5957 | 5957 | 8537 | 2580 |
| C5 | 6406 | 6406 | 8986 | 2580 |
| C6 | 4227 | 4227 | 5677 | 1450 |
| C7 | 4086 | 4086 | 6036 | 1950 |
| C8 | 2041 | 5791 | 5791 | 0 |

V_f is pipework - the inside area of each line at its M-601 inside diameter times the developed
length of one leg times the number of parallel legs - plus the hold-up of components that are NOT
bypassed. V_s adds the hold-up of every component whether bypassed or not (Section 23 25 16
cl.3.4, cl.3.6).

The Fittings and Valves Sum L/D column of M-601 is NOT added to the pipe volume. M-601 Note 3
states that the column is "for use with the equivalent-length method", that is for the friction
head of cl.3.2 c, and an equivalent length represents the fitting pressure loss, not the volume
the fitting displaces. Adding it would overstate the water in C1 by 3,990 gal (12 %) and in C3 by
1,172 gal (19 %) and would overstate every dose, rinse and effluent figure in the programme.
Judgement call 14 in section 9A records the choice.

## 4. Hydraulic design basis

All hydraulic quantities follow Section 23 25 16 cl.3.2 and DOE-HDBK-1012/3-92 Vol. 3 with
rho = 62.30 lbm/ft3, nu = 1.08e-5 ft2/s, Colebrook-White friction factor with the absolute
roughness of Section 23 21 16 cl.2.2 (carbon steel 0.00015 ft, galvanized 0.0005 ft, copper
0.000005 ft, hose 0.0008 ft), and the equivalent length method with sum L/D from M-601.

### 4.1 Flushing flow

The flushing flow is the flow that gives, in every leg of every line, the greater of the UFC
3-230-13 foulant-suspension velocity (3.28 ft/s, 5-3.7) and the project class minimum of
Section 23 25 16 cl.3.3 b: 4.0 ft/s for a circuit that serves a plate heat exchanger or a
cold-plate device, 2.0 ft/s otherwise. The governing line is the one whose legs x A is largest,
because it carries the lowest leg velocity; a 3 % design reserve is applied above the criterion
so that rounding in the field record cannot take the circuit below it.

| Circuit | Velocity class | Criterion (ft/s) | Governing segment | Leg ID (in.) | Flushing flow (gpm) | Flushed velocity (ft/s) | Reynolds |
|---|---|---|---|---|---|---|---|
| C1 | other | 3.28 | 1043 | 6.065 | 1216.9 | 3.38 | 158100 |
| C2 | plate HX / cold plate | 4.00 | 2011 | 7.981 | 642.4 | 4.12 | 253700 |
| C3 | plate HX / cold plate | 4.00 | 2023 | 6.065 | 742.0 | 4.12 | 192800 |
| C4 | plate HX / cold plate | 4.00 | 4021 | 6.065 | 371.0 | 4.12 | 192800 |
| C5 | plate HX / cold plate | 4.00 | 4033 | 4.026 | 490.4 | 4.12 | 128000 |
| C6 | plate HX / cold plate | 4.00 | 4041 | 6.065 | 371.0 | 4.12 | 192800 |
| C7 | other | 3.28 | 5011 | 6.065 | 304.2 | 3.38 | 158100 |
| C8 | other | 3.28 | 6013 | 3.068 | 155.7 | 3.38 | 80000 |

The same flow is maintained through the initial flush, the chemical cleaning circulation and
every rinse displacement (cl.3.3), and it is the flow at which the passivation charge and the
turnover fill are circulated.

### 4.2 Required head and skid duty

Required head = static lift + friction of the MAIN circulation path (the single-leg lines of
M-601 at the total circuit flow) + the pressure drop of every component left in the flushed path
scaled as dP_rated x (Q/Q_rated)^2 + the temporary hose loss and the VD-05 strainer loss at the
skid's own share of the flow. Where a skid combination is used, the units are in parallel, share
the flow equally, and each must develop the required head at its own flow (cl.3.2 d and e).

| Circuit | Skid(s) | Units | Flow per skid (gpm) | Required head (ft w.c.) | Head available (ft w.c.) | Utilisation | Duty-point check |
|---|---|---|---|---|---|---|---|
| C1 | FS-1200-A | 1 | 1216.9 | 92.0 | 114.0 | 0.81 | inside published curve (last point 1400 gpm) |
| C2 | FS-1200-A | 1 | 642.4 | 50.4 | 183.9 | 0.27 | inside published curve (last point 1400 gpm) |
| C3 | FS-1200-A | 1 | 742.0 | 58.7 | 174.3 | 0.34 | inside published curve (last point 1400 gpm) |
| C4 | FS-600-A | 1 | 371.0 | 101.9 | 152.6 | 0.67 | inside published curve (last point 700 gpm) |
| C5 | FS-1200-A | 1 | 490.4 | 83.5 | 193.8 | 0.43 | inside published curve (last point 1400 gpm) |
| C6 | FS-600-A | 1 | 371.0 | 105.2 | 152.6 | 0.69 | inside published curve (last point 700 gpm) |
| C7 | FS-600-A | 1 | 304.2 | 109.2 | 162.4 | 0.67 | inside published curve (last point 700 gpm) |
| C8 | FS-600-A | 1 | 155.7 | 70.0 | 175.5 | 0.40 | inside published curve (last point 700 gpm) |

Every duty point lies inside the last tabulated point of the published curve (cl.3.2 f). The
4.026 in. hose supplied with an FS-600 loses 80 ft w.c. at 600 gpm, so a single FS-600 cannot
serve the four high-flow circuits; C1 is beyond the FS-600 curve and needs the FS-1200, and
C2, C3 and C5 need either the FS-1200 or both FS-600s in parallel. The FS-1200 has been assigned
to C1, C2, C3 and C5 so that no circuit depends on both FS-600 units at once and the FS-600-A
can work the four small circuits concurrently.

### 4.3 Components in the flushed path

Every component shown in M-602 with a full-size temporary bypass spool is bypassed for the
initial flush and the chemical cleaning (cl.3.4): HX-201A, HX-201B, CDU-301, CP-311, CDU-302,
CP-321, CP-331 and CL-401. The components that stay in the path are checked at the declared flow:

| Component | Circuit | dP at declared flow (ft w.c.) | Max allowable dP (ft w.c.) | Temperature (degF) | Max particle size (micron) | Result |
|---|---|---|---|---|---|---|
| PMP-101 | C1 | 0.00 | 40 | 68 <= 200 | 380 <= 800 | pass |
| BT-101 | C1 | 0.00 | 15 | 68 <= 200 | 380 <= 800 | pass |
| ST-601 | C8 | 10.10 | 25 | 68 <= 140 | 380 <= 800 | pass |

PMP-101 and BT-101 show zero pressure drop at rated flow and therefore zero at any flow
(M-602 Notes 1 and 5); the max allowable figures against them are mechanical ratings, not
flushing limits. ST-601 has no bypass: at the C8 declared flow of 155.7 gpm its drop is 10.1 ft w.c. against
a 25 ft w.c. limit (40 % of it), and it is a full-bore vessel that passes the 380 micron
strainer opening.

### 4.4 Passivation and turnover circulation with the components back in the path

The bypass spools are removed after chemical cleaning, so the passivation and turnover rows are
computed with every M-602 component back in the path (cl.3.2 d and cl.3.4). The flow is reduced
from the flushing flow to the largest value at which each component is inside its maximum
allowable pressure drop and the assigned skid still develops the required head, with a 5 %
reserve below the limiting flow:

| Circuit | Q_pass (gpm) | Component | dP at Q_pass (ft) | Max allowable (ft) | Head required (ft) | Skid available (ft) | Head margin |
|---|---|---|---|---|---|---|---|
| C1 | 1156.1 | none (PMP-101/BT-101 full bore) | 0.00 | n/a | 85.6 | 123.1 | 0.305 |
| C2 | 610.3 | HX-201A | 46.05 | 58 | 93.7 | 187.0 | 0.499 |
| C3 | 650.7 | HX-201B | 52.34 | 58 | 102.8 | 183.1 | 0.439 |
| C4 | 313.2 | CDU-301 | 25.81 | 48 | 148.0 | 161.1 | 0.081 |
| | | CP-311 | 35.32 | 65 | | | |
| C5 | 382.4 | CDU-302 | 42.88 | 48 | 170.1 | 199.6 | 0.148 |
| | | CP-321 | 58.67 | 65 | | | |
| C6 | 307.6 | CP-331 | 60.98 | 72 | 148.7 | 161.9 | 0.081 |
| C7 | 267.5 | CL-401 | 46.94 | 52 | 147.9 | 165.8 | 0.108 |
| C8 | 147.9 | ST-601 | 9.11 | 25 | 64.6 | 176.1 | 0.633 |

The required head on every row is the cl.3.2 d sum: static lift from M-ISO-201..204 + main-path
friction of the single-leg M-601 lines at the total circuit flow + the dP of every component in
the path at the declared flow + the VD-05 hose loss and strainer dP at the skid flow. The
flushing rows (bypasses fitted) are unchanged; the passivation/turnover rows use the reduced
Q_pass above. The head figures quoted in the earlier review omitted the hose and strainer terms,
which VD-05 and cl.3.2 d require; the decomposition is stated here so the difference can be
checked term by term.

Section 23 25 16 cl.3.3 applies the flushing velocity to the initial flush, the chemical cleaning
and every rinse displacement. PASSIVATE and FINAL_FILL are not flushing stages; their flow is set
by the component maximum allowable dP and the skid curve, which is why Q_pass is below the
flushing flow on C1, C5, C7 and C8 and the velocity there is below 3.28 ft/s. The flushing rows
retain the full 3.28/4.0 ft/s criterion.

Particle limits: CP-311, CP-321 and CP-331 are limited to 50 micron, CDU-301 and CDU-302 to 300
micron, HX-201A/B to 500 micron and CL-401/ST-601 to 800 micron (M-602). The VD-05 40 mesh
strainer at 380 micron is too coarse for the CP banks and the CDUs, so a 50 micron filter is
fitted on CP-311/CP-321/CP-331 and a 300 micron filter on CDU-301/CDU-302 whenever those
components are in the path; the 380 micron strainer is adequate for HX-201A/B, CL-401 and ST-601.
The fine filters are Contractor scope under cl.3.10 f and carry no price line.

## 5. Chemistry design basis

### 5.1 Makeup water (SW-02)

pH 7.6; conductivity 615 microS/cm; total hardness 288 mg/L as CaCO3; chloride 505 mg/L;
sulphate 355 mg/L; silica 11 mg/L as SiO2; iron 0.09 mg/L; TSS < 1 mg/L.

### 5.2 Programme selection

C1, C2, C3, C4, C5 and C7 - molybdate-azole. C6 - polysilicate-azole, because the circuit
contains the aluminium cold-plate bank CP-331 and UFC 3-230-13 6-2.2.5 states that the
polysilicate programme "is especially beneficial when aluminum metal is present", which is what
VD-04 chemical compatibility note 1 requires. C8 - polysilicate-azole, because the circuit is
hot-dip galvanized (RFI-022) and UFC 5-7.3.1 limits the pH to 8.5 during cleaning and
passivation, which the molybdate band (pH 8.5 to 9.5 in service) cannot guarantee.

On C1, C2 and C3 no copper is wetted anywhere, so no azole is carried: UFC 6-2.2.3 step 4
requires the 10 ppm tolyltriazole only if copper is present. The programme is still the
molybdate-azole programme, dosed with MO-500 alone.

The nitrite programmes are excluded by the makeup analysis: chloride + sulphate = 505 + 355 =
860 mg/L exceeds the 800 mg/L limit of UFC 6-2.2.2 and the (NO2 + Mo) - 100 = 250 mg/L limit of
6-2.2.4. NB-700 is therefore not ordered.

### 5.3 Chemical cleaning

The cleaning product is dosed volumetrically on the SYSTEM volume at the VD-06 application rate
(cl.3.4, VD-06 Note 4a): CL-100 at 1.5 gal per 1,000 gal for the carbon-steel circuits and CL-210
at 2.0 gal per 1,000 gal for the galvanized and aluminium circuits C6 and C8. A target residual
does not apply to a cleaning row. The polyacrylate dispersant PD-45 is carried with the cleaning
charge at 4 ppm active polymer (UFC 5-3.7, together with the 3.28 ft/s velocity). The charge is
circulated for 24 h of OCCUPIED time per circuit (UFC 5-7.3.2.2 b), scheduled as two 12 h crew
shifts per circuit so that the sum of the stage hours is the contact time and no crew is
charged with more than 12 attended hours in a shift.

### 5.4 Rinse

C_n = C_mk + (C_0 - C_mk) exp(-eta n) with C_mk = 615 microS/cm and C_0 = 2,600 microS/cm for
CL-100 / 2,150 microS/cm for CL-210 (VD-06 Note 3); eta = 0.45 where the circuit contains a
cold-plate manifold bank or a coil bank (C4, C5, C6, C7) and 0.62 otherwise (C1, C2, C3, C8).
The acceptance criterion is the UFC 5-7.3.2.2 e one: conductivity within +/-10 % of makeup,
i.e. <= 676.5 microS/cm, and pH within +/-0.3 of 7.6 clipped to the 7.5 to 8.5 window, i.e. a
control band of 7.5 to 7.9 that satisfies both permitted readings of the criterion. The single
cascaded displacement of each receiver is made FIRST in its rinse sequence; the conservative
calculation below uses the donor final rinse quality (not makeup) for that displacement.

| Circuit | Cleaner | Cascade | C_0 (microS/cm) | eta | n | Rinse draw (gal) | Rinse effluent (gal) | C_n (microS/cm) | Conductivity margin |
|---|---|---|---|---|---|---|---|---|---|
| C1 | CL-100 | none | 2600 | 0.62 | 6 | 197900 | 158511 | 663.1 | 0.020 |
| C2 | CL-100 | first displacement from C3 | 2600 | 0.62 | 6 | 27980 | 27980 | 664.1 | 0.018 |
| C3 | CL-100 | first displacement from C5 | 2600 | 0.62 | 6 | 31015 | 25419 | 664.2 | 0.018 |
| C4 | CL-100 | none | 2600 | 0.45 | 8 | 47653 | 41696 | 669.2 | 0.011 |
| C5 | CL-100 | first displacement from C1 | 2600 | 0.45 | 8 | 44840 | 38637 | 670.0 | 0.010 |
| C6 | CL-210 | none | 2150 | 0.45 | 8 | 33817 | 29590 | 656.9 | 0.029 |
| C7 | CL-100 | first displacement from C8 | 2600 | 0.45 | 8 | 28601 | 28601 | 669.8 | 0.010 |
| C8 | CL-210 | none | 2150 | 0.62 | 6 | 34744 | 24867 | 652.2 | 0.036 |

### 5.5 Passivation and turnover

The passivation tables of UFC 3-230-13 (Tables 5-14 and 5-15, the tables the document identifies
for passivation) give 40-60 ppm as Mo and 40-50 ppm as SiO2 at pH 7.5-8.5 with 14-21 days of
film formation, and 10-20 ppm as TTA at pH 6.5-7.9. The programme is dosed at the bottom of the
band (40 ppm) and held for the bottom of the film-formation range (14 days = 336 occupied hours).
Where copper is wetted (C4, C5, C6, C7) the azole is carried at 12 ppm (inside the 10-20 ppm
band) and the passivation pH is controlled to the intersection of the molybdate/silicate band
and the TTA band, 7.5 to 7.9. The dose is referred to the SYSTEM volume (cl.3.5), so the
retained charge after the RETAIN_AND_TOP_UP top-up is 12 ppm TTA at turnover; the FINAL_FILL
row records the zero top-up increment because maintenance and passivation residuals are equal.

Turnover uses RETAIN_AND_TOP_UP for every circuit. That method is permitted because for both
selected programmes the maintenance residual of the programme paragraph is above the passivation
residual: molybdate 100-125 ppm (UFC 6-2.2.3) against 40-60 ppm passivation, and polysilicate
80-100 ppm (UFC 6-2.2.5) against 40-50 ppm passivation, while the azole is held at 12 ppm in both.
The retained charge is therefore raised, not diluted, by the top-up. The top-up is drawn through
the SV-2 softener (C-101) and is dosed only with the increment between the maintenance and
passivation residuals, on the SYSTEM volume (Section 23 25 16 cl.3.8 reporting convention).

The water left standing in C1 and C8 after the last rinse is softened water: one full softened
displacement is accumulated from SV-2 at no more than 5,225 gal/day (C-101 softener SF-1) and
used for the final rinse displacement, so the retained water is below 20 mg/L as CaCO3 and the
system meets UFC Table 6-1 at turnover. The softened water is accounted as MAKEUP in cl.3.9;
its conductivity is measured and is not higher than the 615 microS/cm makeup value used in the
rinse model, so the C_n figures below remain conservative.

Final total hardness at turnover, mg/L as CaCO3: C1 20, C2 203, C3 209, C4 201, C5 205, C6 214, C7 195, C8 20; every value is below
the 250 mg/L limit of UFC Table 6-1. C1 and C8 are below 20 mg/L because their retained water is
the softened final rinse; the others are the raw 288 mg/L rinse water diluted by the softened
FINAL_FILL top-up to the SYSTEM volume.

pH control. VD-06 leaves the product pH as supplied blank for MO-500, PS-330, TA-90 and PD-45.
The pH of each delivered package is measured on receipt and the charge pH is measured after
dosing, before the residual sample is taken. The measured pH is trimmed into the stated band
with SA-100 soda ash (the only pH-adjust product in VD-06, used to raise pH) or with dilute
hydrochloric acid (a standard reagent, not a VD-06 product, used only to lower the passivation/
maintenance charge; the CL-100/CL-210 cleaning charges are never acidified). The acid and soda
ash are consumables within the lump-sum mobilisation; one 50 lb bag of SA-100 is carried as the
contingency recorded in `resources.json`. The PASSIVATE band is 7.5-7.9 where TTA is present
(C4-C7) and 7.5-8.5 elsewhere (C1-C3, C8), with the C8 upper limit 8.5 for galvanized steel.
The FINAL_FILL maintenance band is 8.5-9.5 for the molybdate circuits (C1-C5, C7), 7.5-7.9 for
C6 (polysilicate intersected with TTA) and 7.5-8.5 for C8 (polysilicate, galvanized cap).

### 5.6 Chemical quantities and orders

Every dosing row is rounded up to whole packages at the VD-06 package price, with no pooling
across stages or circuits (cl.3.10 e). The order dates in `resources.json` apply the conservative
rule order_by_day = 0 - VD-06 lead time, i.e. the order is placed at mobilisation less the lead
time, which is no later than first use less the lead; MO-500 (21 days) is ordered 21 days before
mobilisation and every product is on site before its first use.

| Product | Packages | Lead (days) | Order by day | Extended (USD) |
|---|---|---|---|---|
| CL-100 | 24 | 10 | -10 | 2688 |
| PD-45 | 8 | 7 | -7 | 368 |
| MO-500 | 17 | 21 | -21 | 2924 |
| TA-90 | 4 | 12 | -12 | 368 |
| CL-210 | 6 | 14 | -14 | 768 |
| PS-330 | 4 | 18 | -18 | 556 |
| SA-100 | 1 | 5 | -5 | 62 |

## 6. Water, effluent and schedule basis

Water and effluent are accounted per Section 23 25 16 cl.3.9. The programme draws 623,234 gal and
produces 538,725 gal of effluent; the balance of 84,509 gal is the SYSTEM volume left standing in the
eight circuits at turnover.

Daily draw is held at or below the 92,000 gal limit of SW-01 cl.2 (62,000 gal metered plus
30,000 gal trucked) and, on project days 2 and 3, at or below the 31,000 gal metered allocation
of SI-04 cl.1; no activity draws metered water on project day 6 (SI-04 cl.2), when the whole
draw is trucked and is capped at 30,000 gal. The peak day is 80197 gal against the 92,000 gal limit
(utilisation 0.87); the tightest day is project day 2, where the SI-04 limit is 61,000 gal and
the draw is 54,010 gal, a margin of 0.1146.

Discharge: 307,678 gal to the metered manhole MH-14 and 231,047 gal by vacuum tanker. Every stream
from the copper- or zinc-bearing circuits C4 to C8 - hydrostatic test, initial flush, spent
cleaning solution and the whole rinse - is hauled, because VD-06 Note 3 characterises the spent
solution at 3.4 mg/L Cu (CL-100) / 1.6 mg/L Cu (CL-210) and 5.5 mg/L Zn (CL-210 on galvanised),
above the 1.0 mg/L SW-03 local limits, and the first rinse displacements are above the limit by
the cl.3.6 displacement model. C1, C2 and C3 carry no copper or zinc and are sewered. The
metered total is 307,678 gal, 38.5 % below the 500,000 gal authorisation.

## 7. Design basis - governing constraint and margin, per circuit

The margin is (limit - achieved)/limit for an upper limit and (achieved - limit)/limit for a
lower limit. All five candidate constraints are stated for every circuit so the binding one can
be verified; the binding constraint is the smallest of the five, and where a constraint can be
written in more than one quantity the tighter permitted form has been used. The rinse margin is
stated in BOTH permitted forms (conductivity and displacements) and the tighter (conductivity)
is the one used to decide which constraint binds.

GOVERNING CONSTRAINT C1: rinse endpoint (margin 0.0198)

GOVERNING CONSTRAINT C2: rinse endpoint (margin 0.0183)

GOVERNING CONSTRAINT C3: rinse endpoint (margin 0.0181)

GOVERNING CONSTRAINT C4: rinse endpoint (margin 0.0107)

GOVERNING CONSTRAINT C5: rinse endpoint (margin 0.0096)

GOVERNING CONSTRAINT C6: rinse endpoint (margin 0.0289)

GOVERNING CONSTRAINT C7: rinse endpoint (margin 0.0099)

GOVERNING CONSTRAINT C8: rinse endpoint (margin 0.0359)


| Circuit | Flushing duty vs skid head | Rinse endpoint (conductivity) | Rinse (displacements) | Authorised discharge volume | Daily water allocation | Temporary power | Binding |
|---|---|---|---|---|---|---|---|
| C1 | 0.193 | 0.020 | 0.066 | 0.385 | 0.115 | 0.500 | rinse endpoint (0.0198) |
| C2 | 0.726 | 0.018 | 0.066 | 0.385 | 0.115 | 0.500 | rinse endpoint (0.0183) |
| C3 | 0.663 | 0.018 | 0.066 | 0.385 | 0.115 | 0.211 | rinse endpoint (0.0181) |
| C4 | 0.332 | 0.011 | 0.035 | 0.385 | 0.115 | 0.667 | rinse endpoint (0.0107) |
| C5 | 0.569 | 0.010 | 0.035 | 0.385 | 0.115 | 0.167 | rinse endpoint (0.0096) |
| C6 | 0.311 | 0.029 | 0.106 | 0.385 | 0.115 | 0.667 | rinse endpoint (0.0289) |
| C7 | 0.328 | 0.010 | 0.035 | 0.385 | 0.115 | 0.333 | rinse endpoint (0.0099) |
| C8 | 0.601 | 0.036 | 0.135 | 0.385 | 0.115 | 0.750 | rinse endpoint (0.0359) |

Reading of the margins:

- rinse endpoint is the binding constraint on C1, C2, C3, C4, C5, C6, C7, C8.
- The rinse endpoint is the binding constraint on every circuit. In the conservative cascade
  calculation (cascade first, donor quality) C_n is 663.1 microS/cm for C1/C2/C3, 669.2 for C4/C7,
  670.0 for C5 and 652.2 for C8 against the 676.5 microS/cm limit; one displacement fewer fails
  the criterion. The margin in displacements (0.035 to 0.135) is wider than the margin in
  conductivity, which is the tighter permitted form used to rank the constraints (cl.1.6).
- The flushing duty leaves 19 % of the FS-1200 head on C1 (the largest circuit, beyond the
  FS-600 curve) and 31 to 73 % on the other circuits.
- The daily water allocation is not binding: the tightest day is project day 2, 54,010 gal of the 61,000 gal limit (margin 0.1146).
- The temporary power is nowhere near binding; the tightest is C5 at 0.167, because the FS-1200
  draws 75 kW of the 90 kW available at L3-S.
- The discharge cap is not binding: the sewer total is 307,678 gal of the 500,000 gal
  authorisation (margin 0.385) and the balance, 231,047 gal, is tankered because of the local
  metals limits, not because of the cap.

## 8. Conflicts found between the project documents, and their resolution

| # | Conflict | Resolution |
|---|---|---|
| 1 | SW-03 Rev A (and RFI-031, 2026-07-06) state a 540,000 gal programme cap; SW-03 Rev B (2026-07-21) states 500,000 gal, and adds a 0.5 mg/L molybdenum limit and a $9.40/kgal rate against Rev A's $11.20/kgal and no molybdenum limit. | Rev B is the later authorisation and supersedes Rev A; the 500,000 gal cap, the 0.5 mg/L molybdenum limit and $9.40/kgal are applied. RFI-031 remains the authority for the tanker route and the $168.00/kgal rate, which Rev B does not change. |
| 2 | M-PID-103 Rev A puts line 4033 (x2 legs) inside C4 and leaves C5 without it; Rev C puts 4033 (x3 legs) inside C5. | Rev C governs (M-601 Note 5). C5 therefore has four lines, its governing segment is 4033 with three legs, and its flushing flow is 490 gpm (476 gpm at the criterion) rather than the 371 gpm a three-line circuit would need. |
| 3 | UFC Table 6-2 (selection guidelines) does not list the polysilicate programme for chilled water, but paragraph 6-2.2.5 states it is especially beneficial where aluminium is present, and Section 23 25 16 cl.3.5 says the paragraph text governs over the selection table. | Polysilicate-azole selected for C6 (aluminium) and C8 (galvanized pH cap). |
| 4 | UFC Table 5-11 gives 10-12 days film formation for molybdate and polysilicate and 5-6 days for TTA; Tables 5-14 and 5-15 give 14-21 days. | Section 23 25 16 cl.3.5 says the tables the document identifies for PASSIVATION govern and a table written for another duty does not. UFC 5-7.3.2.4 identifies Tables 5-14 and 5-15 as the chemical technology used for passivation; Table 5-11 belongs to the open cooling-tower duty of Chapter 5. 14 days applied. |
| 5 | UFC 6-2.2.3 sets the molybdate maintenance pH at 8.5-9.5 but Table 5-15 sets the molybdate passivation pH at 7.5-8.5. | The passivation band (7.5-8.5) governs the PASSIVATE stage and the programme text (8.5-9.5) governs the FINAL_FILL; the passivation charge is made up at 7.5-8.5 and the pH is brought to 8.5-9.5 at turnover by trimming the circulating charge (titrated; SA-100 soda ash is the quoted pH adjust if the trim needs more than the alkalinity carried by the MO-500 addition). |
| 6 | UFC 6-2.2.5 sets the polysilicate maintenance level at 80-100 ppm while Table 5-11 shows 10-20 ppm maintenance. | The programme paragraph governs maintenance (80-100 ppm); Table 5-11 is not a passivation table. 80 ppm applied, which is also what makes RETAIN_AND_TOP_UP permissible. |
| 7 | UFC 5-7.3.1 caps the pH at 8.5 where galvanized steel is present; 6-2.2.5 allows up to 8.9. | Section 23 25 16 cl.1.1 makes the more restrictive requirement govern: C8 is controlled to 7.5-8.5. |
| 8 | UFC Table 5-15 puts TTA passivation at pH 6.5-7.9 and molybdate/silicate passivation at 7.5-8.5. | Section 23 25 16 cl.3.8 requires control to the intersection: pH 7.5-7.9 on the copper-bearing circuits C4, C5, C6, C7. |
| 9 | CX-02 records all eight circuits tested and accepted at 127.5 psig / 120 min, but the charts it cites for C3, C5, C6 and C7 (TR-0414, TR-0416, TR-0417, TR-0418) are not in the record; only TR-0412, TR-0413, TR-0415 and TR-0419 are filed. | Section 01 91 13 cl.1.3 makes a result whose cited evidence is not on file an unaccepted result, and Section 23 21 16 cl.3.3 requires any circuit not recorded as accepted to be tested before chemical cleaning. C1, C2, C4 and C8 are not retested; C3, C5, C6 and C7 carry a HYDRO row at 127.5 psig for 120 min. |
| 10 | SW-01 cl.1 sets a 62,000 gal daily metered allocation while cl.2 sets a 92,000 gal daily draw limit. | Both applied: the 92,000 gal figure is the hard daily limit (SW-01 cl.2 states the metered figure is where the price changes, not a limit), the 62,000 gal figure is the metered volume priced at $6.20/kgal, and the balance is priced at the $19.80/kgal trucked rate. |
| 11 | UFC Table 6-1 requires makeup below 250 ppm hardness; SW-02 reports 288 ppm; the site softener SF-1 can treat only 88,000 grains per day, i.e. 5,225 gal at 288 ppm, against a programme draw of more than 600,000 gal. | Full softening of the whole campaign is arithmetically impossible. Resolved by drawing every FINAL_FILL top-up through SV-2 and by making the final rinse displacement of C1 and C8 with softened water accumulated at no more than 5,225 gal/day, so the water retained in every circuit at turnover is below 250 mg/L (C1/C8 below 20 mg/L). The softener production is scheduled on days 1, 3-5 and 7-9 for C1 and days 1-2 for C8, outside the day-6 metered shutdown. |
| 12 | VD-03 quotes 46 ft w.c. pressure drop "at the rated flow" for the PHE-450 and a 230 psig design pressure; M-602 lists 58 ft w.c. max allowable and 230 psig. | VD-03 note 5 and M-602 Note 6 make the schedule's max allowable figure govern. The 46 ft w.c. is the drop the unit develops at 610 gpm, not a limit; the unit is bypassed in any case. |
| 13 | M-602 shows a zero pressure drop at rated flow for PMP-101 and BT-101 but a non-zero max allowable figure. | M-602 Note 5: the zero is a full-bore item with no measurable drop at any flow and the max allowable figure is a mechanical rating, not a flushing limit. No contradiction. |
| 14 | RFI-022 confirms lines 6011-6013 and ST-601 are galvanized although M-601 describes the rest of the system as black steel and copper. | Confirmed as designed; C8 is treated as a galvanized circuit (CL-210 cleaner, polysilicate programme, pH <= 8.5). |
| 15 | Section 23 25 16 cl.3.3 sets a 4.0 ft/s minimum for plate-HX and cold-plate circuits, but the circuit velocity class is not stated on the drawings. | C2 and C3 serve the plate heat exchangers HX-201A/B and C4, C5 and C6 serve cold-plate manifold banks in M-602, so those five take the 4.0 ft/s class; C1, C7 and C8 take 3.28 ft/s (the UFC figure, which is above the 2.0 ft/s class minimum). |

## 9. Defects found in the documents

1. Four hydrostatic test charts cited by CX-02 (TR-0414, TR-0416, TR-0417, TR-0418) are missing
   from the commissioning record. Four circuits therefore have to be retested, which is extra
   scope created by a record deficiency, not by the work.
2. The superseded M-PID-103 Rev A and the superseded SW-03 Rev A remain in the issued document
   set alongside their current revisions; both were located and excluded, but they are a live
   risk of a wrong line assignment or a wrong discharge limit being used by others.
3. UFC 3-230-13 Table 5-14 contains typographical unit errors: "20-30 days as PO4" and
   "10-20 days as TTA" should read ppm. Read as ppm (as Table 5-15 and the surrounding text
   confirm); the error does not affect the molybdate and polysilicate lines used here.
4. The site softener SF-1 is undersized for construction use: at the SW-02 hardness of 288 mg/L
   its 88,000 grain capacity yields only 5,225 gal per daily regeneration, about 0.8 % of the
   programme draw. It cannot deliver the Table 6-1 makeup quality for the whole campaign at once.
   The plan works within that capacity: the C1 and C8 final rinse displacements are softened and
   accumulated over 7 and 2 days respectively, and every FINAL_FILL top-up is softened, so the
   water retained in all eight circuits at turnover is below 250 mg/L as CaCO3. The softener
   remains the pacing item for any later owner top-up and is flagged in section 11A.
5. The FS-600 skid is supplied with a 4.026 in. hose: at 600 gpm the 300 ft run alone loses
   about 80 ft w.c., so the published 106 ft w.c. at 600 gpm is almost entirely consumed by the
   hose. The datasheet does not say so, and a plan built on the pump curve alone would fail on
   site. This is why C2, C3 and C5 are assigned to the FS-1200.
6. VD-06 quotes no density for CL-100 and CL-210 (the active content, 22 % and 18 %, is quoted).
   That is correct for a volumetric product (Note 4a), but it means the cleaning dose cannot be
   expressed as a mass and must not be entered as a target residual. VD-06 also leaves the
   product pH as supplied blank for MO-500, PS-330, TA-90 and PD-45; the charge pH is therefore
   measured and trimmed on site (section 5.5 and 11.6) rather than computed from the quotation.
7. M-601 does not assign lines to circuits and M-603 does not list lines; the circuit definition
   exists only on the P&ID sheets. A reader who works from the schedules alone will mis-size C4
   and C5.

## 9A. Judgement calls where the documents leave the choice to the engineer

| # | Call | Why |
|---|---|---|
| 1 | Flushing flow set 3 % above the criterion | The criterion is a minimum measured in the field; a 3 % reserve keeps the recorded velocity above it after rounding and after a slightly different friction factor. It costs 3 % of flow and about 6 % of friction head. |
| 2 | Film formation held at 14 days, the bottom of the 14-21 day tabulated range | The table tabulates a range; the bottom of the range is the requirement and the shorter hold shortens the programme. |
| 3 | Passivation dosed at 40 ppm and maintenance at 100 ppm (Mo) / 80 ppm (SiO2), the bottom of each band | Both are inside the tabulated bands; the lower value is the lower product cost and the lower dose. |
| 4 | RETAIN_AND_TOP_UP for every circuit | It is permitted for both programmes (maintenance residual above passivation residual) and it avoids draining 40-60 ppm of molybdenum to a sewer limited to 0.5 mg/L, which would force every passivation charge to be hauled. |
| 5 | DRAIN_AND_REFILL rejected for the molybdate circuits | It would produce an effluent containing 40-60 mg/L of molybdenum, 80-120 times the SW-03 limit, and the whole charge would have to be tankered. |
| 6 | Cascade chain C1 to C5 to C3 to C2 with C8 to C7 | It maximises the donated volume: each donor is larger than its receiver, each circuit receives once and donates once, and the chain follows the natural rinse order of the two skids. |
| 7 | All streams of C1-C3 sewered; all streams of C4-C8 (hydro, initial flush, spent cleaner and rinse) hauled | Only the circuits whose flushed path wets copper pipe or galvanized steel carry copper or zinc above the SW-03 limits (VD-06 Note 3); the others carry none. Hauling the whole C4-C8 stream is the conservative reading of cl.3.7. |
| 8 | Every stream from C4-C8 is hauled; C1-C3 are sewered (307,678 gal to MH-14, 38.5 % below the 500,000 gal cap) | The copper and zinc limits attach to the stream, not to the cap: VD-06 Note 3 characterises the spent CL-100/CL-210 solution above 1.0 mg/L Cu/Zn, and the first rinse displacements remain above the limit under the cl.3.6 model. Hauling the whole stream is the conservative reading of cl.3.7 and removes the need to characterise each displacement before release; C1-C3 have no copper or zinc and are sewered. |
| 9 | FS-1200-A assigned to C1, C2, C3 and C5 and FS-600-A to C4, C6, C7 and C8 | A single FS-600 cannot overcome the loss in its own 4.026 in. hose above about 450 gpm (80 ft w.c. of the 106 ft it develops at 600 gpm), so the four high-flow circuits need the FS-1200 or both FS-600s. Keeping them on the FS-1200 leaves the FS-600 free to work the low-flow circuits in parallel, which is what keeps the programme inside the water allocation. |
| 10 | Cold plates bypassed and the 50 micron particle limit not applied during flushing | VD-04 requires the bypass for all construction flushing and chemical cleaning; with the component out of the path its particle limit does not bind. The fine filtration the component needs in service is Contractor scope under cl.3.10 f. |
| 11 | 30 minutes of turnover recirculation | UFC 3-230-13 5-7.3.2.2 d is the only recirculation period the document states for a closed-system fill before sampling. |
| 12 | Low point drain DV-Cx-01 used as the sampling point | The isometrics provide a low point drain with a hose connection on every circuit; sampling there is representative while the circuit circulates. |
| 14 | Pipe volume taken over the developed length only, without the fittings equivalent length | M-601 Note 3 says the sum L/D column is for the equivalent-length method, and cl.3.2 c uses it for the friction head; an equivalent length is a pressure-loss abstraction and overstates the water a fitting holds by an order of magnitude. The pipe volume at the developed length, plus component hold-up, is the circuit's actual holdup. |
| 13 | Trial of a single-skid programme rejected | With one skid each 24 h chemical cleaning blocks a whole day and the flushes, rinses and passivations have to wait for it; the calendar grows to about 19 days, which costs more in unit-days than the second skid costs. |

## 10. Execution narrative

**Mobilisation (hour 0).** TM-0. FS-600-A and FS-600-B delivered (SI-05). Temporary power
energised at the tie-in panels of SW-04. Spill containment, eyewash and the SDS pack (VD-07)
placed at the dosing point. Strainers, bypass spools and hoses checked against VD-05 and M-602.

**Hydrostatic testing.** C3, C5, C6 and C7 are tested at 127.5 psig for 120 minutes with the
Contractor's test pump (not a flush skid, Section 23 25 16 cl.3.10 f) before any chemical
cleaning; the 127.5 psig is below the 150 psig rating of the hose and strainer that remain in
the assembled circuit (VD-05 note 1, M-602 Note 3). C3, C5 and C6 are tested on day 0 by the
two crews and C7 on day 4, so all four finish before TM-1 at day 6. A signed chart is filed for
each, which is what CX-02 lacked. C1, C2, C4 and C8 are not retested (Section 23 21 16 cl.3.3).

**Initial flush.** One full circuit displacement at the declared flow with the bypass spools
fitted and the 380 micron strainer in the skid discharge. The lowest-velocity segment is recorded
(CX-03 item 2) and the strainer is cleaned at every drain.

**Chemical cleaning.** The cleaning charge is made up on the SYSTEM volume with the dispersant,
circulated for 24 h as two 12 h crew shifts, then drained. The C8 charge is drained on day 6/7,
directly after its circulation, rather than left standing. Every stream from C4, C5, C6, C7 and
C8 is hauled; the carbon-steel/stainless circuits C1, C2 and C3 are sewered after confirming pH
8.4/8.1 and no copper or zinc (VD-06 Note 3). Strainers are cleaned at the drain. Because SW-03
also sets a 300 mg/L total suspended solids limit that VD-06 does not characterise, every
C1-C3 stream is sampled for TSS before the drain valve is opened; a stream above 300 mg/L is
diverted to the tanker under the RFI-031 contingency instead of to MH-14, and the diversion is
recorded in the log with its volume, route, pH and temperature.

**Rinse.** n displacements at the declared flow, with the cascade arrangement C1 to C5, C5 to C3,
C3 to C2 and C8 to C7. The cascaded displacement is the FIRST displacement of each receiver, so
the donor quality is diluted by the remaining makeup displacements and the conservative C_n of
section 5.4 is met. Each cascade moves exactly one receiver displacement volume out of the
donor's final rinse effluent into a portable holding tank and then into the receiver, so no
circuit receives more than one cascaded displacement and no donor FLUSH volume is smaller than
its receiver's. Rinse samples (clarity, suspended solids, conductivity, pH) are taken while
circulating at every displacement and logged on CX-03 item 6. The final displacement of C1 and
C8 is softened water from SV-2, so the retained water meets UFC Table 6-1. The circuit is left
FULL after the last displacement.

**Passivation.** The bypass spools are removed and the charge is dosed into the standing water
on the SYSTEM volume, pH adjusted into the band, and circulated at the reduced passivation flow
of section 4.3 (all components back in the path and inside their M-602 maximum allowable dP);
the residual and pH at the start of film formation are recorded (CX-03 item 7). The skid is
then released and the circuit is held, unattended, for 14 days (336 h, CX-03 item 8). No skid
and no crew is charged during the hold.

**Turnover.** TM-3 is met when the last film-formation hold closes (day 29, inside
the contractual day 44 milestone). Each circuit is topped up to its SYSTEM volume with softened water
carrying the maintenance charge, recirculated for 30 minutes and sampled while circulating for
the maintenance residual, the azole residual and the total aerobic bacteria count. Strainers are
removed at the start of each turnover fill (CX-03 item 11), on days 24 to 30 and before TM-4 at
day 47. Turnover is complete at hour 721, day 30, inside TM-4.

**Records.** The CX-03 log is maintained for every circuit with the minimum velocity and its
segment, the strainer mesh and removal milestone, the cleaning circulation time, the rinse
results against makeup, the passivation residual/pH/hold and every discharge event with volume,
route, pH and temperature. The acceptance matrix in `acceptance_matrix.csv` states the gate, the
sense and the numeric threshold with the document and clause for every parameter the turnover
log must carry (Section 23 25 16 cl.1.5 a to d).

## 11. Safety - hazard communication (29 CFR 1910.1200)

Section 23 25 16 cl.1.2 adopts 29 CFR 1910.1200 for every product brought on site. The
obligations of the rule are discharged on this scope as follows.

**11.1 The products and their hazards (SDS pack VD-07, section 2).**

| Product | Use here | Hazard classification | Signal word |
|---|---|---|---|
| CL-100 | alkaline pre-operational cleaner, C1-C5 and C7 | Skin Corr. 1B; Eye Dam. 1 | DANGER |
| CL-210 | neutral-pH cleaner, C6 and C8 | Skin Corr. 1B; Eye Dam. 1 | DANGER |
| MO-500 | molybdate inhibitor, C1-C5 and C7 | Eye Irrit. 2A | WARNING |
| PS-330 | polysilicate inhibitor, C6 and C8 | Eye Irrit. 2A | WARNING |
| TA-90 | tolyltriazole azole, C4-C7 | Eye Irrit. 2A | WARNING |
| PD-45 | polyacrylate dispersant, all circuits | Eye Irrit. 2A | WARNING |
| NB-700 | NOT ordered (excluded by the makeup analysis) | Eye Irrit. 2A | WARNING |
| SA-100 | pH trim only if the measured charge pH is below the band; one 50 lb bag carried as a contingency | Skin Corr. 1B; Eye Dam. 1 | DANGER |

Supplier: Cascadia Water Technologies, emergency telephone 1-800-555-0142 (SDS section 1),
displayed at the dosing point and in the site office. Section 14 of every SDS states that the
product is not regulated in packages of this size, so no dangerous-goods consignment note is
required for the deliveries; the waste manifest for tankered effluent still references the SDS.

**11.2 Safety data sheets (1910.1200(g)).** The VD-07 pack covers eight products; the six that
are carried here are kept at the dosing point and in the site office, in English, accessible to
every employee on every shift, and are checked against the delivered labels before the first
charge is made up. NB-700 and SA-100 are not ordered, so no SDS obligation arises for them
beyond the pack already in the record.

**11.3 Labels and warnings (1910.1200(f)).** Shipped containers are accepted only with the
supplier label intact. Every drum, pail, bottle, day tank, temporary hose, tote and sample
bottle used to move a chemical carries a workplace label with the product identity and the
hazard warnings taken from the SDS. Unlabelled or defaced containers are not used.

**11.4 Written programme and chemical list (1910.1200(e)).** The site hazard communication
programme identifies the flush skid pads at MER-1, MER-2, L3-N, L3-S, L3-W, ROOF and YARD as
the work area and lists the six hazardous chemicals above with their hazard classes, the SDS
location, the labelling method and the training arrangement. The list is updated before the
first delivery of any substituted product. Non-routine tasks (the first make-up of a charge, a
product substitution) are covered by a pre-task briefing under 1910.1200(b)(2). Trade-secret
provisions of 1910.1200(i) are not invoked: the SDS give the active species.

**11.5 Information and training (1910.1200(h)).** Every crew member is trained before assignment
on: the requirements of this section; the operations in the work area where the chemicals are
present; the physical and health hazards of the six products, in the terms of the table above;
the protective measures; how to detect a release (eye and skin contact, spill, mist); and the
location and use of the SDS. Training is repeated whenever a new hazard is introduced and is
recorded with the CX-03 log.

**11.6 Specific handling controls.**

- CL-100 and CL-210 are corrosive (Skin Corr. 1B). They are never mixed with acid: acid addition
  to a cleaning charge is forbidden because it liberates heat and can release hazardous gas. CL-210 is
  used on the galvanized circuit C8 and the aluminium circuit C6, and those circuits are held at
  pH <= 8.5 (UFC 5-7.3.1) to avoid white rust and aluminium attack.
- MO-500 and PS-330 are eye irritants: they are dosed from the package into a water-filled day
  tank with the pump discharge below the liquid surface, never concentrate into concentrate.
- TA-90 and PD-45 are transferred by drum pump over a drip tray, away from oxidisers, and kept
  off the skin and out of the eyes.
- Every transfer takes place inside the secondary containment at the skid pad; the containment
  drain valve is closed while a transfer is in progress and is opened only to the authorised
  discharge route.

**11.7 Personal protective equipment (SDS section 8).** Chemical splash goggles and a face shield
when making up, sampling or transferring a charge; chemical-resistant gloves, apron and boots;
hard hat. An emergency eyewash and a quick-drench shower are within 10 seconds of the handling
point (SDS section 4), flushed and logged weekly. Respiratory protection is not required for
these products at the concentrations used; if a mist is raised during make-up, a half-mask with
particulate filters is issued under a written respiratory protection programme.

**11.8 First aid and emergency response (SDS section 4).** Eye contact: flush with water for at
least 15 minutes at the eyewash and obtain medical advice, taking the SDS. Skin contact: remove
contaminated clothing and wash with water. Spill: stop the transfer, contain with the spill kit,
absorb and drum the residue; do not wash it to the storm drain - the only authorised liquid
discharge is the metered manhole MH-14 or the vacuum tanker, and RFI-031 states that no discharge
to the storm system or to Tull Creek is authorised under any circumstances. Any release is
reported to the general contractor in the same shift and logged.

**11.9 Waste and discharge interface.** Spent cleaning solutions and rinse waters leave site only
as declared in `flush_plan.csv`: every stream from the copper- or zinc-bearing circuits C4-C8
goes by tanker under a waste manifest that references the SDS; the C1-C3 streams go to MH-14
within the SW-03 local limits. Sampling at MH-14 is continuous for pH and temperature and by
grab for copper, zinc, molybdenum and TSS.

## 11A. Hold points, sign-offs and actions required of others

| # | Hold point | Who signs / acts | When |
|---|---|---|---|
| 1 | Hydrostatic test of C3, C5, C6 and C7 at 127.5 psig / 120 min, chart signed | Commissioning authority witnesses; Contractor records on CX-02 | before chemical cleaning of each |
| 2 | Confirmation that TR-0414, TR-0416, TR-0417 and TR-0418 are genuinely unavailable (or supply them, which would remove four tests from the scope) | General contractor / owner record holder | before mobilisation |
| 3 | Strainer mesh and bypass spools fitted, CX-03 items 3 and 4 | Contractor QA | before each initial flush |
| 4 | Rinse acceptance sample (conductivity, pH, clarity, SS) at every displacement | Contractor QA; witness at the last displacement | during each rinse |
| 5 | Passivation residual, pH and azole at the start of film formation, CX-03 item 7 | Contractor QA | at each passivation |
| 6 | Film-formation hold closed at 336 h, CX-03 item 8 | Contractor QA | day 16 to day 30 |
| 7 | Turnover sample: maintenance residual, azole, total aerobic bacteria, CX-03 items 6-8 | Contractor QA; owner accepts | at each FINAL_FILL |
| 8 | Strainers removed, system turned over, TM-4 | Contractor to owner | day 30, inside the day 47 milestone |
| 9 | Chemical deliveries landed 21 days (MO-500), 18 (PS-330), 14 (CL-210), 12 (TA-90), 10 (CL-100), 7 (PD-45) after order - place the orders at the dates in `resources.json` | Procurement | immediately |
| 10 | Metred water allocation restored after the utility works (SI-04) and the tanker booking for 231,047 gal | General contractor / tanker contractor | days 2, 3 and 6 avoided in the plan; tanker standing at the YARD pad |
| 11 | Softened water from SV-2 for the final fills and the C1/C8 final rinse displacement, 5,225 gal/day at 288 ppm | General contractor (softener SF-1 regenerates nightly) | C1 production days 1, 3-5 and 7-9; C8 days 1-2; fills days 24, 28 and 30 |

## 12. Cost statement

The cost is priced on the basis of Section 23 25 16 cl.3.10 and is itemised in `resources.json`:

| Item | Basis | USD |
|---|---|---|
| Skid rental | 25 unit-days at the VD-01/VD-02 day rates, apportioned per cl.3.10 a | 15070.00 |
| Commissioning crews | 33 crew-shifts at $820.00, apportioned per cl.3.10 b | 27060.00 |
| Water | 525,070 gal metered at $6.20/kgal and 98,164 gal trucked at $19.80/kgal | 5199.08 |
| Effluent | 307,678 gal to MH-14 at $9.40/kgal and 231,047 gal by tanker at $168.00/kgal | 41708.07 |
| Chemicals | whole packages at the VD-06 package price, rounded per dosing row | 7734.00 |
| **Total** | | **96771.15** |

The hydrostatic test pump, the cascade holding tank and the fine filtration are Contractor scope
and carry no price line (cl.3.10 f).
