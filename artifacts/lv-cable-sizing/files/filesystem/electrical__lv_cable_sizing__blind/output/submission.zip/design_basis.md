```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01, DoD Building Code (1 September 2022, Change 4 of 17 December 2024), which adopts the IBC and directs every reference that code makes to NFPA 70 to UFC 3-501-01; UFC 3-501-01 and UFC 3-520-01 add the Department requirements and EDS-26 Rev 4 adds the installation requirements",
    "precedence": "Where two of the documents of record set different limits for the same thing the most restrictive requirement governs (EDS-26 Rev 4 1.1; G-001 order of precedence); where EDS-26 is silent the UFC governs; a rule EDS-26 restates from NFPA 70 is applied as written and the stricter of the two is met"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42.0,
    "roof_ambient_c": 46.0,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030.0
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA daily normals 1991-2020 station USW00003145 (Yuma MCAS AZ): highest daily normal maximum 106.8 F = 41.56 C, rounded up to 42 C per EDS-26 Rev 4 5.4",
    "roof_ambient_c": "EDS-26 Rev 4 5.4: outdoor design dry bulb plus 4 K = 46 C; M-501-C states the same 46 C at the roof tray",
    "earth_ambient_c": "EDS-26 Rev 4 5.3.2 from the same NOAA record: annual mean of the daily average normals 76.0036 F = 24.4464 C plus 3 K = 27.45 C",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T 2.2: fluidised thermal backfill, 0.60 K.m/W, surrounds the encasement for the full width of the trench and is the material whose resistivity enters Re, Rb and the mutual-heating term; the native-soil value 0.95 K.m/W (GEO-4210-T 2.1) was considered and rejected",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 5.4: alpha_s = 0.6, S = 1030 W/m2, h = 14.0 W/m2.K",
    "other_ambients": "M-501-C Ambient Temperature Coordination memo: 40 C ceiling cavity, 45 C mechanical room 121 and fire pump room 105, 40 C Building 4212 shop"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (the point of government ownership per WRPU-2026-0412)",
    "transformer_reset": false,
    "feeder_chain_pct": {
      "MSB-1 to MCC-1 (SE-1 + F-01)": 2.65,
      "MSB-1 to FP-1 (SE-1 + F-03)": 1.41,
      "MSB-1 to CH-1 (SE-1 + F-04)": 2.36,
      "MSB-1 to CH-2 (SE-1 + F-12)": 2.69,
      "MSB-1 to ATS-1 (SE-1 + F-10)": 2.62,
      "MSB-1 to EL-1 (SE-1 + F-11)": 2.28,
      "MSB-1 to DP-3 (SE-1 + F-05)": 2.65,
      "MSB-1 to K-13 (SE-1 + F-02 + F-06)": 1.68,
      "MSB-1 to LP-1 (SE-1 + F-02 + F-06 + F-07)": 2.88
    },
    "feeder_limit_pct": 3.0,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0,
    "service_entrance_vd_load_a": 1600.0,
    "branch_circuits_inheriting_upstream_budget": 18,
    "note": "transformer_reset is false: under UFC 3-501-01 3-2.7.4.5.3 the percentage drop carries through K-13 to the 208 V secondary, so the ten LP-1 branch circuits inherit the 2.88 percent already spent on SE-1 + F-02 + F-06 + F-07"
  },
  "cost": {
    "conductor_usd": 93734.78,
    "termination_usd": 9407.94,
    "raceway_usd": 48093.6,
    "material_usd": 98230.49,
    "labor_usd": 53005.83,
    "total_usd": 151236.32
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D3",
      "D4",
      "D8",
      "D9"
    ],
    "F-10": [
      "D5",
      "D10"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": {
    "SE-1": 23.93,
    "F-10": 27.37,
    "F-05": 1.54
  },
  "distinct_large_sizes": [
    "4/0",
    "300 kcmil",
    "350 kcmil",
    "500 kcmil",
    "600 kcmil"
  ]
}
```

# Design basis - P-4210 Building 4210, low-voltage wire schedule (E-621)

## 1. Codes of record and order of precedence

The design was prepared against NFPA 70, National Electrical Code, **2023 edition**, and the
International Building Code, **2024 edition**. They are codes of record because UFC 1-200-01,
DoD Building Code (1 September 2022 with Change 4 of 17 December 2024) adopts the IBC and
directs every reference that code makes to NFPA 70 to UFC 3-501-01 Electrical Engineering,
which cites NFPA 70; UFC 3-501-01 and UFC 3-520-01 Interior Electrical Systems add the
Department's requirements and NSA Whitmore Ridge EDS-26 Rev 4 (12 June 2026) adds the
installation's. The editions and the adopting document are fixed on sheet G-001, Code of
Record and General Notes (codes fixed at the start of design, 14 July 2025).

**Order of precedence.** EDS-26 Rev 4 paragraph 1.1 and sheet G-001 state the rule: where two
of these documents set different limits for the same thing, the most restrictive requirement
governs, and where EDS-26 is silent the UFC governs. NFPA 70 treats voltage drop only in
advisory informational notes, so the mandatory UFC 3-501-01 paragraph 3-2.7 limits are the
requirement here whatever split is customary elsewhere (EDS-26 5.6). The same rule was applied
between revisions of the installation standard: **EDS-26 Rev 2 is superseded in its entirety
and must not be used for design** (EDS-26 Rev 4 paragraph 1.2), so Rev 2's seven-size
standardisation limit, four-set parallel limit and 2 percent feeder limit were not applied;
Rev 4's five sizes, six sets and the UFC 3 percent feeder limit were. The superseded E-601
Rev A one-line and the Meridian Cable datasheet (which states that it is not the basis of
design) were likewise not used.

## 2. Environmental parameters and their provenance

| Parameter | Value | Source |
|---|---|---|
| Outdoor design dry bulb | 42 C | NOAA station USW00003145, highest daily normal maximum 106.8 F = 41.56 C, rounded up (EDS-26 5.4) |
| Roof ambient at the tray | 46 C | 42 C + 4 K roof allowance (EDS-26 5.4); M-501-C gives the same value |
| Earth ambient at duct-bank depth | 27.45 C | annual mean daily average normal 76.0036 F = 24.4464 C + 3 K (EDS-26 5.3.2) |
| Soil (thermal backfill) resistivity | 0.60 K.m/W | GEO-4210-T 2.2 - the backfill surrounds the encasement |
| Concrete encasement resistivity | 0.55 K.m/W | GEO-4210-T 2.3 |
| Solar irradiance / absorptivity | 1030 W/m2 / 0.6 | EDS-26 5.4 |
| Ceiling cavity / mechanical room / Building 4212 shop | 40 C / 45 C / 40 C | M-501-C ambient table |

The geotechnical report's logged ground temperatures (22.1 to 28.4 C) were **not** used: GEO
2.4 says the logging period does not span the summer maximum and the design value must be
derived from the station record, which is what EDS-26 5.3.2 does. The native-soil design
resistivity of 0.95 K.m/W was considered and rejected: both duct banks are encased in concrete
and surrounded by the specified thermal backfill for the full width of the trench, so 0.60
K.m/W is the resistivity that enters the earth and mutual-heating terms. The rejected value is
carried as a row of its own on the calculation front sheet.

## 3. Ampacity basis

Every ampacity is calculated under engineering supervision as NFPA 70 (2023) Article 310.14
permits, not taken from a code table. Raceway ampacities start from the 90 C column of the
Cascadia Wire Engineering Data 2026 (Section 4, issue 2026-1) and are corrected by
k_a = sqrt((90 - Ta)/60) and by k_g = sqrt(3/N) for more than three current-carrying
conductors; tray ampacities use the free-air heat balance with the 14.0 W/m2.K film
coefficient, the 14.05 K solar rise and k_t = 1 + 0.06(N - 3) with N = 18;
duct-bank ampacities use the Neher-McGrath formulation of EDS-26 5.3 with a load factor of
1.0. Each corrected ampacity is then capped by the ampacity of the same conductor at the
termination temperature (60 C for an overcurrent device of 100 A and below, 75 C above, but
never above the listed lug rating of the equipment) at the table reference ambient and without
correction (EDS-26 5.5). The schedule reports the ampacity per set; the design current is
compared with sets x ampacity per set.

## 4. Voltage-drop budget

The count starts at the **T-1 secondary lugs**, the point of government ownership named in
WRPU-2026-0412 and the start point required by UFC 3-501-01 3-2.7.4.2. It does **not** restart
at the low-voltage transformer K-13: under UFC 3-501-01 3-2.7.4.5.3 the drop through a
transformer is zero but the percentage at the primary terminals carries to the secondary, so
the ten LP-1 branch circuits inherit the 2.88 percent already spent on
SE-1 + F-02 + F-06 + F-07. In total **18 branch circuits** (B-01 to B-10 through
LP-1, B-11 to B-15 through MCC-1, B-16 to B-18 through DP-3) inherit a budget already spent
upstream of their panel.

Feeder chains spend:


- MSB-1 to MCC-1 (SE-1 + F-01): **2.65 percent**
- MSB-1 to FP-1 (SE-1 + F-03): **1.41 percent**
- MSB-1 to CH-1 (SE-1 + F-04): **2.36 percent**
- MSB-1 to CH-2 (SE-1 + F-12): **2.69 percent**
- MSB-1 to ATS-1 (SE-1 + F-10): **2.62 percent**
- MSB-1 to EL-1 (SE-1 + F-11): **2.28 percent**
- MSB-1 to DP-3 (SE-1 + F-05): **2.65 percent**
- MSB-1 to K-13 (SE-1 + F-02 + F-06): **1.68 percent**
- MSB-1 to LP-1 (SE-1 + F-02 + F-06 + F-07): **2.88 percent**

against the 3 percent feeder limit and the 5 percent total at the load. The service entrance
itself spends 1.11 percent of that. The remaining feeder allowance was
allocated so that the branch with the least freedom still fits: B-17 (CMP-1) is the critical
branch because its terminal at CMP-1 accepts #6 AWG at most, #6 carries 54 A against a 43.25 A
design current, and #6 costs 2.35 percent of its own. The chain to DP-3 therefore had to be
held below 2.653 percent. That is why F-05 runs three parallel sets of
600 kcmil aluminium: its own drop is 1.54 percent, which with
SE-1's 1.11 percent leaves B-17 inside the 5 percent total. The worst
cumulative drop on the schedule is **4.999 percent at B-17** (5.0 percent to two decimal places).

The service-entrance voltage-drop load is **1600 A, the rating of the main device**. EDS-26 2.3
permits either the device rating or the 2000 A ampacity the service conductors are sized to;
the device rating was used and is declared on the schedule (`vd_load_a` = 1600 A for SE-1).

The fire pump F-03 is outside the general limits and is checked to NFPA 70 Article 695 as
adopted in EDS-26 4.6.3: 1.41 percent at 96 A full load (limit 5 percent) and
3.19 percent at 543 A locked rotor (limit 15 percent). The locked-rotor case replaces the
pump's 96 A running current by 543 A in the 1732 A connected service load, so the service
current is 2179 A; SE-1's drop is scaled from its declared 1600 A voltage-drop load and
contributes 1.52 percent, and F-03 contributes
1.67 percent at 543 A. Both readings of the locked-rotor
service load (with or without the pump's running current removed) are far inside the 15 percent
limit.

## 5. Service-entrance sizing decision

UFC 3-501-01 3-2.3.3 and EDS-26 2.2 make **the ampacity of the main bus of the service
equipment, not the rating of the device protecting it**, the sizing quantity. MSB-1 has a
2000 A bus with a 1600 A main device, so SE-1 is sized for 2000 A, not 1600 A. 5
parallel sets of 600 kcmil copper in DB-1 give 5 x 412.8 = 2064 A
corrected, within the six terminals provided at T-1 and MSB-1 and the 600 kcmil maximum
conductor they accept. The set count and size were selected by evaluating every permitted
combination against the same bank calculation: six sets of 400 kcmil reach only 1940 A once
the bank's mutual heating is included and are not compliant; six sets of 500 kcmil reach
2229 A but cost $1,262 more; five sets of 600 kcmil give 2064 A, 3.2 percent above the 2000 A
bus, and the lowest installed cost of the compliant selections. EDS-26 8 requires the lower
installed cost where two compliant selections exist, so the five-set 600 kcmil selection is
used. Its voltage drop spends 4.999 percent of the 5 percent total at B-17, inside both the
5.0 percent limit and the 0.02 percentage-point allowance for the rounding of published cable
data; the 3.2 percent ampacity reserve is the margin on the 2000 A bus. The six-set 500 kcmil
alternative, at 2229 A and 4.93 percent, was the more conservative option and is the fallback
if the service load grows; it is recorded in the option table in the calculation record.

## 6. Duct banks, the assignment and its thermal consequence

DB-1 has twelve 5 in EPC-40 ducts on a 9 in grid, 30 in of cover, a 39.6 in x 29.6 in
encasement. **Ten ducts are available**: D11 is an owner reserve and D12 is an existing
site-lighting feeder, both marked reserved on E-619 and left empty (Section 26 05 33 3.2).
DB-2 has four 4 in ducts, three available; E4 is the communications duct.

Assignment (one three-phase set per duct, no duct shared):

- **SE-1**: 5 sets in D1, D3, D4, D8, D9.
- **F-10**: 2 sets in D5, D10.
- **F-05**: three sets in E1, E2, E3, one set per duct in DB-2's three available
  ducts (E4 is the communications duct and is reserved).

The DB-1 positions were chosen to maximise the lowest SE-1 ampacity while keeping both F-10
sets above their 600 A design current: the five SE-1 ducts raise one another by
23.93 K and the loaded bank raises the two F-10 ducts by
27.37 K. That is the thermal consequence for the other circuits in the
bank: F-10's 350 kcmil conductors carry 417 A in an
otherwise empty bank but only 312.9 A with SE-1 loaded, so its 2 sets give
626 A instead of 834 A for the
600 A design current; two sets are required in either case, but the loaded bank leaves only
26 A of reserve.
SE-1 itself falls from 525 A per conductor in an unloaded bank to
412.8 A.

DB-2 is a separate bank and its three available ducts are all used by F-05. The three F-05
sets raise one another by 1.54 K at the 93.7 A per set operating current, so the
600 kcmil aluminium conductors would still carry about 400 A per set; the 75 C termination
cap of 336 A per set governs the selection, not the mutual heating. The reserved ducts carry
no load and were excluded from every mutual-heating sum (EDS-26 5.3.4).

## 7. Material and standardisation decisions

All conductors are single-conductor XHHW-2, 90 C, sunlight resistant. Every conductor #6 AWG
and smaller is copper, and **every equipment grounding conductor is copper** (EDS-26 3.2;
UFC 3-520-01 3-6.3.1). Aluminium was used only at #4 AWG and larger and only where its lower
installed price survived the check that the same circuit could be terminated and still meet
ampacity, the termination cap and voltage drop: F-01, F-04, F-05, F-06, F-07, F-08, F-09, F-12, F-13
are aluminium; every other circuit is copper. Aluminium was not used where a smaller copper
conductor was cheaper overall once the larger raceway and the higher voltage drop were priced.

Standardisation (EDS-26 3.4.2) allows at most five distinct phase-conductor sizes larger than
#1 AWG. The design uses exactly five: **4/0, 300 kcmil, 350 kcmil, 500 kcmil, 600 kcmil**. The five were chosen by exhaustive
search over every permitted set of five sizes, minimising the installed cost of the whole
package. Every circuit other than SE-1 is at its own ampacity or voltage-drop minimum within
that set, so no circuit carries a size that standardisation alone forced; SE-1 uses 5 sets of
600 kcmil as the lowest-cost compliant option (2064 A) rather than the ampacity minimum of
6 x 500 kcmil (2229 A), as section 5 explains.

Equipment grounding conductors are sized from NFPA 70 Table 250.122 on the rating of the
overcurrent device ahead of the circuit and are increased in the same circular-mil ratio where
the phase conductor was increased above the ampacity-only size to meet voltage drop
(NFPA 70 250.122(B); EDS-26 5.7). That rule is why F-05's 600 kcmil phase conductors carry
a 3/0 EGC: the ampacity requirements alone would allow a much smaller phase conductor
with three sets.

## 8. Cost

The installed cost of the package is **$151,236.32**, made up of

| Component | Amount (USD) |
|---|---|
| Conductor (phase and equipment grounding, net of the quantity break) | 93,734.78 |
| Terminations (per set per end) | 9,407.94 |
| Raceway (interior rigid steel conduit, one run per set) | 48,093.60 |
| **Total installed** | **151,236.32** |

of which **material $98,230.49** and **labour $53,005.83**. Duct banks and the roof cable tray
are existing and carry no installed cost in this scope (unit price book basis note A2); conduit
is priced only for the 25 circuits installed in interior raceway, one run per parallel set,
over the same length as the conductors including the 16 ft termination allowance. The total
length of conductor installed is 39,752 ft (equipment grounding conductors count),
which reaches the 38,000 ft campus quantity break, so the 6 percent deduction of
$5,983.07 is carried as a line of its own against the conductor material and labour.
Every line of the ledger carries its material and labour part and they add to the amount; the
ledger total equals `total_usd` on the calculation front sheet.

## 9. Disagreements between documents and how each was resolved

| Disagreement | Resolution and why |
|---|---|
| EDS-26 **Rev 2** (superseded) allows 7 distinct sizes above #1 AWG, 4 parallel sets, 2 percent feeders and sets the voltage-drop load at the connected load; **Rev 4** allows 5 sizes, 6 sets, 3 percent feeders and takes the load by circuit class | Rev 4 governs. EDS-26 Rev 4 1.2 supersedes Rev 2 in its entirety and Rev 2 "must not be used for design"; G-001 repeats that superseded standards are retained for reference only |
| **E-601 Rev A** (superseded) shows SE-1 1200 A / 1402 A, F-01 400 A / 362 A, F-05 250 A / 202 A, F-10 400 A / 318 A; the issued-for-construction one-line and connected load schedule show SE-1 1600 A / 1732 A, F-01 600 A / 455 A, F-05 400 A / 281 A, F-10 600 A / 432 A | Rev A is superseded by Revision C (12 June 2026) and states that its loads and device ratings are not current and must not be used. The issued-for-construction values were used |
| **Meridian Cable** datasheet publishes different ampacities (e.g. 500 kcmil 434 A) from **Cascadia** (455 A at 90 C in raceway) | Cascadia is the basis of design (26 05 19 1.3) and 26 05 19 1.3 forbids substituting another manufacturer's ampacities; the Meridian sheet itself says it is not the basis of design |
| **GEO-4210-T 2.1** gives 0.95 K.m/W for the native soil; **GEO-4210-T 2.2** gives 0.60 K.m/W for the thermal backfill | 0.60 K.m/W used. The report states that both duct banks are encased and surrounded by the thermal backfill for the full width of the trench, so the backfill and not the native soil is the material whose resistivity enters the earth and mutual-heating terms. 0.95 is recorded as a rejected value |
| **GEO-4210-T 2.4** logs 22.1 to 28.4 C at 36 in; EDS-26 5.3.2 derives the earth ambient from the station record | 27.45 C used. GEO 2.4 itself says the logged readings do not span the summer maximum and must not be used as a design earth ambient |
| **M-501-C** states 46 C at the roof tray; EDS-26 5.4 derives 42 C + 4 K | They agree (46 C). The station record value 106.8 F = 41.56 C rounds up to 42 C and the roof allowance adds 4 K |
| **UFC 3-501-01 2-1.11.c** directs NFPA 70 ampacity tables for exterior systems; **EDS-26 5.1** requires calculated ampacity for every circuit on this project | EDS-26 5.1 governs. The UFC clause is limited to exterior systems not associated with a building; these duct banks are the Building 4210 service laterals, and NFPA 70 Article 310.14 permits calculated ampacity. The termination cap still uses the published table values, so the result is not less restrictive |
| **NFPA 70** addresses voltage drop only in advisory informational notes; **UFC 3-501-01 3-2.7** makes 3/3/5 percent mandatory | The UFC limits applied, per EDS-26 5.6 and the most-restrictive rule in EDS-26 1.1 |
| **EDS-26 2.3** allows the service-entrance voltage-drop load to be read as the device rating or as the conductor ampacity | 1600 A, the device rating, used and declared on the schedule. It is also the only reading under which the DP-3 chain can meet the 5 percent total, because B-17 is already at the largest conductor its terminal accepts |
| Issued-for-construction E-601 one-line device ratings vs the connected load schedule device ratings | They agree for every circuit (20 to 1600 A); the connected load schedule value was used |
