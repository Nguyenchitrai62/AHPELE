# BASIS OF ESTIMATE — DEVICE TAKEOFF AND PRICED BILL
MERIDIAN DATA CENTER — PHASE 1, DATA HALL 1 (ec_0205_d100)

## 1. Counting convention applied (with clause)
C1 a device is counted once, wherever shown (E-201..E-204 general sheet note 2 and the
match-line notes); C2 the E-001 legend is the only definition of a symbol; C3 a symbol
not in the legend carries no quantity and is listed in section 4 below; C4 a legend
entry with no instance carries zero; C5 keyed notes are part of the drawing; C6 the
latest issue governs; C7 areas cross-referenced to an enlarged plan are counted from
the enlarged plan only; C8 condition from location (A-102, E-002); C9 counts split by
condition. Symbols drawn in grey on the far side of a match line (east of A-A, north of
B-B) are reference only and were not counted. The structural column grid (E-001 legend
note 6; A-101 "STRUCTURAL GRID — DIMENSIONS TO COLUMN CENTRELINES 7200") is the only
grid used for bay reporting. locations.csv gives grid_bay as the structural bay of the
E-001 note-6 grid (lettered A.. northward from the south wall, numbered 1.. eastward
from the west wall); where a device was recorded by its A-101 access-floor tile address
(A-101 plan note 2), that address was converted to the structural bay it lies in. The
600 mm access-floor tile grid is a finish grid, not a column grid, and is not the
census of structural bays.

## 2. Sheets each type was counted from
| type | sheets and views | quantity |
|---|---|---|
| R1 | E-201 (10 drawn, 3 deleted by ADD-02 = 7), E-202 (13), E-203 (4), E-204 (3), E-231 (4), E-232 (3), E-233 (2) | 36 |
| R2 | E-232 (2), E-233 (3), plus 2 added in grid bay A1 by ADD-02 | 7 |
| R3 | E-231 (2), E-232 (2), E-233 (1) | 5 |
| R4 | E-202 (4), E-233 (2) | 6 |
| R5 | E-201 (4), E-202 (1), E-204 (1), E-231 (1), E-232 (1), E-233 (1) + keyed note <2> (16 CRAH units) | 25 |
| R6 | E-201 (1), E-203 (1), E-231 (1), E-233 (1) | 4 |
| R7 | keyed note <3>: one recessed floor box at each PDU (PDU-01..06) | 6 |
| J1 | E-201 (11), E-202 (7), E-203 (7), E-204 (8), E-231 (2), E-232 (1) | 36 |
| P1 | E-201 (1), E-202 (1), E-203 (1), E-231 (2), E-232 (1), E-233 (1) | 7 |
| F1 | keyed notes <1> and <4> (not drawn): 8 column bays on the north and south walls + 4 egress doors | 12 |
| F2 | E-211 (1), E-231 (1), E-233 (1) | 3 |
| F3 | E-211 (2), E-233 (1) | 3 |
| F4 | E-211 (6) | 6 |
| F5 | E-211 (24) | 24 |
| D1 | E-211 (25), E-231 (1), E-232 (1) | 27 |

Every per-(sheet, type) total above is the sum of the bay rows for that sheet and type
in locations.csv; every type total is the sum of its locations.csv rows and appears
unchanged in takeoff.csv.

## 3. Governing issue
The drawing set is issued for construction 2026-07-24; every device plan is at revision
2 dated 2026-07-27 ("SEE CLOUDS"). ADD-02 is dated 2026-08-07 and therefore postdates
every sheet revision, so it governs for what it describes: item 02-1 deletes the duplex
receptacles clouded and tagged revision 2 in grid bay A1 and adds one quadraplex
receptacle at each of the first and second deleted positions measured from the south.
Three E-201 R1 symbols lie inside the cloud (x=1049, y=1470/1848/2322; the two further
E-201 R1 at x=1049, y=622/1000 are north of the cloud boundary): all three are deleted,
so R1 falls from 39 drawn to 36. The two additions raise R2 from 5 to 7. The sheet
governs for everything else; ADD-02 items 02-2 and 02-3 make no change.

## 4. Symbols not in the legend (no quantity carried)
| sheet | location (structural grid bay) | mark | reason |
|---|---|---|---|
| E-201, E-202, E-203 | hall centre, bay C2 / C3 | 45 mm open circle with cross-hair (4 per sheet) | not in the E-001 legend; reviewed at 8x; not a scheduled device |
| E-201..E-204, E-231..E-233 | sheet edges | section markers "1" "2" "A" "B" "C", north arrows and grid bubbles | drawing furniture |
| E-231..E-233 | view margins | PDU / CRAH / structural-column equipment symbols (orange, green and grey legend) | equipment legend, not device symbols |
No other mark outside the device legend was found on any plan.

## 5. Condition split (type mark, condition) and where it came from
A-102 notes: P1 = steel stud and gypsum board (outlet box 100 mm square with raised
plaster ring); P2 = nominal 200 mm concrete masonry (masonry box, no plaster ring);
P3 = two-hour fire-rated assembly (firestopped, Section 07 84 00). A-102 note 5: the
areas hatched DAMP are the condensate apron of each perimeter cooling unit and the
entry vestibule; no area is a wet location. E-002 supplies mounting and branch.
E-002 conditions take precedence (EMERGENCY by branch, IG, CEILING and ACCESS-FLOOR by
mounting) and a duct detector is carried under CEILING wherever it is. Otherwise a
device inside a DAMP area is DAMP; any other device that takes a wall condition takes
the construction of the nearest wall measured to its centreline. A keyed-note device
drawn nowhere takes the construction of the wall the note names (for a device at a
door, the wall that door is in on A-102), or DRY-STUD where the note names none:
keynote <1> names the north and south walls (both P2 masonry) -> DRY-MASONRY;
keynote <4> puts one appliance on the wall at each exit door, so D-01 and D-02 (in the
P2 wall, door schedule "P-R1" wall) -> DRY-MASONRY and D-04/D-05 (in the P1 exterior
walls W-W/W-E) -> DRY-STUD; keynotes <2> and <3> name no wall -> DRY-STUD / ACCESS-FLOOR.
Split: R1 DRY-MASONRY 21, R1 DRY-STUD 9, R1 RATED-2HR 6, R2 DRY-MASONRY 2, R2 DRY-STUD 5, R3 DRY-STUD 5, R4 IG 6, R5 DAMP 9, R5 DRY-STUD 16, R6 EMERGENCY 4, R7 ACCESS-FLOOR 6, J1 DRY-MASONRY 24, J1 DRY-STUD 3, J1 RATED-2HR 9, P1 DRY-MASONRY 2, P1 DRY-STUD 4, P1 RATED-2HR 1, F1 DRY-MASONRY 10, F1 DRY-STUD 2, F2 DRY-MASONRY 1, F2 DRY-STUD 2, F3 DRY-MASONRY 2, F3 DRY-STUD 1, F4 CEILING 6, F5 ACCESS-FLOOR 24, D1 CEILING 27.

## 6. Assembly chosen per condition and the clause permitting it
| condition | assembly per device | clause |
|---|---|---|
| DRY-STUD | BOX-4SQ-15 + RING-1G-58 (+ CVR-4SQ-BLANK for J1) | 26 05 33 2.2 |
| DRY-MASONRY | BOX-MAS-4KO, no ring (two ganged boxes for the quadraplex R2) (+ CVR-4SQ-BLANK for J1) | 26 05 33 2.3 |
| RATED-2HR | BOX-4SQ-15 + RING-1G-58 + ACC-FIRESTOP-PAD (+ CVR-4SQ-BLANK for J1; BOX-PULL-12 + pad for P1) | 26 05 33 2.4; 07 84 00 2.1 |
| DAMP | BOX-4SQ-15 + RING-1G-58 + DEV-GFCI-20 (wet-listed, integral GFCI) | 26 05 33 2.5; 26 20 00 2.3/2.5 |
| CEILING | BOX-4SQ-15 + DET-PHOTO (F4) / INS-DUCT-DET installation only (D1) | 28 31 76 3.2; 26 05 33 2.9 |
| ACCESS-FLOOR | BOX-FLOOR-2G for the floor box R7; BOX-4SQ-15 + DET-PHOTO-UF for F5 | 26 05 33 2.6; 28 31 76 3.2 |
| EMERGENCY | separate BOX-4SQ-15 + RING-1G-58 + DEV-DUP-20 | 26 20 00 3.2; E-002 note 2 |
| IG | BOX-4SQ-15 + RING-1G-58 + DEV-IG-20 + ACC-IG-CONDUCTOR | 26 20 00 2.2 |
| R2 quadraplex | two ganged BOX-4SQ-15 + two RING-1G-58 + two DEV-DUP-20 (stud); two BOX-MAS-4KO + two DEV-DUP-20 (masonry) | 26 05 33 2.1-2.3 |

A quadraplex receptacle has four outlets; the catalogue carries no quadraplex device and
no two-gang ring or plate, so the permitted assembly is two duplex devices (DEV-DUP-20)
in two ganged 4 inch square boxes, one single-device ring each in a stud wall and no ring
in masonry (26 05 33 2.1 "boxes ... for the device they receive"; 2.3 no plaster ring in
masonry). Attaching two duplex devices to one single-gang box and one single-device ring
would not be a permitted assembly.

The catalogue carries no extra-duty weather-resistant while-in-use hood and no cast
metal damp box. The specification (26 20 00 paragraph 2.3, restating UFGS 26 20 00
2.12.2; 26 05 33 2.5) requires a gasketed, hinged, lockable, weather-resistant
EXTRA-DUTY rated while-in-use hood in every damp location. No hood line is carried
because the catalogue has no such item; the requirement is recorded here as instructed.

## 7. Keyed-note census (convention C5)
<1> one visible notification appliance at each structural column bay on the north and
south walls. The A-101/A-102 structural column grid has three internal column lines
numbered 1, 2 and 3 at 7200 mm centres (A-101 "STRUCTURAL GRID — DIMENSIONS TO COLUMN
CENTRELINES 7200") plus the two end walls: four structural column bays on each long
wall, eight in all. The 600 mm access-floor tile grid letters (AA..BT etc.) are finish
tiles, not column lines (A-101 plan note 2), and are not the census. <4> one visible
notification appliance on the wall at each exit door: the A-102 door schedule marks
D-01, D-02, D-04 and D-05 EGRESS YES and D-03 EGRESS NO, so 4 doors. F1 = 8 + 4 = 12.
<2> one weather-resistant receptacle within 7.6 m of each CRAH unit: 4 perimeter plus
12 in-row units (A-601) = 16, additional to the 9 R5 symbols drawn (the note is marked
NOT SHOWN, so its devices are not the drawn symbols; conversely the 4 drawn R5 in the
DAMP entry vestibule are not claimed against the 16). <3> one recessed floor box at each
PDU: PDU-01..06 (A-601) = 6.

## 8. Mounting heights (E-002, measured to centre of device)
Receptacles 460 mm AFF; R8 1200 mm; J1 and P1 2600 mm; F1/F2/F6 2286 mm; F3 1067 mm;
F4 at ceiling; F5 in the access floor; R7 flush in floor; D1 at the unit.

## 9. Spare stock and carton method
The REQUIRED quantity of a catalogue item is the sum over every (type mark, condition)
pair of the pair's device count times the item's multiplicity in the chosen assembly.
The unit price is the price list rate for the band the item's own required quantity
falls in, using that line's own printed breaks (manual section 4.3; the price list
states "Each line carries its own quantity breaks" — the manual's generic 1-24/25-99/100+
summary does not override a line's printed breaks). The quantity BOUGHT is
ceil(1.05 x required / carton) x carton: 1.05 is the Owner's 5 per cent spare stock
(OPR section 4) and the carton is the price list carton quantity, since a part carton is
not supplied. Purchase rows carry (PURCHASE)/(STOCK); a catalogue item with no required
quantity carries a zero purchase row so that every catalogue item has one.

## 10. Basket total
Basket total (sum of the attribution rows' extended prices, the price of the work) =
**$15943.22**. Sum of all rows including the purchase rows = $34137.75.
