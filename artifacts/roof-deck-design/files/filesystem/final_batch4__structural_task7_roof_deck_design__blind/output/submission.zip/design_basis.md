# DC-2 Helena Data Centre - Building A
## Roof deck design basis - gravity, diaphragm and attachment

Project DC2-2026-014 | Sandalwood Marlow Structural Engineers, PLLC | Roof steel deck package
Design basis issued with the roof deck drawing and the deck attachment schedule.

## 1 Documents that govern, and how conflicts were resolved

| Issue | Values found | Resolution |
|---|---|---|
| Revision status | EOR-DC-RD-01 Rev 1 and Rev 2 both in the file; A-201 Rev B and Rev C; S-101 Rev 2/Rev 3; M-401 Rev B/Rev C; T-118 transmittal dated 01 Aug 2026 | T-118 lists the current revision of each. **EOR-DC-RD-01 Rev 2**, **A-201 Rev C**, **S-101 Rev 3**, **S-501 Rev 2**, **M-401 Rev C**, **LAT-2026-003 Rev 1**, **SNOW-2026-014 Rev 0** and model **DC2-A-STR Rev C** govern. EOR-DC-RD-01 Rev 1 and the Rev B drawings are superseded and were not used. Rev 1 of the criteria allowed a roof live load reduction on the deck; Rev 2 clause 4.2 forbids it. |
| Roof live load on the deck | Rev 1 reduced Lr; Rev 2 unreduced | Rev 2 clause 4.2 governs: the deck panel tributary area is 3 ft x 6 ft = 18 sq ft, below the 200 sq ft threshold, so R1 = 1.0 and Lr = 20 psf unreduced. |
| Ground snow | Site study vs mapped value | SNOW-2026-014 Rev 0 (accepted by the AHJ on 28 April 2026) gives pg = 63 psf on the Risk Category II basis required by the study. Criteria clause 2.2 applies Is = 1.10 once only; the study value is not re-factored. |
| Equipment screen SCR-N and SCR-E position | A-201 Rev B (earlier positions) vs A-201 Rev C and the model | T-118 note 3.2 and model note clause 5: the Rev C position and the model govern. SCR-N is at y = 163.667 to 164.333 ft, x = 18 to 222 ft; SCR-E is at x = 215.667 to 216.333 ft, y = 24 to 144 ft. |
| Rooftop unit and enclosure geometry | M-401 Rev C vs model vs schedule | M-401 Rev C, the model and the mechanical schedule agree on plan positions and heights (RTU-1 to RTU-8 7 ft, RTU-9 and RTU-10 9 ft, RTU-11 and RTU-12 8 ft, SCR-N 6 ft, SCR-E 7 ft, MEP-PH-1 12 ft). The model is the geometry of record. |
| Seismic hazard | USGS ASCE 7-22 RC-III Site Class D gives SDS = 0.44, SD1 = 0.24; the 2019 preliminary ASCE 7-16 RC-II Site Class C file gives SDS = 0.407, SD1 = 0.149 | Criteria clause 7.1 fixes SDS = 0.44 and SD1 = 0.24, which reproduce the ASCE 7-22 Risk Category III, Site Class D map. The 2019 preliminary file is neither the governing risk category nor the governing site class and was not used. |
| DoD overlay | UFC 3-301-01 Change 6 (2026) and UFC 1-200-01 Change 4 (2024) | UFC 3-301-01 is the overlay invoked by criteria clause 1.2. It supplies Table E-1 (roof live), paragraph 3-4.1 (snow buildup) and section 1604.3.1 [Replacement] (deflection). UFC 1-200-01 Change 4 is the current umbrella document. No conflict with the criteria values. |
| Deck gages available | Catalogue lists 22, 20, 18 and 16 gage | Deck Stock Availability 2026-07: 22, 20 and 18 gage are ex stock at 2, 3 and 4 weeks; 16 gage is a mill order at 14 weeks, against the 9 week release-to-site allowance of OBD section 5. **16 gage is not available** and was excluded. The design uses 22 and 18 gage only. |
| Framed openings | S-101 Rev 3 and A-201 Rev C agree: RO-1 and RO-2 are 12 ft x 12 ft, RO-3 is 30 ft x 20 ft | Openings are at 96-108 / 48-60, 132-144 / 120-132 and 180-210 / 60-80 ft. No deck is placed over them (criteria 10.5). |
| Interior deck bearing detail | S-501 Detail 1 shows two panel ends meeting at an interior joist; Joist Schedule note N2 says the 2.5 in top chord bearing width is shared between the two sheets that lap on that joist | The 1.5 in minimum bearing of criteria 10.6 and S-501 note B governs. The deck is laid with **staggered panel ends and lapped/nested end bearing** as described in section 6, so each panel end has at least 1.5 in bearing on the 2.5 in top chord. The butted mid-chord condition that would give 1.25 in per end is not used. No bearing RFI remains open. |

## 2 Snow basis

- Ground snow pg = **63 psf** (SNOW-2026-014 clause 6, Risk Category II basis, accepted by the AHJ).
- Exposure Ce = 0.90 (Terrain Category C, partially exposed roof), thermal Ct = 1.00, importance Is = 1.10 for Risk Category III (criteria 5.1).
- pf = 0.7 x 0.90 x 1.00 x 1.10 x 63 = **43.66 psf**. Because pg > 20 psf, the minimum roof snow load and the rain-on-snow surcharge do not apply.
- Snow density gamma = 0.13 x 63 + 14 = **22.19 pcf**, not greater than 30 pcf. Balanced depth hb = pf / gamma = **1.968 ft**. All clear heights are measured from the top of the balanced snow: hc = h - hb.
- Drift height hd = 0.43 lu^(1/3) (pg + 10)^(1/4) - 1.5 ft, with lu not less than 20 ft. A full-height drift peaks at hd x gamma over a width 4 hd. A drift truncated by the obstruction peaks at hc x gamma over w = min(4 hd^2 / hc, 8 hc).
- **Windward faces** take a drift height of **0.75 hd** with lu equal to the roof fetch from the upwind roof edge to the face (criteria 5.4.3). The 0.75 hd value is the drift height compared with hc in the 5.4.2 truncation check.
- **Sheltered faces** take a drift height of **hd** with lu equal to the along-wind length of the obstruction itself (criteria 5.4.4).
- All four wind directions are run in turn. At each point the largest surcharge produced by the four directions is retained; the four directions are not superimposed (criteria 5.4.5). A drift is a triangle against one face, not an infinite strip.
- Parapets are treated by the windward rule with lu equal to the roof dimension upwind of the parapet and hc = parapet height minus hb (criteria 5.4.6). The parapet is 3 ft-6 in high on all four sides, so hc = 3.5 - 1.968 = 1.532 ft.
- Every RTU, both screen walls and MEP-PH-1 have hc greater than 2.0 ft and take the full drift treatment (criteria 5.5). The balanced load acts over the whole roof, including beneath the drifts.
- The deck is checked on the 6 ft x 6 ft cell grid. Each cell is given the peak surcharge occurring anywhere inside it, and each zone carries the peak of the cells it contains (criteria 5.4.7). Drift surcharges are not included in the effective seismic weight; the balanced snow is (criteria 7.2.1).

### 2.1 The four required Drifts rows

The Drifts sheet reports the design surcharge at each named face, i.e. the larger of the windward and sheltered cases at that face under criteria 5.4.5.

| Location | Face | Peak surcharge (psf) | Band (ft) | Basis |
|---|---|---|---|---|
| MEP-PH-1 | W | 104.3 | 41.2 to 60.0 | Sheltered (leeward) drift, wind from the east, lu = 120.0 ft (the x-length of the enclosure); hd = 4.700 ft < hc = 10.032 ft, so full height, w = 4 hd = 18.80 ft. The windward drift from the west is smaller, 56.9 psf. |
| SCR-N | S | 89.5 | 147.5 to 163.7 | Windward drift, wind from the south, lu = 163.667 ft. 0.75 hd = 4.031 ft, just below hc = 4.032 ft, so the drift is full height (not truncated); w = 4 x 4.031 = 16.13 ft. The leeward case from the north is 42.4 psf. |
| PARAPET | N | 34.0 | 167.1 to 179.3 | Windward rule, lu = 180.0 ft. 0.75 hd = 4.198 ft exceeds hc = 1.532 ft, so the drift is truncated: peak = hc x gamma = 34.0 psf, w = min(4 hd^2/hc, 8 hc) = 12.26 ft. The face is the inside of the north parapet at y = 179.333 ft. |
| RTU-1 | E | 98.2 | 36.0 to 53.7 | Windward drift, wind from the east, lu = 240 - 36 = 204.0 ft. 0.75 hd = 4.424 ft < hc = 5.032 ft, so full height, w = 4 x 4.424 = 17.70 ft. The leeward case from the west is 42.4 psf with lu = 12 ft floored to 20 ft; the windward case governs. |

The 104.3 psf at the MEP-PH-1 west face produces the 160.9 psf Z3 demand (104.3 + 43.66 balanced + 13.0 dead). The SCR-E **end-face** leeward drifts (not one of the four required rows) produce the 160.9 psf demand in Z4: SCR-E is 120 ft long in y, so the leeward drift at either end has lu = 120 ft and peak 104.3 psf; the south-face drift extends south from y = 24 ft and the north-face drift extends north from y = 144 ft. The SCR-E **east-face** leeward drift (42.4 psf) produces the 98.2 psf demand in Z2. The 98.2 psf RTU-1 east-face value is reported because the task requires that face; it is not the governing zone demand.

## 3 Seismic and wind basis

- SDS = 0.44, SD1 = 0.24, Site Class D, Seismic Design Category D, Ie = 1.25, R = 3.25 for the ordinary concentrically braced frames, Omega_0 = 2.0, rho = 1.0 (criteria 7.1 and LAT-2026-003 Table 3-1).
- Effective seismic weight: roof dead weight **18.0 psf** (LAT Table 5-2) plus 20 per cent of pf because pf = 43.66 psf exceeds 30 psf: 18.0 + 0.2 x 43.66 = **26.73 psf** over the 240 ft x 180 ft plan. Drift surcharges are excluded.
- Cs = SDS Ie / R = 0.44 x 1.25 / 3.25 = 0.1692. Fpx = Cs wpx = 0.1692 x 1154.8 kip = **195.4 kip**, within the 0.2 SDS Ie and 0.4 SDS Ie bounds (127.0 and 254.0 kip).
- The seismic inertial force is distributed over the roof plan by tributary area. Accidental torsion of 0.05 times the plan dimension perpendicular to the force is applied as a plan couple: 9.0 ft for forces along x and 12.0 ft for forces along y. The model captures the inherent torsion because each braced frame is a spring at its actual position and stiffness.
- Wind: 118.0 kip along x and 152.0 kip along y enter half at each of the two walls perpendicular to the force (LAT 4.2). Wind Case 2, 75 per cent of the case 1 pressures with an eccentricity of 0.15 times the perpendicular plan dimension, was run in both directions; the envelope of Case 1 and Case 2 is reported.
- The load combinations are those of criteria 8.1: D + Lr and D + S on the ASD basis for deck gravity and end reaction; 0.9D + 1.0W on the LRFD basis for uplift; 1.0W and 1.0E on the LRFD basis for diaphragm shear, chord and collector. Snow and roof live load are not combined (criteria 8.2); thermal effects are excluded (criteria 1.5).

## 4 Diaphragm analysis and classification

The roof was analysed as the in-plane assembly described in LAT-2026-003 clause 7 and criteria 9.3. Nodes are at every joist line (6 ft module, 41 lines) and every girder line (30 ft module, 7 lines). A 6 ft x 30 ft shear panel in every joist bay by girder bay carries pure shear with the G' of the deck actually specified in that panel. Axial bars run along every joist line (EA = 87,580 kip), every girder line (EA = 221,850 kip) and, added to the boundary lines, the L5x3-1/2x5/16 continuous edge member (EA = 74,240 kip). Each braced frame is a spring of half its stiffness at each of its two column lines (BF-X1/X2 55.0 kip/in, BF-X3/X4 18.0 kip/in, BF-Y1/Y2 22.0 kip/in, BF-Y3/Y4 68.0 kip/in). The three framed openings are holes in the shear field, with axial members around them. A small regularisation spring acts on every free degree of freedom; it carries **0.31 per cent** of the applied force, well below the 2 per cent limit that would indicate a missing load path.

The model was validated before it was used. A single 6 ft (x) by 30 ft (y) panel at G' = 20 kip/in gives a stiffness of G b/a = 20 x 30 / 6 = **100 kip/in** for force along x (depth 6 ft, width 30 ft) and G a/b = 20 x 6 / 30 = **4.0 kip/in** for force along y; the FE reproduces both closed-form values. The sum of the reactions equals the applied force to better than 0.01 per cent in every case.

The model is solved at the G' of the deck selected. The G' values, each reproduced from the catalogue basis of clause 5.2, are:

| Zone | Specification | G' (kip/in) |
|---|---|---|
| Z1 | 22 gage, 36/4, BP, ns = 2 | 10.1 |
| Z2 | 22 gage, 36/9, SCREW-10, ns = 5 | 29.8 |
| Z3 | 18 gage, 36/7, SCREW-10, ns = 3 | 26.8 |
| Z4 | 18 gage, 36/9, SCREW-10, ns = 5 | 45.6 |

The reported results are the envelope of Wind Case 1 and Case 2 for wind, and the seismic case with accidental torsion:

| Scenario | Direction | Max shear (plf) | Max in-plane deflection (in) | Chord (kip) | Collector (kip) |
|---|---|---|---|---|---|
| S05 | x | 398.9 | 0.37 | 15.25 | 11.43 |
| S06 | y | 563.2 | 0.77 | 21.65 | 11.72 |
| S07 | x | 640.4 | 0.61 | 27.56 | 20.65 |
| S08 | y | 738.5 | 0.98 | 27.82 | 15.06 |
| S10 | x | 640.4 | 0.61 | 27.56 | 41.30 |

### 4.1 Deflection and classification

Clause 9.2 limits the **in-plane deflection of the roof diaphragm** to 1.60 in. The quantity includes the shear flexibility of the deck, the flexibility of the chords and the flexibility of the connections. The model reports the diaphragm deformation as the maximum deviation of the roof nodes from a best-fit rigid-body motion (translation plus rotation); that is **0.98 in under S08**, below 1.60 in. The total nodal displacement is 2.57 in under S08, but 1.75 in of that is the translation of the flexible Y frames at BF-Y1/Y2; a 1.60 in limit on total nodal displacement would be unattainable by any deck because the frames alone exceed it. The 1.60 in limit is therefore applied to the diaphragm deformation relative to its supports, as clause 9.2 defines it.

Clause 9.3 classifies the diaphragm by comparing the computed maximum in-plane deflection with 2.0 times the average storey drift of the vertical elements. The average frame drift from the model is **1.309 in** for the four Y frames under S08 and **1.531 in** for the four X frames under S07, so the 2.0x values are 2.618 in and 3.061 in. The diaphragm deformation of 0.98 in (S08) is below 2.618 in, and 0.61 in (S07) is below 3.061 in. The diaphragm is therefore **semi-rigid** and has been analysed as an in-plane element of finite stiffness with the frames as springs, never by tributary area. Even the total nodal displacement (2.57 in under S08) is below 2.618 in, so the classification is semi-rigid on either reading. The allowable storey drift for Risk Category III (0.015 x 32 ft = 0.48 ft = 5.76 in) is not approached.

### 4.2 Chords and collectors

The chord force is the largest axial force in the perimeter chord line for that direction: 27.56 kip under seismic along x and 27.82 kip along y, against the governing chord splice capacity of **38.0 kip** (utilisation 0.73). The collector force is the largest axial force in a perimeter member within one bay of a braced frame of that direction: 20.65 kip along x and 15.06 kip along y. The x collector is amplified by Omega_0 = 2.0 in S10 to **41.30 kip**, against the **58.0 kip** collector splice (utilisation 0.71); the y collector amplified is 30.12 kip. The splices govern over the gross member capacities (LAT Table 6-1 and clause 6.2.1).

## 5 Zoning decisions and what drove each one

The design respects the constructability limits of criteria 10.2: **2 deck gages** (22 and 18), **3 attachment patterns** (36/4 BP with 2 sidelaps, 36/7 SCREW-10 with 3 sidelaps, 36/9 SCREW-10 with 5 sidelaps), **4 zones** and **14 rectangles**. Every zone boundary falls on a joist line (6 ft x-module) and a sidelap line (6 ft y-module). No two rectangles overlap, and the 14 rectangles cover the full 240 ft x 180 ft roof envelope.

The zone rectangles are nailing/fastening envelopes on the 6 ft module, not a deck-placing layout. No deck is placed over RO-1, RO-2 or RO-3 (criteria 10.5); the openings are framed out, shown on layer `S-OPENING` of the drawing, and cut out of the BOM and cost. The rectangles span the openings only to keep long, straight zone boundaries within the 14-rectangle limit.

| Zone | Gage | Pattern | Sidelap | Rectangles | Net area (sf) | What drove it |
|---|---|---|---|---|---|---|
| Z1 | 22 | 36/4 | BP x 2 | 1 | 5,184 | Interior, clear of openings, drift surcharge below 50.2 psf and Zone 1/1-prime uplift. Lowest-cost specification that satisfies gravity, 33.1 psf uplift capacity and the low interior shear (152.6 plf demand). |
| Z2 | 22 | 36/9 | SCREW-10 x 5 | 4 | 11,376 | Perimeter Zone 2 uplift band (68.7 psf net demand) and the perimeter diaphragm shear (738.5 plf demand), where the drift is low enough for 22 gage. The 36/9 pattern on 22 gage gives 74.5 psf uplift and 819 plf shear capacity. |
| Z3 | 18 | 36/7 | SCREW-10 x 3 | 5 | 21,216 | Balanced snow plus the drifts of MEP-PH-1, SCR-N, SCR-E and the RTUs, where 22 gage runs out of gravity capacity (demand up to 160.9 psf against 106 psf). 18 gage allows 177 psf and the 36/7 pattern gives 742.7 plf shear capacity. |
| Z4 | 18 | 36/9 | SCREW-10 x 5 | 4 | 4,536 | Zone 3 corner wind uplift (94.9 psf net demand needs 18 gage 36/9: 0.5 x 479 x 9/18 = 119.8 psf) and the S04 SCR-E end-face leeward drifts at the southeast and northeast corners (160.9 psf). |

The principal drivers, in order of area:

1. **Drift gravity.** MEP-PH-1, SCR-N, SCR-E and the twelve RTUs create local drift surcharges up to 104.3 psf at the MEP-PH-1 west and east faces, 89.5 psf on the south face of SCR-N, 104.3 psf on the south face of SCR-E (leeward, lu = 120 ft) and 98.2 psf on the east face of RTU-1. The 22 gage allowable total load is 106 psf; after the 10.5 psf collateral dead load, 1.6 psf deck self-weight and 43.66 psf balanced snow, 22 gage can carry **50.2 psf of drift surcharge** (93.9 psf total snow plus drift). The 18 gage allowable is 177 psf, or **120.3 psf of drift surcharge** (164.0 psf total snow plus drift). Zones Z3 and Z4 therefore use 18 gage where the demand exceeds the 22 gage limit; the remainder of the roof is 22 gage.
2. **Wind uplift.** Zone 3 corners (94.9 psf net demand) are the only place where the attachment, not the gage, cannot be met by 22 gage: 18 gage 36/9 gives 119.8 psf. Zone 2 needs the 36/9 pattern (74.5 psf on 22 gage). Zone 1 and Zone 1-prime are satisfied by the light 36/4 BP pattern.
3. **Diaphragm shear.** Seismic along y governs the diaphragm (738.5 plf in Z2, 639.4 plf in Z3) because the Y frames are concentrated in two bays on each of grids 1 and 9. The perimeters carry the shear into those frames, which is why the strong patterns sit in the perimeter zones while the interior needs only 36/4 BP (152.6 plf demand).
4. **Boundary and opening edges.** Criteria 10.4 requires at least 36/7 and 3 sidelaps on every zone that touches the roof perimeter or the edge of a framed opening. Z2 and Z4 (perimeter) use 36/9 and 5; Z3 (opening edges and drift bands) uses 36/7 and 3. Z1 is the only zone that touches neither the perimeter nor an opening, so its 36/4 BP pattern is permitted.
5. **Constructability and cost.** The 2 gage / 3 pattern / 12 zone / 14 rectangle limits are hard. The layout was selected by enumerating 13- and 14-rectangle partitions at the CP-RD-2026 rates. The lowest feasible 14-rectangle layout is the submitted one at **USD 218,140**. A 13-rectangle variant at USD 217,956 and a 14-rectangle variant at USD 217,922 were cheaper on material but reached shear utilisations of 1.017 and 1.026 respectively, and were rejected; the submitted layout keeps the worst shear utilisation at 0.902. The 18 gage area is 25,752 sf rather than the 31,224 sf of an all-drift-band envelope because 22 gage is used wherever its 106 psf total capacity and 74.5 psf uplift capacity are sufficient.

## 6 Design checks

- **Governing scenario by zone** (largest demand/capacity ratio, reported in the CalcSummary): Z1 S09 (uplift, 0.81), Z2 S04 (gravity, 0.926), Z3 S02 (gravity, 0.909), Z4 S04 (gravity, 0.909).
- **Gravity.** ASD D + S with drift (S02, S03, S04) and D + Lr (S01). The catalogue allowable total load includes the deck self-weight. Worst utilisation **0.926** (Z2, S04: 98.2 psf against 106 psf). Z3 and Z4 reach 160.9 psf against 177 psf (0.909).
- **Deflection.** The 6 ft span is 72 in, so span/240 = **0.30 in**. The 3-span continuous deflection is delta = 0.0069 w L^4 / (E I) with L = 72 in, E = 29,500 ksi, I = 0.169 in^4/ft for 22 gage and 0.285 in^4/ft for 18 gage. At the worst snow-plus-drift demand (Z3, 147.94 psf snow excluding dead) the 18 gage deflection is **0.272 in**, below 0.30 in. Z2's worst snow is 86.1 psf, giving 0.267 in on 22 gage; Z1's worst is 60.9 psf, giving 0.188 in. If the dead load is conservatively included in the deflection load, the worst value is 0.296 in at 160.9 psf total, still below 0.30 in. The construction-stage bare-deck deflection under the 250 lb erection load is 0.31 in for 22 gage and 0.18 in for 18 gage, below the 0.75 in limit of criteria 9.1.
- **End reaction.** The interior-support reaction of a 3-span panel, taken as 1.1 w L, is at most **648 lb/ft** (Z2, S04) against the catalogue allowable end reaction at 1.5 in bearing of 1,180 lb/ft for 22 gage and 2,310 lb/ft for 18 gage. Utilisation 0.55.
- **Bearing and continuity.** Criteria 10.6 and S-501 note B require 1.5 in bearing at every support. The joist top chord provides 2.5 in (Joist Schedule note N2). The deck is laid in 3-span continuous runs with **staggered panel ends**: adjacent 3 ft panel runs start one joist apart, so at any joist only one panel end occurs and it bears on the full 2.5 in top chord. Where two ends must coincide, the ends are lapped/nested over the chord for the full 2.5 in, so each end has at least 1.5 in bearing. The 1.25 in per end that a butted mid-chord joint would give is not used. At the perimeter and opening headers the L5x3-1/2x5/16 edge angle and L4x4x3/8 header angles provide at least 1.5 in horizontal leg. This closes the bearing item; no RFI is open.
- **Span condition at the framed openings.** Deck is cut at RO-1, RO-2 and RO-3 and terminated on the L4x4x3/8 header, which becomes a support. Panel lengths are set out from each opening so that the piece between the header and the next joint is three spans wherever the local demand exceeds the two-span allowable. The 18 gage two-span bending allowable, computed from the catalogue basis of clause 3.1 with the two-span moment coefficient (w = 0.8 x the 3-span value), is 141.6 psf total load. At RO-1 and RO-2 the local total D + S demand is 132.6 psf (119.6 psf snow plus 13.0 psf dead), below 141.6 psf, so a two-span piece is acceptable; at RO-3 the demand is 160.9 psf total, so the panels are laid to give a three-span piece on the header. Where a shorter run is unavoidable the capacity for the actual span condition is used, as criteria 10.6 requires.
- **Diaphragm shear.** Design strength phi_d = 0.70 x catalogue Sn (criteria 10.1). The worst panel demand is **738.5 plf** in the 22 gage 36/9 Z2 perimeter against 819 plf (utilisation **0.902**). Z3's worst panel demand is 639.4 plf against 742.7 plf (0.861); Z4's is 737.9 plf against 1,225.7 plf (0.602); Z1's is 152.6 plf against 284.9 plf (0.536).
- **Uplift.** 0.9D + 1.0W, with the resisting dead load 0.9 x (deck weight + 4.5 psf roofing) and the MEP allowance excluded (criteria 6.2.3). phi_t = 0.50 x nominal pull-over (criteria 10.1). The worst demand is **68.7 psf** in the 22 gage 36/9 Z2 against 74.5 psf (utilisation **0.922**). Z1 is 26.8 against 33.1 psf (0.810); Z3 is 67.9 against 93.1 psf (0.729); Z4 is 94.9 against 119.8 psf (0.792).
- **Chords and collectors.** 27.82 kip against the 38.0 kip chord splice (0.732); 41.30 kip amplified collector against the 58.0 kip collector splice (0.712).
- **Procurement.** 18 and 22 gage only, ex stock at 4 and 2 weeks, both within the 9 week allowance. No 16 gage is used.

## 7 Bill of materials and installed cost

| Item | Quantity | Unit |
|---|---|---|
| deck area 18 gage | 25,752 | sf |
| deck area 22 gage | 16,560 | sf |
| support fasteners | 17,359 | ea |
| sidelap connectors | 8,532 | ea |

The BOM areas are net of the 888 sf of framed openings, as CP-RD-2026 notes 2 and 5 require. The 6 ft x 6 ft checking grid gives 42,192 sf of decked cells because RO-3 clips one 6 ft cell band; the exact opening area is 888 sf, so the BOM uses 42,312 sf. The 120 sf difference is the part of the clipped cell outside RO-3 and is not deck.

Installed cost at CP-RD-2026 rates: deck **USD 164,332** (18 gage 25,752 sf x 4.42 + 22 gage 16,560 sf x 3.05); support fasteners 17,359 ea x 1.35 = **USD 23,434**; sidelap connectors **USD 9,334** (SCREW-10 and BP at their separate rates); indirects **USD 21,040** (4 zones x 900, 14 rectangles x 260, 2 gages x 4,800, 3 patterns x 1,400). **Total USD 218,140.**

## 8 Items reported to the EOR

1. A-201 Rev C, M-401 Rev C, the mechanical schedule and the model agree on the position and height of every obstruction. The superseded Rev B positions (SCR-N at y = 158.0 ft, SCR-E at y = 17.7 to 138.3 ft) were not used. No open geometry discrepancy remains on the current revisions.
2. Criteria 5.4.3 and 5.4.6 use the windward drift height of 0.75 hd; the 5.4.2 truncation check is applied to that 0.75 hd value. At SCR-N the windward drift is full-height by 0.001 ft (0.75 hd = 4.031 ft against hc = 4.032 ft), so the peak is 89.5 psf over 16.13 ft, not the truncated 28.6 ft width that would result from using hd in place of 0.75 hd in the truncation check. This is the convention applied throughout the four Drifts rows.
3. The 16 gage option is excluded by the 14 week lead time, not by structural merit. The 20 gage option is available but was not used because the 2-gage limit and the cost comparison favour the 22/18 combination.
4. Permanent guarding or covers for RO-1, RO-2 and RO-3 after handover are outside the deck structural package. The openings are framed out and the deck is terminated on the header; the owner/architectural package is to provide permanent covers or guardrails meeting **29 CFR 1910.28(b)(3)**. This assignment is recorded in the constraint register, so the openings are not left unprotected after handover.
5. Any temporary cover over RO-1, RO-2 or RO-3 during erection is a purpose-made cover meeting **29 CFR 1926.754(e)(3)**: capable of supporting twice the weight imposed, secured against displacement, and marked HOLE or COVER. Structural deck is not left over an opening as a working surface (criteria 10.5).
6. The zone rectangles on the drawing are fastening envelopes on the 6 ft module, not deck-placing panels. The openings are cut out; the drawing shows them on `S-OPENING` and the BOM and cost are net of them. This is stated on the drawing and in section 5.
